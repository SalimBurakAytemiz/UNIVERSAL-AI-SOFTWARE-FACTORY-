# 14 — Test Kanıtları (üretim anında)

## Self-test'ler (build.py)

| Test | Sonuç |
|---|---|
| NEW:config/authority-matrix.json → protected | PASS |
| NEW:.github/workflows/x.yml → authority | PASS |
| PR231:core/sandbox/x → security | PASS |
| docs/ → not protected | PASS |
| EXT:coord-ledger → authority | PASS |
| V3-T1025 tier T2 | PASS |
| V3-T1026 tier T2 | PASS |
| UASCO-T0095 tier T2 | PASS |
| V3-T1004 (ledger) tier T2 | PASS |
| #231 write set 42 dosya | PASS |
| #251 write set 4 | PASS |
| T0031.b ← T0031:CODE_READY | PASS |
| kit, reseal'in review'undan sonra | PASS |
| PR-231 ön koşulu kit | PASS |
| V3-T1014 ← #231 MERGED | PASS |
| V3-T1008 başlangıç kapısı yok | PASS |
| R: registries/ klasörü korumalı (içinde korumalı dosya) | PASS |
| R: renderer/ klasörü korumalı | PASS |
| R: kabul kiti yetki-hassas | PASS |
| R: docs/x.mjs yetki-hassas | PASS |
| R: V3-T1008 T2 | PASS |
| R: UASCO-T0031 T2 | PASS |
| R: UASCO-T0077 (package.json) T2 | PASS |
| R: rutin prompt'larında Haiku yok | PASS |
| R: kit ← reseal:REVIEWED | PASS |
| R: UASCO-T0016 reseal gerekiyor (manifest write set) | PASS |
| R: UASCO-T0120 CI'sız değil | PASS |
| R3: V3-T1021 (docs/register) T2 | PASS |
| R2: docs/policy T2 | PASS |
| R2: register'a LLM yazmıyor | PASS |
| R2: norm 'NEW:docs/routines (…)' dizin | PASS |
| R2: bağımsız normalizasyon da dizin | PASS |
| overlap dizin/dosya | PASS |
| overlap NEW/PR önek normalize | PASS |
| overlap farklı dosya yok | PASS |
| overlap EXT yok | PASS |

## Statik kontroller

- Hata listesi: boş (0)
- Kontrol edilenler: eksik bağımlılık · geçersiz durum · SPLIT konteynerine bağımlılık · dalga tersliği · döngü · kapsanmayan AC · Task'sız Feature · kalan karma owner · Haiku'nun hassas dosyada kullanılması · korumalı dosyada T0 · repo dosyasında CI'sız commit · bilinmeyen karar kapısı · R1 kapanışında W1 sonrası Task

## Simülasyon

| Senaryo | Tamamlanan | Kilitlenme | Yazma çakışması | En çok slot |
|---|---|---|---|---|
| S0_NO_DECISION | 0/— | 0 | 0 | 0 |
| S1_D01_ONLY | 8/167 | 0 | 0 | 1 |
| S2_D01_GROUP1_NO_FOUNDER_ENV | 54/167 | 0 | 0 | 3 |
| S3_ALL_DECISIONS_FOUNDER_ENV | 167/167 | 0 | 0 | 3 |
| S4_ALL_DECISIONS_NO_FOUNDER_ENV | 92/167 | 0 | 0 | 3 |
| S5_KIT_EXCEEDS_LOCK_TIMEOUT | 104/167 | 0 | 0 | 3 |
| S6_KIT_FAILS_ONCE_THEN_PASSES | 167/167 | 0 | 0 | 3 |
| S7_KIT_FAILS_TWICE | 104/167 | 0 | 0 | 3 |
| S8_FOUNDER_TASKS_LONG | 167/167 | 0 | 0 | 3 |
| S9_FOUNDER_GONE_AFTER_LOCK | 101/167 | 0 | 0 | 3 |
| NEGATIVE_TESTS (beklenen > 0) | claim'ler kapalı: 43 çakışma | kilit kapalı: 25 ihlal | — | — |

Kalan kapı nedenleri (S2):

```
{
 "FOUNDER_ENV": {
  "Founder-PC": 17
 },
 "DECISION": {
  "D-11": 7,
  "D-29": 2,
  "D-27": 4,
  "D-13": 3,
  "D-19": 19,
  "D-28": 1,
  "D-02": 1,
  "D-02,D-28": 1,
  "D-04": 23,
  "D-15": 11,
  "D-22": 1,
  "D-05": 3,
  "D-21": 2,
  "D-06": 8,
  "D-14": 1,
  "D-17": 1,
  "D-30": 2,
  "D-10": 4,
  "D-09": 2
 }
}
```

Yeniden üretim ve manifest kontrolü sonuçları: `verify.py` çıktısı (16_VERIFY_RUN_LINUX.txt).
