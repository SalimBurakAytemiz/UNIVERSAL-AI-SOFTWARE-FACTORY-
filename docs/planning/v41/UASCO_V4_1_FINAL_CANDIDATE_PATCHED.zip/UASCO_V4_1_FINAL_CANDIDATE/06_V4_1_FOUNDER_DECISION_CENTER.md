# 06 — Founder Karar Merkezi (V4.1 patch)

> Hiçbir karar verilmedi. Güvenlik, harcama, secret, dış dağıtım ve korunan yol onayları kaldırılmadı.

## Yetkilendirme durumları (EX-05)

| Durum | Anlamı | Gereken |
|---|---|---|
| DESIGN_FINAL_CANDIDATE | Şu an. Repo'ya yazma yok. | — |
| FOUNDER_AUTHORIZED | D-01 verildi. Execution oturumu açılabilir; deterministik doğrulama ve register işleri başlar. | D-01 |
| CODE_ALLOWED | Task kendi startGates'i karara bağlıysa kodlanabilir, PR açılabilir. Slot sayısı: D-12 verilmeden 1, verildikten sonra 3. | D-01 + Task startGates (+ D-12 → 3 slot) |
| MERGE_ALLOWED | PR paketi review'dan geçti, mergeGates karara bağlı, T2 için Founder onayı var (D-31 paketi), birleşik SHA'da CI yeşil. | mergeGates (D-31, D-07, D-18, D-03, D-06, D-04, D-08, D-30) |
| WINDOWS_ACCEPTANCE_ALLOWED | Founder-PC kabul Task'ları başlayabilir. | D-23 + D-26 (+ D-03 sandbox için) + Founder-PC teşhisi (11_*) |

## Alias (kapanış → V4.1)

| Eski | V4.1 |
|---|---|
| FD-A | D-20 |
| FD-B | D-07 |
| FD-C | D-11 |
| FD-D | D-21 |
| FD-E | D-04 |
| FD-F | D-06 |
| FD-G | D-12 |
| FD-H | D-01 (+ D-08 bütçe) |
| FD-01 | tamamlandı (#293 merge 6b174dc) |
| FD-02 | D-21 |
| FD-03 | D-03 |
| FD-04 | D-07 |
| FD-05 | D-11 |
| FD-06 | D-01/D-08 |
| FD-07 | D-12 |
| FD-08 | D-21 (FA-8) |
| FD-09 | D-01 |
| FD-10 | D-06 |
| FA-1 | tamamlandı (#295 merge) |
| FA-2 | tamamlandı (#294 merge; #282 DEFER) |
| FA-3 | D-21 |
| FA-4 | D-07 |
| FA-5 | D-03 / UASCO-T0031 |
| FA-6 | D-11 |
| FA-7 | D-12 / V4-T0002 |
| FA-8 | D-21 |
| FA-9 | D-06 |

## 0. Execution başlangıcı (tek zorunlu karar) (1)

### D-01 — V4.1'in (V3.1 kayıtları dahil) tek yetkili yürütme planı olarak onayı + yazılı yeniden başlatma talimatı
- **Neden:** Dağınık plan kaynakları; yeniden başlatma yazılı talimat istiyor (FD-H, L.10). D-01 olmadan repo'ya yazma yok.
- **Seçenekler:** A: V4.1 onay + başlangıç talimatı (09_*) · B: değişiklik iste · C: beklet
- **Öneri:** A. Diğer kararlar başlangıcı değil, yalnız kendi alanlarındaki merge/paralellik/Windows kabulünü kapılar (EX-05)
- **Risk / maliyet:** Yok
- **Bloke ettiği:** Execution başlangıcı; UASCO-T0120 · matriste: UASCO-T0120, V3-T1021
- **Karar yoksa:** Hiçbir geliştirme başlamaz
- **En geç:** Execution oturumu açılmadan (tek zorunlu başlangıç kararı)
- **Alias:** FD-H, FD-06, FD-09, D-24


## 1. Alan kapıları — ilgili merge / paralellik / Windows kabulünden önce (8)

### D-23 — Windows'ta gerçek kurulum ve E2E kabulünü kim yürütecek?
- **Neden:** Bulut oturumu Windows'a kurulum yapamaz; CI installer PASS kullanıcı kabulü değildir (G-01).
- **Seçenekler:** A: Founder runbook (V3-T1019 + #231 founder-acceptance.mjs), sonuç JSON'u register'a · B: Founder-PC klasörü Remote Control ile oturuma bağlanır (her bağlantı Founder onaylı) · C: yalnız windows-latest CI E2E (ara kanıt; kabul değil)
- **Öneri:** A + C (C yalnız regresyon)
- **Risk / maliyet:** A: Founder zamanı ~30–60 dk/tur (ESTIMATE); token ihmal edilebilir. B: daha hızlı ama Founder makinesine komut erişimi. C: ~20–30 runner-dk/koşu (public repo ücretsiz)
- **Bloke ettiği:** UASCO-T0002, T0014, T0029, T0035, T0044, V3-T1018, V3-T1013, V3-T1010 · matriste: UASCO-T0002, UASCO-T0002.a, UASCO-T0014, UASCO-T0029, UASCO-T0031.c, UASCO-T0035, UASCO-T0044, UASCO-T0069.c, V3-T1010, V3-T1010.C, V3-T1010.F, V3-T1013, V3-T1013.B, V3-T1013.F, V3-T1018
- **Karar yoksa:** Bütün kabul aşamaları NOT_RUN_ENV_UNAVAILABLE; kod ve CI ilerler, hiçbir Feature ACCEPTED olmaz
- **En geç:** W0 kabulünden önce
- **Alias:** —

### D-31 — T2 (korumalı yol) onaylarının toplu takvimi
- **Neden:** Export (main.mjs), #231 (server.ts + manifest), CI provenance (ci.yml, validate-shards.mjs) korumalı; dağınık onay kritik yolu bekletir (protected-tier median 11,8 h).
- **Seçenekler:** A: dalga başına tek T2 paketi; her PR yine tek tek onaylanır · B: PR başına anlık onay · C: süreli genel onay (önerilmez)
- **Öneri:** A
- **Risk / maliyet:** Maliyet yok; rebase döngülerini azaltır. Paket gecikirse birden çok PR bekler
- **Bloke ettiği:** UASCO-T0016, T0031, T0069.a, V3-T1002/1003/1036 · matriste: UASCO-T0003, UASCO-T0004.A, UASCO-T0004.D, UASCO-T0007.A, UASCO-T0007.D, UASCO-T0016, UASCO-T0016.A, UASCO-T0016.D, UASCO-T0017.A, UASCO-T0017.D, UASCO-T0018.A, UASCO-T0018.D, UASCO-T0023, UASCO-T0023.a.A, UASCO-T0023.a.D, UASCO-T0024, UASCO-T0031, UASCO-T0031.a, UASCO-T0031.b, UASCO-T0033, UASCO-T0047, UASCO-T0049, UASCO-T0051.D, UASCO-T0051.E, UASCO-T0056.C, UASCO-T0056.D, UASCO-T0057.C, UASCO-T0057.D, UASCO-T0059.C, UASCO-T0059.D, UASCO-T0061, UASCO-T0061.a, UASCO-T0063, UASCO-T0064, UASCO-T0066.C, UASCO-T0066.D, UASCO-T0069.a, UASCO-T0069.b, UASCO-T0069.c, UASCO-T0070, UASCO-T0071, UASCO-T0072.D, UASCO-T0072.F, UASCO-T0074.B, UASCO-T0074.D, UASCO-T0077, UASCO-T0081, UASCO-T0091, UASCO-T0095, UASCO-T0098, UASCO-T0099, UASCO-T0100.a, UASCO-T0106, UASCO-T0107, UASCO-T0108, UASCO-T0109, UASCO-T0110, UASCO-T0111, UASCO-T0112, UASCO-T0115, UASCO-T0116, UASCO-T0117, UASCO-T0118, UASCO-T0120, UASCO-T0121, UASCO-T0123.C, UASCO-T0123.D, UASCO-T0125, UASCO-T0127, UASCO-T0129, V3-T1002, V3-T1003, V3-T1004, V3-T1005, V3-T1007, V3-T1008, V3-T1010.C, V3-T1011.B, V3-T1011.D, V3-T1014, V3-T1015, V3-T1016, V3-T1017.C, V3-T1017.D, V3-T1019, V3-T1020.D, V3-T1020.F, V3-T1021, V3-T1025, V3-T1026.B, V3-T1026.D, V3-T1028, V3-T1029, V3-T1030.C, V3-T1030.D, V3-T1031, V3-T1032, V3-T1033.D, V3-T1033.E, V3-T1035, V3-T1036, V3-T1037.C, V3-T1037.D
- **Karar yoksa:** B gibi: PR'lar hazırlanır ve review edilir, merge olmaz
- **En geç:** W0 içinde, ilk T2 PR hazır olmadan
- **Alias:** —

### D-03 — Windows sandbox: WSL2 (#231)
- **Neden:** W1 kritik yolu; sandbox olmadan test NOT_EXECUTED.
- **Seçenekler:** A: WSL2, ayrı 'UASCO' dağıtımı (kabul kiti interop=false ve appendWindowsPath=false istiyor; Founder'ın diğer WSL kullanımı etkilenmesin) · B: WSL2, mevcut dağıtım · C: Windows-native/Docker (yeni geliştirme)
- **Öneri:** A (doğrulamadan sonra)
- **Risk / maliyet:** Kod hazır, ücretsiz. Rebase + review 40–120 h (ESTIMATE). Ön koşullar: Win11, sanallaştırma, WSL2, dağıtımda node 24+ ve perl
- **Bloke ettiği:** UASCO-T0031, T0029 → W1 kritik yolu; ayrıca PR-231 eskalasyonunun çıkış kararı (kit 2 kez başarısız ya da kilit 2 kez zaman aşımı): A yeniden dene (sayaç sıfırlanır) · B paket üyelerini yeniden tasarım için aç · C PR-231'i ertele (claim'ler serbest) · matriste: UASCO-T0029, UASCO-T0031, UASCO-T0031.c, UASCO-T0069.c
- **Karar yoksa:** #231 rebase ve review'a kadar ilerler; merge yok; sandboxsız host modu hiçbir zaman yok. Eskalasyonda karar yoksa C: PR-231 ertelenir, claim'ler serbest bırakılır, bağımlı Task'lar BLOCKED_DECISION
- **En geç:** UASCO-T0031 merge'ünden önce (doğrulama hemen)
- **Alias:** FD-03, FA-5

### D-07 — Trust-root reseal sırası
- **Neden:** #251, #247 ve #231 aynı manifest dosyasında çakışıyor.
- **Seçenekler:** A: tek reseal · B: batch 1 = #251 → #247 (seri, her biri kendi reseal'iyle), batch 2 = #231 (FA-5 sonrası) · C: üç bağımsız, sırasız
- **Öneri:** B
- **Risk / maliyet:** Batch başına ~1–2 h Founder + Opus review (ESTIMATE). #251 ve #247 güncel base'in 199–263 commit gerisinde; yeniden review gerekir
- **Bloke ettiği:** UASCO-T0069.a, V3-T1002/1003/1036 merge, UASCO-T0031 · matriste: UASCO-T0069.a, UASCO-T0069.b, UASCO-T0069.c, UASCO-T0100.a
- **Karar yoksa:** Reseal yok; CI provenance ve sandbox merge'ü bekler
- **En geç:** UASCO-T0069.a başlamadan
- **Alias:** FD-B, FD-04, FA-4

### D-12 — Founder-PC'deki yerel V6 / Task Scheduler / worker'ı doğrula ve durdur
- **Neden:** İkinci bir kontrol düzlemi aynı repoda iş başlatabilir (B8, G-20).
- **Seçenekler:** A: rapor M.7'deki PowerShell adımları; durdur ve raporla · B: claim protokolüne kat (geliştirme gerekir) · C: bırak
- **Öneri:** A
- **Risk / maliyet:** ~10 dk (ESTIMATE); risk yok denecek kadar az
- **Bloke ettiği:** V4-T0002; 3 slot paralelliği · matriste: V4-T0002
- **Karar yoksa:** Execution tek slotla (tek builder) çalışır; yerel durum UNKNOWN olarak raporlanır
- **En geç:** 3 slota çıkmadan (o zamana kadar 1 slot)
- **Alias:** FD-G, FD-07, FA-7

### D-08 — Haftalık geliştirme bütçesi ve dağılımı
- **Neden:** Kota geçmişte takvimin %55'ini durdurdu (G-10).
- **Seçenekler:** A: haftalık oturum/saat sınırı + %90'da sert durma · B: yalnız gözlem · C: sınırsız
- **Öneri:** A (örnek: %60 build, %20 review, %10 supervisor, %10 yedek)
- **Risk / maliyet:** Sınır düşük seçilirse yavaşlar
- **Bloke ettiği:** UASCO-T0110 · matriste: UASCO-T0110
- **Karar yoksa:** En fazla 3 builder; USAGE_LIMIT görülünce dur
- **En geç:** W1 paralel lane'leri açılmadan
- **Alias:** FD-H (bütçe kısmı), FD-06

### D-18 — CI shard provenance kuralları
- **Neden:** Sahte PASS riski (COORD-001, B3).
- **Seçenekler:** A: kabul (V3.1 §7.5) · B: yalnız 'Re-run all jobs'
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** V3-T1002/1003/1036 · matriste: V3-T1002, V3-T1003, V3-T1036
- **Karar yoksa:** Yalnız 'Re-run all jobs' kullanılır
- **En geç:** V3-T1002 merge'ünden önce
- **Alias:** —

### D-26 — Desteklenen işletim sistemi matrisi
- **Neden:** Kabul kiti ve WSL2 hedefi Windows 11; Windows 10 (WSL2 için 2004+/build 19041+) desteği doğrulanmadı. EX-08: Upgrade dayatılmaz; önce salt-okur teşhis.
- **Seçenekler:** A: R1–R2 yalnız Windows 11 · B: Windows 10 + 11 · C: R2'de karar
- **Öneri:** A
- **Risk / maliyet:** İkinci kullanıcı Windows 10 kullanıyorsa kapsam dışı
- **Bloke ettiği:** UASCO-T0002, DS-R2-INSTALL · matriste: UASCO-T0002, UASCO-T0002.a
- **Karar yoksa:** A
- **En geç:** UASCO-T0002'den önce, 11_* teşhisinden sonra
- **Alias:** —


## 2. Kodlama sürerken (14)

### D-29 — Claude CLI launcher hash pin'i ile otomatik güncelleme politikası
- **Neden:** Güncelleme executor'ı NOT_READY yapabilir (G-09, UNVERIFIED).
- **Seçenekler:** A: güncellemede Founder tek tıkla yeniden doğrular · B: W1 kabul run'ları boyunca otomatik güncelleme kapalı · C: pin'i kaldır (önerilmez)
- **Öneri:** A; kabul run'ları sırasında geçici B
- **Risk / maliyet:** B'de güvenlik yamaları gecikebilir
- **Bloke ettiği:** UASCO-T0061.a, T0014 · matriste: UASCO-T0014, UASCO-T0061.a
- **Karar yoksa:** Pin korunur; değişimde run BLOCKED
- **En geç:** W1'in 3 ardışık run'ından önce
- **Alias:** —

### D-19 — SEC-PROFILE-R1 araçları ve pre-dev kalite eşiği
- **Neden:** SECURITY_ACCEPTED için gerçek araç gerekir; PARTIAL hiçbir zaman VERIFIED olmaz.
- **Seçenekler:** A: Founder-PC'ye pinned gitleaks + SCA (trivy) · B: yalnız yerleşik secret scan (sonuç PARTIAL) · C: araçları installer'a göm (lisans/boyut incelemesi)
- **Öneri:** A (R1); C W4'te değerlendirilir
- **Risk / maliyet:** ~15 dk kurulum
- **Bloke ettiği:** V3-T1010, UASCO-T0035, T0026 · matriste: UASCO-T0026, UASCO-T0035, V3-T1010, V3-T1010.C, V3-T1010.F
- **Karar yoksa:** Teslim DELIVERED_SECURITY_PARTIAL etiketi alır
- **En geç:** W1 kabulünden önce
- **Alias:** —

### D-21 — IR reviewer: token yenile mi, IR'ı opsiyonel/emekli mi; eski waiting run 39687649214
- **Neden:** IR check her PR'da FAIL; çift review (G-14, B4); 39687649214 2026-10-21'den beri bekliyor (VERIFIED).
- **Seçenekler:** A: token yenile (`claude setup-token` → env uasco-review) · B: IR resmen opsiyonel; tek yol = taze alt ajan reviewer + ledger · C: ayrı reviewer App (D-05)
- **Öneri:** B şimdi, C W2'de; 39687649214 reddet/iptal
- **Risk / maliyet:** GitHub tarafından zorlanan bağımsızlık W2'ye kalır
- **Bloke ettiği:** V3-T1034, UASCO-T0098 · matriste: UASCO-T0098, V3-T1034
- **Karar yoksa:** IR check yok sayılır; ledger review'u geçerli
- **En geç:** W1 başında
- **Alias:** FD-D, FD-02, FD-08, FA-3, FA-8

### D-20 — Windows CI kararlılığı ile #231 paralel mi?
- **Neden:** Sıra belirsiz (FD-A).
- **Seçenekler:** A: paralel kodlama; #231 merge'ü V3-F038 AC1–AC2 sonrası · B: önce CI · C: önce #231
- **Öneri:** A
- **Risk / maliyet:** Yok
- **Bloke ettiği:** V3-T1001, UASCO-T0031
- **Karar yoksa:** A gibi davranılır (merge güvenliği korunur)
- **En geç:** W0 içinde
- **Alias:** FD-A

### D-30 — latest-known-good .exe'nin saklanması
- **Neden:** Artifact 2026-12-02T11:14:14Z'de siliniyor; SHA ZIP'e ait (G-12).
- **Seçenekler:** A: Founder indirip saklar, SHA register'da · B: GitHub draft Release (T3 sınırına yakın) · C: yalnız artifact
- **Öneri:** A
- **Risk / maliyet:** Elle adım
- **Bloke ettiği:** V4-T0001 · matriste: V4-T0001, V4-T0001.a
- **Karar yoksa:** SHA register'a yazılır, binary saklanmaz
- **En geç:** 2026-12-01'den önce
- **Alias:** —

### D-17 — Base kırmızıyken merge durur, geliştirme durmaz (politika belgesi + ci.yml değişikliği)
- **Neden:** V4 ilkesiyle aynı. EX-06: M0 seri merge bu karara bağlı DEĞİL; mevcut kurallar içinde geçici mod (tek merger + update-branch + birleşik SHA'da tam CI) zaten uygulanır.
- **Seçenekler:** A: kabul · B: tam dondurma
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** V3-T1007 · matriste: V3-T1007
- **Karar yoksa:** Geçici mod sürer; base kırmızıyken zaten merge yapılmaz (mevcut ruleset: required check kırmızı)
- **En geç:** V3-T1007 merge'ünden önce
- **Alias:** —

### D-22 — #282 yeniden ele alma ölçütü
- **Neden:** DEFER_TO_ROADMAP; ölçüm store.ts kilit yoluna giriyor.
- **Seçenekler:** A: V3-T1001 merge sonrası, aynı head'de 3 ardışık tam yeşil Windows + base kontrol koşusu; otomatik yeniden koşu yok · B: SUPERSEDED olarak kapat
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** UASCO-T0090 · matriste: UASCO-T0090
- **Karar yoksa:** DEFER
- **En geç:** UASCO-T0090 değerlendirmesinden önce
- **Alias:** —

### D-04 — Birleşik SHA CI: merge queue mi, zorunlu up-to-date mi
- **Neden:** B6; native merge queue'nun bu kişisel repoda kullanılabilirliği UNVERIFIED.
- **Seçenekler:** A: merge queue (varsa) · B: ruleset 'up to date' zorunlu · C: yalnız supervisor seri kuralı
- **Öneri:** C şimdi (V3-T1008); A ya da B W2 öncesi
- **Risk / maliyet:** B: CI süresi uzar
- **Bloke ettiği:** V3-T1020 · matriste: V3-T1020, V3-T1020.D, V3-T1020.F
- **Karar yoksa:** C
- **En geç:** W2'den önce
- **Alias:** FD-E

### D-06 — Ledger ↔ founder-authority köprüsü
- **Neden:** B5; #293 kapısı ledger içinden açılamadı.
- **Seçenekler:** A: API'den okunan kayıt türü · B: Founder manuel merge
- **Öneri:** A
- **Risk / maliyet:** ~4–10 h; geliştirme altyapısı (supervisor-owned)
- **Bloke ettiği:** V3-T1004 · matriste: V3-T1004
- **Karar yoksa:** B
- **En geç:** W2'den önce
- **Alias:** FD-F, FD-10, FA-9

### D-02 — v1 kapsamı: R1 = kaynak teslimi
- **Neden:** —
- **Seçenekler:** A: kaynak/ZIP · B: + PR · C: + deploy
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** UASCO-T0038 · matriste: UASCO-T0038, UASCO-T0040
- **Karar yoksa:** A
- **En geç:** W1 kabulünden önce
- **Alias:** —

### D-11 — #66 SUPERSEDED
- **Neden:** Ortak geçmiş yok (M.5).
- **Seçenekler:** A: SUPERSEDED (Founder kapatır) · B: güncel base'de yeniden kur
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** UASCO-T0096, T0095 · matriste: UASCO-T0096
- **Karar yoksa:** Açık kalır
- **En geç:** W2'den önce
- **Alias:** FD-C, FD-05, FA-6

### D-14 — Repo public kalır
- **Neden:** Actions ücretsiz.
- **Seçenekler:** A: public · B: private + Actions bütçesi
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** UASCO-T0113 · matriste: UASCO-T0113
- **Karar yoksa:** A
- **En geç:** W2'den önce
- **Alias:** —

### D-25 — Siyah/kırmızı/beyaz tasarım sistemi gerçek gereksinim mi?
- **Neden:** V4 PK-05 ekledi; V3.1/repo'da kaynağı yok (G-13). Bu kararla V4.1'e Task eklenmedi.
- **Seçenekler:** A: evet, yalnız CSS token katmanı · B: mevcut paleti koru · C: W4'e ertele
- **Öneri:** Founder tercihi; A ise yalnız token katmanı
- **Risk / maliyet:** ~8–20 h (ESTIMATE)
- **Bloke ettiği:** PK-05 (Task yok)
- **Karar yoksa:** Mevcut palet korunur
- **En geç:** W2'den önce
- **Alias:** —

### D-16 — Faz maliyet sınırları
- **Neden:** D-08'e bağlı.
- **Seçenekler:** A: P0–P1 sınırını şimdi, P2+ R1 ölçümünden sonra
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** Bütün fazlar
- **Karar yoksa:** Sınır yok; yalnız ölçüm
- **En geç:** W1 açılmadan (P0–P1 kısmı)
- **Alias:** —


## 3. İleri fazlar (7)

### D-05 — Builder/Reviewer GitHub App'leriyle kimlik ayrımı
- **Neden:** —
- **Seçenekler:** A: App'ler · B: ikinci hesap · C: yalnız ledger
- **Öneri:** A
- **Risk / maliyet:** App kurulumu
- **Bloke ettiği:** UASCO-T0072, T0097 · matriste: UASCO-T0072, UASCO-T0072.D, UASCO-T0072.F, UASCO-T0097
- **Karar yoksa:** Ledger + alt ajan reviewer
- **En geç:** W2
- **Alias:** FD-02 (kısmen)

### D-09 — Ürün içi ücretli API / ikinci sağlayıcı
- **Neden:** —
- **Seçenekler:** A: W3'te T3 onayıyla · B: hiç
- **Öneri:** A
- **Risk / maliyet:** Ücretli kullanım
- **Bloke ettiği:** UASCO-T0066 · matriste: UASCO-T0066, UASCO-T0066.C, UASCO-T0066.D
- **Karar yoksa:** Yalnız Claude CLI
- **En geç:** W3
- **Alias:** —

### D-10 — 599 rol → arketip + paket
- **Neden:** Eval verisi gerekli.
- **Seçenekler:** A: evet (V3-T1017 sonrası) · B: hayır
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** UASCO-T0059, V3-T1037 · matriste: UASCO-T0059, UASCO-T0059.C, UASCO-T0059.D, V3-T1037, V3-T1037.C, V3-T1037.D
- **Karar yoksa:** 9 bağlı rol
- **En geç:** W2–W3
- **Alias:** —

### D-13 — Code-signing sertifikası
- **Neden:** —
- **Seçenekler:** A: OV/EV sertifika · B: imzasız devam
- **Öneri:** A (tür/maliyet araştırması)
- **Risk / maliyet:** Sertifika ücreti (UNKNOWN)
- **Bloke ettiği:** UASCO-T0093 · matriste: UASCO-T0093
- **Karar yoksa:** İmzasız; SmartScreen belgeli
- **En geç:** W4
- **Alias:** —

### D-15 — Mobil ve ses (gizlilik)
- **Neden:** —
- **Seçenekler:** A: W5 · B: iptal
- **Öneri:** A
- **Risk / maliyet:** —
- **Bloke ettiği:** UASCO-T0082, T0018 · matriste: UASCO-T0018, UASCO-T0018.A, UASCO-T0018.D, UASCO-T0082
- **Karar yoksa:** Kapsam dışı
- **En geç:** W5
- **Alias:** —

### D-27 — RunAsNode fuse: utilityProcess'e taşı mı, AC'yi düzelt mi
- **Neden:** Backend ELECTRON_RUN_AS_NODE ile çalışıyor (G-11, VERIFIED).
- **Seçenekler:** A: UASCO-T0023.a ile taşı, sonra fuse kapat · B: fuse açık, diğer fuse'lar kapalı; AC düzeltilir
- **Öneri:** A; olmazsa B
- **Risk / maliyet:** 8–20 h (ESTIMATE)
- **Bloke ettiği:** UASCO-T0023, T0023.a · matriste: UASCO-T0023, UASCO-T0023.a, UASCO-T0023.a.A, UASCO-T0023.a.D
- **Karar yoksa:** Fuse açık (mevcut)
- **En geç:** W4
- **Alias:** —

### D-28 — Sandbox'ta müşteri bağımlılıklarının kurulma politikası
- **Neden:** Sandbox --net izole (G-16).
- **Seçenekler:** A: sandbox dışında kilit dosyası + integrity ile ön indirme, ağsız test · B: yalnız registry egress · C: ağ açık (önerilmez)
- **Öneri:** A
- **Risk / maliyet:** Tasarım + uygulama (ESTIMATE 16–40 h)
- **Bloke ettiği:** UASCO-T0037, T0040 · matriste: UASCO-T0037, UASCO-T0040
- **Karar yoksa:** Yalnız bağımlılıksız şablonlar
- **En geç:** W3'ten önce
- **Alias:** —


## Birleştirilen kararlar (1)

### D-24 — V3.1 kayıtlarını (paket içinde sources/v31) V4.1'in Task/AC kaynağı olarak kabul et
- **Neden:** V4 paketinde 164 Task'lık matris yoktu; bu pakette var.
- **Seçenekler:** A: kabul; Execution yalnız deterministik hash/tutarlılık kontrolü yapar · B: önce üçüncü taze reviewer doğrulasın · C: yalnız 29 seed
- **Öneri:** SUBSUMED_BY D-01: V4.1 paketi V3.1 kayıtlarını sources/v31 altında içerir; D-01-A onayı bu kaynağı kabul etmek demektir. Ayrı karar gerekmez (EX-05 tekleştirme). 46 PROPOSED Task ilk koşudan önce Task review'undan geçer
- **Risk / maliyet:** Yok
- **Bloke ettiği:** —
- **Karar yoksa:** D-01 yoksa hiçbir Task başlamaz
- **En geç:** — (D-01 ile birleştirildi)
- **Alias:** D-01 alias

