# 12 — EX-01..EX-10 Bulgu Kapanış Raporu

Her bulgu kaynakla karşılaştırıldı. Reddedilen bulgu yok: 10 bulgunun 10'u kanıtla doğrulandı. Kısmi kalanlar açıkça işaretli.

| ID | Önem | Başlık | Durum | Düzeltme | Kanıt |
|---|---|---|---|---|---|
| EX-01 | P0 | DONE/MERGE/ACCEPTED kilitlenmesi | **CLOSED** | Tipli durumlar ve bağımlılıklar (patch_ex.STATES, TYPED_DEPS); PR paketleri (BUNDLES). UASCO-T0031 artık REVIEWED'de tamamlanıyor, merge PR-231 paketinde. T0031.b ← T0031:CODE_READY; T0069.c ← T0031:REVIEWED + T0031.b:REVIEWED + T0069.a:MERGED; T0069.a ← V3-T1002/1003/1036:REVIEWED. | Self-test 'T0031.b ← T0031:CODE_READY' = True. Simülasyon S3: 167/167 tamamlandı, kilitlenme 0. S1 ve S2'de tamamlanmayanların hepsi DECISION ya da FOUNDER_ENV nedenli (kilitlenme 0). |
| EX-02 | P0 | Yeni korumalı dosyalarda tier | **CLOSED** | `canon_path()` NEW:/PR231:/PR247: öneklerini ve '(…)' açıklamalarını temizliyor. Repo korumasına ek AUTHORITY_SENSITIVE (fail-closed T2): config/, .github/, scripts/validate-, scripts/ci/, scripts/run-validation, automation/lib/, schemas/, prompts/, coord-ledger. CI'sız supervisor commit'i yalnız register dalı. NEW_PROVISIONAL yollar en az T1 ve keşifte yeniden sınıflanıyor. | Self-test: NEW:config/authority-matrix.json korumalı · NEW:.github/workflows yetki-hassas · V3-T1025/V3-T1026/UASCO-T0095/V3-T1004 = T2 · T0 ve CI'sız commit kontrolü hata 0 — True |
| EX-03 | P0 | Gerçek dosyada paralel yazma | **CLOSED** | PR-231 (42), PR-251 (4), PR-247 (3) gerçek changed-files'tan paket üyelerine dağıtıldı. Karma owner'lı 16 açık Task otomatik bölündü. Önek/dizin çakışması algılanıyor (sim.overlap). Aynı lane'deki Task'lar da claim'e tabi. V3-T1014 ← PR-231 MERGED (executors.ts). Claim'ler MERGED'e kadar tutuluyor. | Self-test '#231 write set 42 dosya' = True; overlap testleri geçti. Simülasyon: yazma çakışması S1 0 · S2 0 · S3 0; en çok slot 3. Build kontrolü 'mixed owner remains' = 0. |
| EX-04 | P0 | Kabul kiti SHA'sı | **CLOSED** | Sıra: T0069.c reseal (son commit) → T0031.c kit son head'de → paket merge (ön koşul: T0031.c). Head değişirse kit yeniden. Merge sonrası V4-T0001.a installer + T0002.a yeniden kurulum; R1 koşuları bunun üzerinde. V4-T0001.a bütün R1 kod Task'larını MERGED bekliyor. | Self-test 'kit ← reseal:CODE_READY' = None, 'PR-231 ön koşulu kit' = True. Kit README'si: sonuç SHA'ya bağlı; bilinmeyen SHA = NOT_ACCEPTED (kaynak #231 docs/acceptance/windows/README.md). |
| EX-05 | P1 | Başlatma şartları çelişkisi | **CLOSED** | AUTH_STATES (5 durum). Başlangıç için tek zorunlu karar D-01. D-24, D-01 ile birleştirildi. Diğer kararlar yalnız kendi merge/paralellik/Windows alanlarını kapılar. D-12 yoksa 1 slot (tek supervisor + tek builder). 01_* ve 09_* aynı kuralı kullanıyor. | Simülasyon S1 (yalnız D-01, 1 slot): 8 Task tamamlandı, kilitlenme 0. S0 (karar yok): 0 Task. |
| EX-06 | P1 | M0 / D-17 | **CLOSED** | V3-T1008'in başlangıç kapısı kaldırıldı. Geçici mod mevcut kurallar içinde (tek merger + update-branch + birleşik SHA'da tam CI). D-17 yalnız V3-T1007 (politika + ci.yml, T2) için. 14 günlük ölçüt `monitoring` alanında. | Self-test 'V3-T1008 başlangıç kapısı yok' = True. |
| EX-07 | P1 | Doğrulama komutu | **CLOSED (Linux) / Windows NOT_RUN** | `v41/verify.py`: platformdan bağımsız Python; V41_PACKAGE_ROOT'u kendisi ayarlar. Linux ve Windows komutları 09_*'da. | Linux'ta çalıştırıldı (14_*). Windows'ta çalıştırılmadı: bu ortamda Windows/PowerShell yok (NOT_RUN_ENV_UNAVAILABLE). |
| EX-08 | P1 | Windows ön koşul teşhisi | **CLOSED (doküman) / ortam UNKNOWN** | 11_* salt-okur komutlar; D-26 'Windows 11 dayatma' yerine teşhis sonrası karar. | Komutlar bu oturumda çalıştırılmadı (Founder-PC yok). |
| EX-09 | P1 | Uzun pencere ölçütleri | **CLOSED** | MONITORING_SPLIT (V3-T1001, UASCO-T0088, V3-T1008, V3-T1033, UASCO-T0121): `doneMerge` ↔ `monitoring`. 10 AC STABILITY_MONITORING; R1 kapısı 45 kabul AC'si + 7 izleme AC'si (kapı değil). Test güvenliği değişmedi: deterministik test birleşik SHA'da zorunlu. | Kanıt sayaçları: {'EVIDENCE_SPEC_COUNT': 102, 'EVIDENCE_VERIFIED_PASS_COUNT': 0, 'LEGACY_UNIT_EVIDENCE_TO_RELINK': 10, 'NOT_PRODUCED': 92, 'STABILITY_MONITORING_ACS': 10, 'R1_GATE_ACS_ACCEPTANCE': 45, 'R1_GATE_ACS_MONITORING': 7}. |
| EX-10 | P2 | 102 kanıt ≠ PASS | **CLOSED** | EVIDENCE_SPEC_COUNT 102 ve EVIDENCE_VERIFIED_PASS_COUNT 0 ayrı. LEGACY_UNIT 10, NOT_PRODUCED 92. Rapor ve başlangıç talimatı bu sayaçları kullanıyor. | EVIDENCE_VERIFIED_PASS_COUNT = 0. |

## Bağımsız review (tur 1) bulguları ve kapanışı

| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |
|---|---|---|---|---|---|
| R-S1 | HIGH | Korumalı dosya içeren klasör hedefleri T1 | **CLOSED** | is_protected/is_auth/is_sec klasör kapsamını kontrol ediyor (as_dir) | self-test 'registries/ klasörü korumalı', 'renderer/ klasörü korumalı' |
| R-S2 | HIGH | Kabul kiti kendini onaylıyor; docs değişikliği T0'a düşüyor | **CLOSED (kısmi risk kabulü)** | docs/acceptance/ ve docs altındaki çalıştırılabilir dosyalar T2 + Opus review; T0 yalnız .md dokümanları (CI'lı PR). Kiti yazan ile koşan farklı: kiti Founder çalıştırır, sonucu supervisor şema ve SHA ile doğrular | self-test 'kabul kiti yetki-hassas'. Kalan risk: kitin içeriği builder tarafından yazılıyor; T2 Founder onayı + Opus review bunu sınırlıyor, ama ortadan kaldırmıyor |
| R-S3 | HIGH | Merge kuralı ve register düşük tier'da | **CLOSED** | EXT:supervisor* yetki-hassas (T2). Register'a yalnız deterministik araç yazar. T0008/T0028 deterministik; T0120 gerçek roadmap dosyaları; T0121/T0122 .md PR'ı; V3-T1005 .github + scripts/ci (T2) | self-test 'V3-T1008 T2', 'UASCO-T0120 CI'sız değil'; build kontrolü 'ci-less commit not deterministic/register-only' = 0 |
| R-S4 | MEDIUM-HIGH | Güvenlik uygulayan kod T1 | **CLOSED** | SECURITY_SENSITIVE genişletildi (executors, devrun dahil) ve T2'ye bağlandı | self-test 'UASCO-T0031 T2'; build kontrolü 'security-sensitive below T2' = 0 |
| R-S5 | MEDIUM | Eksik yetki/güvenlik dosyaları | **CLOSED** | package.json/lock, .npmrc, build-installer, installer/, core/policy, models/router, models/omniroute, docs/routines, supervisor araçları T2; rutin prompt'larında Haiku yok | self-test 'UASCO-T0077 T2', 'rutin prompt'larında Haiku yok' |
| R-D1 | HIGH | PR-231 sırası makineyle zorlanmıyor | **CLOSED** | Kit ← T0069.c:REVIEWED; paket ön koşulu kit; headFreezeAfter; reseal penceresi kilidi (base sabit, update-branch gerekmez); simülasyonda head-freeze denetimi | self-test 'kit ← reseal:REVIEWED'; simülasyon lockViolations = 0, headFreezeViolations = 0 |
| R-D2 | HIGH | Manifest write set'lerde yok | **CLOSED** | Mühürlü (373 dosya) bir dosyaya dokunan her Task'a manifest eklendi → `<id>.D` reseal alt Task'ı (aynı PR, sıralı devir). Reseal penceresi kilidi araya merge girmesini engelliyor | self-test 'UASCO-T0016 reseal gerekiyor'; build kontrolü 'sealed file without manifest' = 0; simülasyon lockViolations = 0 |
| R-D3 | MEDIUM | '0 çakışma' tanım gereği | **CLOSED** | Claim mantığından ayrı bağımsız denetim (günlük aralıkları, ayrı normalizasyon); EXT kaynakları (register, coord-ledger, supervisor, GitHub, claude.ai) claim edilir; aynı PR'da eşzamanlı kodlama yasak | simülasyon independentAuditConflicts = 0 (S1, S2, S3) |
| R-D4 | MEDIUM | Kod dışı Task'larda merge kapısı yok sayılıyor | **CLOSED** | Kod dışı Task'lar bütün kapılar verilmeden başlamaz | simülasyon gateBypass = 0 |
| R-D5 | LOW | Slot sınırı, neden sırası, belirsiz yol | **CLOSED** | Slot D-12'den türetiliyor; belirsiz NEW yol dizin öneki; UASCO-T0125 ← PR-231 MERGED | simülasyon kodu; statik döngü kontrolü build'de (dfs) |

## Bağımsız review (tur 2) bulguları ve kapanışı

| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |
|---|---|---|---|---|---|
| R2-N0 | HIGH | Reseal kilidi bütün merge'leri süresiz dondurabilir | **CLOSED** | Kilit yalnız ön koşullar başlatılabilirken alınır; 24 h zaman aşımı + iptal (reseal ve süren kit geçersiz); 2 iptalden sonra Founder'a eskalasyon; kilitte bekleyen Task'ın nedeni MERGE_LOCK olarak raporlanır | S2: 54/167 (önce 28); S4 (Founder-PC yok): kilit alınmadı; S5: 2 iptal + eskalasyon, kilit sonda serbest, kilitlenme 0 |
| R2-N1 | MEDIUM | Normalizasyon boşluğu; denetim bağımsız değil | **CLOSED** | Uzantısız ya da açıklamalı yollar dizin öneki. Denetim ayrı normalizasyonla (audit_norm, posixpath) ve deneme bazında aralıklarla çalışıyor | self-test 'norm NEW:docs/routines dizin', 'bağımsız normalizasyon da dizin'; negatif test: claim'ler kapalıyken denetim çakışma buluyor |
| R2-N2 | MEDIUM | Reseal öncesi update-branch kuralı yok | **CLOSED** | Reseal üyesinin iş tanımına eklendi: kilit başında update-branch, sonra reseal; base kilitle sabit | 02_* matrisinde ilgili Task'ların `work` alanı; 09_* reseal kuralı |
| R2-N3 | MEDIUM | LLM Task'ları register'a yazıyor | **CLOSED** | UASCO-T0101 ve T0102 Founder kararı oldu; V3-T1021 eşleme dosyasını repo PR'ı olarak yazıyor (deterministik içe aktarma); UASCO-T0123 `registries/` (T2). Build kuralı: register-yalnız hedefli Task'lar yalnız deterministik olabilir | self-test 'register'a LLM yazmıyor'; build kontrolü 'LLM writes register' = 0 |
| R2-N4 | LOW | docs/policy düşük tier | **CLOSED** | docs/policy/ yetki-hassas (T2); Haiku yok | self-test 'docs/policy T2' |

## Bağımsız review (tur 3) bulguları ve kapanışı

| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |
|---|---|---|---|---|---|
| R3-L1 | MEDIUM | Kilit süresince Founder rezerve değil; sahte iptaller | **CLOSED** | Kilit süresince Founder yalnız kilitli paketin kitini yapar; zaman aşımı kit başlatılabilir olunca başlar; ön koşulsuz paketlerde zaman aşımı yok | S3: iptal 0; S6: iptal 0 (yalnız gerçek kit başarısızlığı) |
| R3-L2 | MEDIUM | Kit başarısızlığında düzeltme yolu yok | **CLOSED** | NOT_ACCEPTED → kilit bırakılır, paket üyeleri yeniden açılır (aynı PR'da düzeltme, claim'ler pakette), kit yeniden koşulur | S6: kit 1 kez başarısız → onarım → 167/167, kilitlenme 0, kilit/freeze ihlali 0 |
| R3-L3 | MEDIUM | Eskalasyonun çıkışı yok | **CLOSED** | Eskalasyon kararı: PR-231 → D-03 (yeniden dene / yeniden tasarla / ertele); karar yoksa paket DEFERRED, claim'ler serbest, bağımlılar BLOCKED_DECISION | S5 ve S7: eskalasyon sonrası claim'ler serbest; kalan Task'ların nedeni 'D-03 (eskalasyon)'; kilit sonda serbest |
| R3-L4 | LOW | V3-T1021 register'a T1 yoldan giriyor | **CLOSED** | docs/register/ yetki-hassas → T2 (Opus review + Founder onayı) | self-test 'V3-T1021 (docs/register) T2' |

## Bağımsız review (tur 4) bulguları ve kapanışı

| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |
|---|---|---|---|---|---|
| R4-L1 | MEDIUM | Kilit alınırken Founder zaten meşgul → sahte iptal | **CLOSED** | Kilit yalnız Founder boşken alınır; zaman aşımı kit fiilen başlayınca başlar | S8 (Founder Task'ları 40 h): iptal 0, 167/167; S3: iptal 0 |
| R4-L2 | LOW | S6'da kit başarısızlığı lockAborts'ta görünmüyor | **CLOSED** | Kit NOT_ACCEPTED da iptal sayacına yazılıyor | S6 lockAborts: 1 (kit NOT_ACCEPTED) |
| R4-L3 | LOW | Eskalasyon mevcut D-03 kimliğini yeniden kullanıyor | **CLOSED** | Eskalasyon ayrı karar örneği (ESC-<paket>, D-03/D-07 kapsamında); devamda rebase + yeniden review + yeniden claim zorunlu | S5/S7 nedeni: 'ESC-PR-231 (yeni karar örneği …)' |
| R5-LOW | LOW | Kilit alındıktan sonra kit başlamazsa kilit süresi sınırsız | **CLOSED** | Kit öncesi zaman aşımı 8 h (LOCK_PREKIT_TIMEOUT_H) → iptal; 2 iptal → eskalasyon | S9: Founder kilitten sonra kayboluyor → iptal + eskalasyon, kilit sonda serbest |

**Bedel (Founder'ın bilmesi gereken):** güvenlik sıkılaştırmasından sonra açık Task'ların T2 sayısı **102** (önceki: 35). Bunların hepsi Founder T2 onayıyla merge edilir. D-31 (toplu onay takvimi) bu yüzden daha kritik hâle geldi. S1'de (yalnız D-01) 8 Task tamamlanabiliyor; geri kalanların çoğu D-31'i bekliyor.

## Doğrulama sırasında bulunan ek hatalar (denetimde yoktu; düzeltildi)

1. Sahiplik eşleşmesinde boş önek (`PR247:` normalize edilince boş string) her yolla eşleşiyordu; register ve EXT yolları D lane'e düşüyordu. Düzeltildi: önek ham eşleştirme + kanonik eşleştirme ayrımı.
2. tests/docs dosyaları Feature'ın V4 lane'ine düşüyor ve sahte karma owner üretiyordu (ör. UASCO-T0031.a). Düzeltildi: tests/docs Task'ın birincil lane'inde kalır; claim yine yol bazında.
3. Founder karar Task'ları (UASCO-T0113, T0082) Feature modül varsayılanıyla repo dosyası 'tutuyordu' (S3'te 1 sahte çakışma). Düzeltildi: hedef EXT:Founder kararı; Founder Task'ları claim tutmaz.
4. Dispatch önceliği kritik yolu ikinci sıraya atıyordu. Düzeltildi: öncelik R1 → en uzun kalan zincir.

## Kalan açık noktalar (hazır olma hükmünü etkileyenler)

- Windows'ta `verify.py` NOT_RUN (ortam yok).
- Founder-PC ortamı UNKNOWN (11_* komutları çalıştırılmadı). Bu durum READY'nin değil Windows kabulünün kapısıdır.
- Bağımsız reviewer sonucu: 15_INDEPENDENT_REVIEW.md.
