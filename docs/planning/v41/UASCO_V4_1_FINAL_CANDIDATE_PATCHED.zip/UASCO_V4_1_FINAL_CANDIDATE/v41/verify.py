#!/usr/bin/env python3
"""V4.1 paket doğrulaması (salt-okur; Linux/macOS/Windows). Kullanım: paket kökünde `python3 v41/verify.py` (Windows: `py -3 v41\\verify.py`)."""
import hashlib, json, os, subprocess, sys, tempfile, filecmp
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); ok = True
def h(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def fail(m):
    global ok; ok = False; print("FAIL", m)
man = os.path.join(ROOT, "SHA256_MANIFEST.txt"); n = 0
for line in open(man, encoding="utf-8"):
    if not line.strip(): continue
    d, p = line.split("  ", 1); p = p.strip(); n += 1
    q = os.path.join(ROOT, *p.split("/"))
    if not os.path.exists(q) or h(q) != d: fail("manifest " + p)
print(f"manifest: {n} girdi kontrol edildi")
tmp = tempfile.mkdtemp(prefix="v41verify_"); env = dict(os.environ, V41_PACKAGE_ROOT=ROOT, PYTHONHASHSEED="11")
for s in ("build.py", "docs.py"):
    r = subprocess.run([sys.executable, os.path.join(ROOT, "v41", s), tmp], env=env, capture_output=True, text=True, cwd=os.path.join(ROOT, "v41"))
    if r.returncode: fail(f"{s} exit {r.returncode}: {r.stderr[-400:]}")
gen = sorted(os.listdir(tmp)); diff = [f for f in gen if not os.path.exists(os.path.join(ROOT, f)) or not filecmp.cmp(os.path.join(tmp, f), os.path.join(ROOT, f), shallow=False)]
print(f"yeniden üretim: {len(gen)} dosya, farklı: {diff if diff else 0}")
if diff: fail("regeneration differs")
S = json.load(open(os.path.join(tmp, "_summary.json"), encoding="utf-8"))
M = json.load(open(os.path.join(tmp, "02_V4_1_EXECUTION_MATRIX.json"), encoding="utf-8"))
D = json.load(open(os.path.join(tmp, "06_V4_1_FOUNDER_DECISION_CENTER.json"), encoding="utf-8"))
feats = {t['v3Feature'] for t in M['tasks']}
checks = {"base175 present": S['base175'] == 175, "records==175+EXnew+splitChildren": len(M['tasks']) == 175 + len(S['exNew']) + S['exSplitChildren'], "features==57": len(feats) == 57, "decisions==31": len(D['decisions']) == 31,
          "acSpec==102": S['evidence']['EVIDENCE_SPEC_COUNT'] == 102, "errors==0": not S['errors'], "selftests": all(x[1] for x in S['selftest'])}
neg = S['sim'].get('NEGATIVE_TESTS', {})
checks["NEG claims-off detected"] = neg.get('NEG_CLAIMS_DISABLED', {}).get('independentAuditConflicts', 0) > 0
checks["NEG lock-off detected"] = neg.get('NEG_LOCK_DISABLED', {}).get('lockViolations', 0) > 0
for k, v in S['sim'].items():
    if k in ("S0_NO_DECISION", "NEGATIVE_TESTS"): continue
    checks[f"{k}.auditConflicts==0"] = not v['independentAuditConflicts']; checks[f"{k}.gateBypass==0"] = not v['gateBypass']
    checks[f"{k}.lock/freeze==0"] = not v['lockViolations'] and not v['headFreezeViolations'] and not v['lockHeldAtEnd']
    checks[f"{k}.deadlocks==0"] = not v['deadlocks']; checks[f"{k}.writeConflicts==0"] = v['writeConflicts'] == 0; checks[f"{k}.slots<=limit"] = v['maxSlotsUsed'] <= v['slots']
checks["S3.complete"] = S['sim']['S3_ALL_DECISIONS_FOUNDER_ENV']['incomplete'] == 0
checks["S6.kit-failure repaired & complete"] = S['sim']['S6_KIT_FAILS_ONCE_THEN_PASSES']['incomplete'] == 0 and len(S['sim']['S6_KIT_FAILS_ONCE_THEN_PASSES']['kitFailures']) == 1
checks["S8 founder-busy: 0 aborts, complete"] = not S['sim']['S8_FOUNDER_TASKS_LONG']['lockAborts'] and S['sim']['S8_FOUNDER_TASKS_LONG']['incomplete'] == 0
checks["S9 founder gone: lock released"] = bool(S['sim']['S9_FOUNDER_GONE_AFTER_LOCK']['lockAborts']) and not S['sim']['S9_FOUNDER_GONE_AFTER_LOCK']['lockHeldAtEnd']
checks["S5/S7 escalation released"] = all('PR-231' in S['sim'][k]['escalated'] and not S['sim'][k]['lockHeldAtEnd'] for k in ('S5_KIT_EXCEEDS_LOCK_TIMEOUT', 'S7_KIT_FAILS_TWICE'))
for k, v in checks.items():
    print(("PASS " if v else "FAIL ") + k)
    if not v: ok = False
print("SONUÇ:", "PASS" if ok else "FAIL"); sys.exit(0 if ok else 1)
