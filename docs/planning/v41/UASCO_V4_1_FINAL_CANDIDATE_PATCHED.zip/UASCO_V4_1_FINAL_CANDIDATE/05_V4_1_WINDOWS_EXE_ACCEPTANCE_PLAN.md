# 05 — Windows `.exe` Teslim ve Kabul Planı (patch EX-04, EX-08)

> Bir aşamanın kanıtı diğerinin yerine geçmez. Gerçek ortam yoksa NOT_RUN_ENV_UNAVAILABLE. CI installer PASS kullanıcı kabulü değildir.

## 1. Kanıt ↔ SHA bağlama kuralları (EX-04)

1. **Kabul kiti (`founder-acceptance.mjs`) `git HEAD`'e bağlıdır.** Temiz checkout ve `npm ci` gerektirir (kit README; #231).
2. **Sıra:** T0031 (kod) → T0031.b (server.ts) → **T0069.c (reseal commit = son commit)** → **T0031.c: Founder, PR #231'in o anki head SHA'sını temiz checkout eder ve kiti çalıştırır** → merge.
3. **T0031.c'den sonra PR dalına commit atılmaz.** Atılırsa (rebase ya da düzeltme dahil) T0031.c geçersizdir ve kit yeniden koşulur. Merge öncesi supervisor şunu doğrular: `kit.sha == PR head SHA`.
4. **Merge commit ≠ PR head.** Kit kanıtı PR head kaynağı içindir. Merge sonrası:
   - **V4-T0001.a** merge commit'inin installer'ını toplar (`.exe` SHA + kaynak merge SHA).
   - **T0002.a** bu installer'la yeniden kurulum yapar.
   - R1 koşuları (T0029 …) bu kurulu build üzerinde yapılır.
   - Eşleme kanıtı: merge commit'in ikinci ebeveyni (parent2) = kabul edilen PR head SHA'sı. Ağaç da merge-tree ile aynı olmalı; ledger bunu zaten kontrol ediyor (rapor M.2).
5. **R1 installer'ı bütün R1 kod Task'larını içerir:** V4-T0001.a, R1 kod Task'larının hepsi MERGED olmadan başlamaz (build betiği bu bağımlılıkları ekliyor).

## 2. Aşamalar

| Aşama | Sorumlu | Ortam | Yöntem | Kanıt | Başarısızlıkta |
| --- | --- | --- | --- | --- | --- |
| BUILD_OK | E (deterministik) | Actions | Push CI sonucu | run id + headSha | Merge durur |
| INSTALLER_OK | E (V4-T0001 / V4-T0001.a) | Actions windows-latest | Installer workflow + smoke (job log'u) | `.exe` adı, boyutu, sha256, kaynak SHA | D lane |
| WINDOWS_INSTALL_VERIFIED | Founder (UASCO-T0002, sonra T0002.a) | Founder-PC | Kontrol listesi (V3-T1019) | JSON + ekran görüntüsü; installer sha256 = V4-T0001(.a) SHA | A/D Task'ı |
| FRONTEND_API_VERIFIED | Founder + A_UI | Founder-PC (+ ara kanıt: windows-latest E2E UASCO-T0095) | Ekran aksiyonu → `/v1` yanıtı | Ekran → route → yanıt kaydı | A Task'ı |
| REAL_AI_EXECUTION_VERIFIED | Founder | Founder-PC (native claude.exe, login) | Gerçek pre-dev | Artifact hash'leri; kullanım ya da UNKNOWN | T0061.a akışı (D-29) |
| SANDBOX_VERIFIED | Founder (T0031.c) | Founder-PC WSL2 | Kabul kiti, **son PR head'inde** | Kit JSON'u (head SHA'ya bağlı) | Kitin yazdığı komutlar; C Task'ı |
| TEST_ACCEPTED | Founder | Founder-PC, merge sonrası installer | 3 ardışık run; tohumlanmış hata remediation ile düzeltilir | V3-EV-F012-2, F019-2 | Sonnet → Opus |
| SECURITY_ACCEPTED | Founder + UASCO | Founder-PC | SEC-PROFILE-R1 (gitleaks + trivy, sabit sürüm) | security-report + araç hash'leri. PARTIAL → DELIVERED_SECURITY_PARTIAL | D-19 |
| DELIVERY_ACCEPTED | Founder + script | Founder-PC + temiz dizin | Export sha256 + `npm ci && npm test` (şablon kilit dosyası) | V3-EV-F005-1, F057-1/2 | A / B / C |
| FOUNDER_ACCEPTED | Founder | Founder-PC | SOURCE_DELIVERY_ACCEPTED + R1 demo | V3-EV-F015-1, F004-1 | İlgili aşama |

## 3. Founder-PC gereksinimleri

Ayrıntı ve salt-okur kontrol komutları: 11_FOUNDER_PC_READONLY_DIAGNOSTIC.md. Windows 11 dayatılmaz; D-26 teşhisten sonra verilir.

## 4. İlk gerçek `.exe` tesliminin kabul şartları (R1)

1. PR-231 merge edildi; merge commit parent2 = kit'in kabul ettiği head SHA'sı.
2. V4-T0001.a installer'ı (bütün R1 kodu MERGED) Founder-PC'ye kuruldu (T0002.a).
3. 10 aşamanın her biri ayrı kanıtla geçti.
4. İki proje tipi, 3 ardışık run.
5. SECURITY PARTIAL ise etiket VERIFIED olmaz.
6. Bağımsız yeniden üretim PASS.
7. Elle düzenleme 0.
8. STOP ve sağlayıcı hatası negatifleri geçti.
9. R1 kapısı: 45 kabul AC'si. 7 izleme AC'si R1'i bloke etmez, STABLE durumuna sayılır.
