# 07 — Uzlaştırma: G-01..G-21 · X-01..X-16 · B1–B8

(EX-01..EX-10 kapanışı ayrı: 12_EX_FINDINGS_CLOSURE.md)

| ID | Önem | Başlık | Karar | Task | Değişiklik | Founder | B |
|---|---|---|---|---|---|---|---|
| G-01 | CRITICAL | W0/W1 Windows kabul yürütücüsü tanımsız | ACCEPTED | UASCO-T0002, V3-T1019, V4-T0001, T0014, T0029, T0035 | W0 iki parçaya ayrıldı: V4-T0001 deterministik (BUILD_OK/INSTALLER_OK), UASCO-T0002 Founder (WINDOWS_INSTALL_VERIFIED). CI smoke hiçbir zaman kurulum kabulü sayılmaz. | D-23, D-26 | B8 |
| G-02 | HIGH | WSL2 kullanıcı ön koşulları için Task yok | ACCEPTED_MODIFIED | UASCO-T0031.a | Yeni alt Task; ayrı UASCO dağıtımı önerisi eklendi (interop kapatma Founder'ın diğer WSL kullanımını etkiler) | D-03 | B7 |
| G-03 | HIGH | Export bağımlılığı yanlış; kök neden main.mjs:273 | ACCEPTED | UASCO-T0016 | dependsOn T0069 kaldırıldı; kapı D-31 | D-31 | — |
| G-04 | HIGH | #231: 173 commit geride, korumalı dosya, owner çakışması | ACCEPTED | UASCO-T0031 | Sandbox kodu C_ENGINE (T0031), server.ts bağlaması B_API (T0031.b), manifest reseal + merge D_CI_RELEASE (T0069.c); aynı PR dalında sıralı devir | D-03, D-07, D-31 | B7 |
| G-05 | HIGH | Lane dosya sahipliği çakışması | ACCEPTED | Tüm kod Task'ları | OWNER_BY_PATH tablosu; build betiği aynı dalgada aynı dosyaya iki lane yazmasını reddeder | — | — |
| G-06 | HIGH | W1'de 5 lane aktif | ACCEPTED_MODIFIED | — | Lane = sahiplik, slot = eşzamanlılık: en fazla 3 kodlama slotu; E ve Founder slot kullanmaz; D slot sırasına girer | — | — |
| G-07 | HIGH | Feature bazlı dalga ataması R1 Task'larını geciktiriyor | ACCEPTED | UASCO-T0115, T0119, T0120, V3-T1005, V3-T1006, V3-T1018 | Dalga Task bazında hesaplanır; bağımlılık tersliği 0 olana kadar öncül öne çekilir | — | — |
| G-08 | HIGH | npm ci kilit dosyası olmadan başarısız | ACCEPTED | V3-T1012.a, V3-T1012 | Şablonlara kilit dosyası + teslim kuralı | — | — |
| G-09 | HIGH | Launcher hash pin'i ↔ otomatik güncelleme | NEEDS_VERIFICATION | UASCO-T0061.a | Senaryo testi + Founder-PC gözlemi | D-29 | — |
| G-10 | HIGH | Kota ölçümü yok | ACCEPTED_MODIFIED | UASCO-T0110 | W0'a alındı; yüzde yerine Founder bütçesi + USAGE_LIMIT olayları | D-08 | — |
| G-11 | MEDIUM | RunAsNode fuse AC'si backend'i bozar (V3.1 hatası) | ACCEPTED | UASCO-T0023.a, T0023 | Ön Task + AC notu | D-27 | — |
| G-12 | MEDIUM | Artifact 30 gün; .exe SHA bilinmiyor | ACCEPTED | V4-T0001 | Deterministik toplama | D-30 | — |
| G-13 | MEDIUM | Siyah/kırmızı/beyaz tasarım sistemi kaynaksız | ACCEPTED | — (Task eklenmedi) | Karar gelene kadar kapsam dışı | D-25 | — |
| G-14 | MEDIUM | Review yolu ikiye ayrık; IR token reddi | ACCEPTED | V3-T1034, UASCO-T0098 | Tek yetkili yol: taze alt ajan reviewer + ledger; tier'a göre model | D-21 | B4 |
| G-15 | MEDIUM | V3.1 kayıtları icraya verilmemiş | ACCEPTED | Hepsi | V3.1 kayıtları pakette (sources/v31); Execution yalnız hash kontrolü yapar | D-24 | — |
| G-16 | MEDIUM | Sandbox'ta müşteri bağımlılığı politikası yok | ACCEPTED | UASCO-T0037, T0040 | Kapı D-28 | D-28 | — |
| G-17 | LOW | #247 önceliği abartılmış | ACCEPTED | UASCO-T0100.a | Ayrı alt Task UASCO-T0100.a (gating değil) | D-07 | B7 |
| G-18 | MEDIUM | Merge queue kullanılabilirliği doğrulanmadı | NEEDS_VERIFICATION | V3-T1008, V3-T1020 | W0'da seri kural; W2 öncesi D-04 | D-04 | B6 |
| G-19 | MEDIUM | Uzun çalışma: journal büyümesi, run başına pause yok | ACCEPTED_MODIFIED | UASCO-T0049 | W2'de; ölçüm EV alanı olarak (yeni Task yok) | — | — |
| G-20 | MEDIUM | Yerel V6 UNKNOWN | ACCEPTED | V4-T0002 | Founder kontrol Task'ı | D-12 | B8 |
| G-21 | LOW | Ekran sayacı tanımsız | ACCEPTED | — | Sayaç = DS-* senaryolarında kullanılan route'lar | — | — |

| X | Başlık | Karar | G | Uygulanış |
|---|---|---|---|---|
| X-01 | Dalgayı Task'a taşı | ACCEPTED | G-07 | build betiği: task wave + fixpoint |
| X-02 | Export bağımlılığı | ACCEPTED | G-03 | UASCO-T0016 deps=[]; kapı D-31 |
| X-03 | RW-006'yı böl | ACCEPTED_MODIFIED | G-03, G-04 | T0069.a/.b; değişiklik: W1 boyunca korumasız güvenlik dosyaları (runner, execution-gate, security-tools, sandbox, claude-profiles) için review modeli Opus (koruma gelene kadar telafi) |
| X-04 | #231 tek owner + T0031.a | ACCEPTED | G-02, G-04 | C/B/D sıralı devir: T0031 → T0031.b → T0069.c |
| X-05 | W0 deterministik + Founder | ACCEPTED_MODIFIED | G-01, G-12 | V4-T0001 (deterministik) + UASCO-T0002 (Founder; yeni W0-c Task'ı yaratılmadı, mevcut Task kullanıldı) |
| X-06 | npm ci kilit dosyası | ACCEPTED | G-08 | V3-T1012.a (VERIFIED) |
| X-07 | Sahiplik tablosu + 3 slot | ACCEPTED | G-05, G-06 | OWNER_BY_PATH; çakışma kontrolü build'de |
| X-08 | Store-lock'ta Opus'u atla | ACCEPTED | — | V3-T1001 Sonnet; Opus yalnız 2 başarısız denemeden sonra |
| X-09 | Launcher değişimi | ACCEPTED | G-09 | UASCO-T0061.a |
| X-10 | Kota korumasını W0'a | ACCEPTED | G-10 | UASCO-T0110 W0 |
| X-11 | RunAsNode AC | ACCEPTED | G-11 | UASCO-T0023.a |
| X-12 | Deterministik reconcile | ACCEPTED | G-15 | Başlangıç talimatı adım 2 |
| X-13 | Tek review yolu + patch-id cache | ACCEPTED | G-14 | Model/lane matrisi review sütunu |
| X-14 | Paketlemeyi ajan yapmasın | ACCEPTED | G-12 | V4-T0001 her dalga sonunda yeniden kullanılır |
| X-15 | #247'yi kritik yoldan çıkar | ACCEPTED | G-17 | UASCO-T0100.a, gating değil |
| X-16 | Şemada tek seferlik Opus | ACCEPTED | — | V3-T1022 opus→sonnet |

| B | Blokaj | Feature | Task | Karar | Plan |
|---|---|---|---|---|---|
| B1 | #282 DEFER_TO_ROADMAP (store.ts withLock ölçümü; Windows'ta 2 farklı test kırmızı) | V3-F038 | UASCO-T0090, V3-T1001, UASCO-T0088 | D-22 | DEFER korunur; otomatik yeniden koşu yok. Yeniden değerlendirme: V3-T1001 merge edildikten sonra, aynı head'de 3 ardışık tam yeşil Windows koşusu + base kontrol koşusu. Ölçümün Windows zamanlamasına etkisi dışlanamadığı için V3-T1001 #282 diff'ini yalnız teşhis girdisi olarak okur; store.ts tek owner C_ENGINE. |
| B2 | Windows shard kararsızlığı (F-B1-006, relfx-c3:200, relfx-1:459, role-context:826) | V3-F038 | V3-T1001, UASCO-T0088 | D-20 | Store-lock düzeltmesi (C_ENGINE) + deterministik test ve karantina (D_CI_RELEASE testleri). Kabul: 20 ardışık base push'ta bilinen-flake kırmızısı 0. |
| B3 | COORD-001: 'Re-run failed jobs' aggregator'ı yeşile çeviremiyor | V3-F054 | V3-T1002, V3-T1003, V3-T1036 | D-18, D-31 | #251 temel alınır; provenance kuralları; merge T2 (ci.yml, validate-shards.mjs korumalı). Ara kural: yalnız 'Re-run all jobs'. |
| B4 | IR reviewer token reddi (REVIEWER_AUTH_REJECTED) | V3-F042 | V3-T1034, UASCO-T0098 | D-21 | Founder secret işlemi ya da IR'ı resmen opsiyonel yapmak; o zamana kadar tek yetkili yol: taze alt ajan reviewer + ledger. FA-8 (39687649214 waiting) aynı kararla iptal/red. |
| B5 | Ledger ↔ Founder environment onayı senkron değil | V3-F053 | V3-T1004 | D-06 | API'den okunan founder-authority kaydı; o zamana kadar T2 PR'larında Founder manuel merge. |
| B6 | Aynı dosyaya dokunan PR'lar birleşik CI olmadan merge oluyor | V3-F052 | V3-T1008, V3-T1020 | D-04, D-17 | W0'da seri merge kuralı (V3-T1008); W2'den önce merge queue ya da zorunlu up-to-date (D-04). |
| B7 | Founder-tier: #251/#247/#231 manifest çakışması; #231 Windows 11/WSL2 kabulü; #66 ortak geçmişsiz | V3-F030, V3-F013, V3-F041 | UASCO-T0100, UASCO-T0069.a, UASCO-T0031, UASCO-T0031.a, UASCO-T0096 | D-07, D-31, D-03, D-11 | Merge planı §5 (batch 1: #251→#247; batch 2: #231 FA-5 sonrası; #66 SUPERSEDED önerisi). |
| B8 | Founder-PC: V6 Supervisor, Task Scheduler, yerel worker UNKNOWN | V3-F047, V3-F045 | V4-T0002 | D-12 | Founder PowerShell kontrolü; W1 paralel lane'leri açılmadan. |
