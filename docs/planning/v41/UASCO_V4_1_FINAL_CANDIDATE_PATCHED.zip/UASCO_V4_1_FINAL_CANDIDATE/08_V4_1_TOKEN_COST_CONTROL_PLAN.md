# 08 — Token ve Maliyet Kontrol Planı

> ESTIMATE; ölçülmüş tasarruf yok.

## Model dağılımı (açık Task)

- FOUNDER (model yok): 24 Task, 40–114 h
- sonnet: 127 Task, 1574–4189 h
- deterministic: 9 Task, 16–36 h
- opus→sonnet: 6 Task, 120–320 h
- haiku: 1 Task, 1–3 h

## Kurallar

- **Bütçe ve kota:** D-08 bütçesi + UASCO-T0110 USAGE_LIMIT koruması; ölçüm UASCO-T0111.
- **Uzlaştırma:** yalnız `v41/verify.py` (deterministik); LLM ile yeniden üretim yok.
- **Keşif:** Task başına ≤10 sembol; tüm repo okunmaz.
- **Review:** tier'a göre model; patch-id cache; base-merge'de yeniden review yok; IR yeniden koşturulmaz.
- **CI:** draft PR'da yalnız L0; Windows shard'ları yalnız Windows'a duyarlı yollarda; "Re-run failed jobs" yok; post-merge CI yalnız ağaç farklıysa.
- **Paketleme:** ajan değil V4-T0001 / V4-T0001.a.
- **Retry:** aynı fingerprint için 1.
- **Supervisor:** kısa ömürlü; olay güdümlü; saatlik tick yok.
- **İzleme ölçütleri (EX-09)** ayrı izlenir. İlk kod kabulünü bekletmedikleri için gereksiz yeniden koşu ve bekleme maliyeti doğmaz.

## Maliyet metrikleri

Accepted Feature başına maliyet · kullanılabilir teslim başına maliyet (R1'de ölçülür) · $/merged PR (ikincil) · kota duruş saati.
