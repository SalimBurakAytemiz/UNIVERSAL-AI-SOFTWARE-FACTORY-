#!/usr/bin/env python3
"""V4.1 paket doğrulaması (salt-okur; Linux/macOS/Windows). Kullanım: paket kökünde `python3 v41/verify.py` (Windows: `py -3 v41\\verify.py`)."""
import hashlib, json, os, subprocess, sys, tempfile, filecmp
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); ok = True
def h(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def fail(m):
    global ok; ok = False; print("FAIL", m)
man = os.path.join(ROOT, "SHA256_MANIFEST.txt"); n = 0
for line in open(man, encoding="utf-8"):
    if not line.strip(): continue
    d, p = line.split("  ", 1); p = p.strip(); n += 1
    q = os.path.join(ROOT, *p.split("/"))
    if not os.path.exists(q) or h(q) != d: fail("manifest " + p)
print(f"manifest: {n} girdi kontrol edildi")
tmp = tempfile.mkdtemp(prefix="v41verify_"); env = dict(os.environ, V41_PACKAGE_ROOT=ROOT, PYTHONHASHSEED="11")
for s in ("build.py", "docs.py"):
    r = subprocess.run([sys.executable, os.path.join(ROOT, "v41", s), tmp], env=env, capture_output=True, text=True, cwd=os.path.join(ROOT, "v41"))
    if r.returncode: fail(f"{s} exit {r.returncode}: {r.stderr[-400:]}")
gen = sorted(os.listdir(tmp)); diff = [f for f in gen if not os.path.exists(os.path.join(ROOT, f)) or not filecmp.cmp(os.path.join(tmp, f), os.path.join(ROOT, f), shallow=False)]
print(f"yeniden üretim: {len(gen)} dosya, farklı: {diff if diff else 0}")
if diff: fail("regeneration differs")
S = json.load(open(os.path.join(tmp, "_summary.json"), encoding="utf-8"))
M = json.load(open(os.path.join(tmp, "02_V4_1_EXECUTION_MATRIX.json"), encoding="utf-8"))
D = json.load(open(os.path.join(tmp, "06_V4_1_FOUNDER_DECISION_CENTER.json"), encoding="utf-8"))
feats = {t['v3Feature'] for t in M['tasks']}
checks = {"base175 present": S['base175'] == 175, "records==175+EXnew+splitChildren+cloudNew": len(M['tasks']) == 175 + len(S['exNew']) + S['exSplitChildren'] + len(S.get('cloudNew', [])), "features==57": len(feats) == 57, "decisions==31": len(D['decisions']) == 31,
          "acSpec==102": S['evidence']['EVIDENCE_SPEC_COUNT'] == 102, "errors==0": not S['errors'], "selftests": all(x[1] for x in S['selftest'])}
neg = S['sim'].get('NEGATIVE_TESTS', {})
checks["NEG claims-off detected"] = neg.get('NEG_CLAIMS_DISABLED', {}).get('independentAuditConflicts', 0) > 0
checks["NEG lock-off detected"] = neg.get('NEG_LOCK_DISABLED', {}).get('lockViolations', 0) > 0
for k, v in S['sim'].items():
    if k in ("S0_NO_DECISION", "NEGATIVE_TESTS"): continue
    checks[f"{k}.auditConflicts==0"] = not v['independentAuditConflicts']; checks[f"{k}.gateBypass==0"] = not v['gateBypass']
    checks[f"{k}.lock/freeze==0"] = not v['lockViolations'] and not v['headFreezeViolations'] and not v['lockHeldAtEnd']
    checks[f"{k}.deadlocks==0"] = not v['deadlocks']; checks[f"{k}.writeConflicts==0"] = v['writeConflicts'] == 0; checks[f"{k}.slots<=limit"] = v['maxSlotsUsed'] <= v['slots']
checks["S3.complete"] = S['sim']['S3_ALL_DECISIONS_FOUNDER_ENV']['incomplete'] == 0
checks["S6.kit-failure repaired & complete"] = S['sim']['S6_KIT_FAILS_ONCE_THEN_PASSES']['incomplete'] == 0 and len(S['sim']['S6_KIT_FAILS_ONCE_THEN_PASSES']['kitFailures']) == 1
checks["S8 founder-busy: 0 aborts, complete"] = not S['sim']['S8_FOUNDER_TASKS_LONG']['lockAborts'] and S['sim']['S8_FOUNDER_TASKS_LONG']['incomplete'] == 0
checks["S9 founder gone: lock released"] = bool(S['sim']['S9_FOUNDER_GONE_AFTER_LOCK']['lockAborts']) and not S['sim']['S9_FOUNDER_GONE_AFTER_LOCK']['lockHeldAtEnd']
checks["S5/S7 escalation released"] = all('PR-231' in S['sim'][k]['escalated'] and not S['sim'][k]['lockHeldAtEnd'] for k in ('S5_KIT_EXCEEDS_LOCK_TIMEOUT', 'S7_KIT_FAILS_TWICE'))
# ---- cloud-only birleştirme kontrolleri (CO-1..CO-11)
B = json.load(open(os.path.join(ROOT, "sources", "v41_patched", "02_V4_1_EXECUTION_MATRIX.json"), encoding="utf-8")); BT = {t['id']: t for t in B['tasks']}
BD = json.load(open(os.path.join(ROOT, "sources", "v41_patched", "06_V4_1_FOUNDER_DECISION_CENTER.json"), encoding="utf-8"))
CM = json.load(open(os.path.join(ROOT, "sources", "cloud", "CLOUD_ONLY_CHANGE_MATRIX.json"), encoding="utf-8"))
AM = json.load(open(os.path.join(ROOT, "sources", "v31", "V3_ACCEPTANCE_EVIDENCE_MATRIX.json"), encoding="utf-8"))
T = {t['id']: t for t in M['tasks']}; R = {"T0": 0, "T1": 1, "T2": 2, "T3": 3}; OPEN = lambda t: t['v31Status'] not in ("ASSET_DONE", "ASSET_CODED_UNWIRED", "DONE_OBSERVED", "SPLIT")
cloud_ids = [t['id'] for t in CM['newTasks']]; bundles = M['meta']['bundles']; uat = ("UASCO-T0002", "UASCO-T0002.a")
refs = [d[0] for t in M['tasks'] for d in t['deps']] + [m for b in bundles.values() for m in b['members'] + b['preconditions']] + [x for d in D['decisions'] for x in d['gatedTasks']]
checks["CO PATCHED base==241"] = len(BT) == 241
checks["CO-1 all 241 PATCHED ids preserved"] = set(BT) <= set(T)
checks["CO-1 15 CLOUD-T added"] = len(cloud_ids) == 15 and all(c in T for c in cloud_ids) and sorted(S['cloudNew']) == sorted(cloud_ids)
checks["CO all Task ID refs resolve"] = all(r in T for r in refs)
checks["CO-2 no tier downgrade vs PATCHED"] = all(R[T[k]['authorityTier']] >= R[b['authorityTier']] for k, b in BT.items() if b['authorityTier'] in R)
checks["CO-3 no gate removed vs PATCHED"] = all(set(b['startGates'] + b['mergeGates']) <= set(T[k]['startGates'] + T[k]['mergeGates']) for k, b in BT.items())
checks["CO T2 sensitive paths (protected/authority/security ⇒ ≥T2)"] = all(R[t['authorityTier']] >= 2 for t in M['tasks'] if OPEN(t) and (t['protectedFiles'] or t['authorityFiles'] or t['securitySensitive']))
checks["CO-9 decisions: same 31 ids as PATCHED"] = sorted(d['id'] for d in D['decisions']) == sorted(d['id'] for d in BD['decisions'])
checks["CO-8 AC overrides refer to the 102 AC ids"] = all(a['acId'] in {r['acId'] for r in AM['rows']} for a in CM['acceptanceOverrides']) and len(AM['rows']) == 102
checks["CO-8 evidence PASS counter == 0"] = S['evidence']['EVIDENCE_VERIFIED_PASS_COUNT'] == 0
checks["CO-6 Founder-PC only for .exe UAT"] = all(k in uat for k, t in T.items() if OPEN(t) and any(f.startswith("EXT:Founder-PC") for f in t['targetFiles']))
checks["CO-6 UAT after cloud e2e CI + hosted installer"] = all({"CLOUD-T0011", "CLOUD-T0006"} <= {d[0] for d in T[u]['deps']} for u in uat)
checks["CO-4 PR-231 DO_NOT_MERGE_AS_IS + D-03/D-07"] = all(T[m].get('cloudOnlyStatus', "").startswith("DO_NOT_MERGE_AS_IS") and {"D-03", "D-07"} <= set(T[m]['mergeGates']) for m in bundles['PR-231']['members'])
checks["CO-7 reseal lock 24h / pre-kit 8h kept"] = bundles['PR-231']['lockTimeoutH'] == 24 and bundles['PR-231']['lockPrekitTimeoutH'] == 8 and bundles['PR-231']['lock']
checks["CO slots: 1 without D-12, ≤3 with"] = S['sim']['S1_D01_ONLY']['maxSlotsUsed'] <= 1 and all(v.get('maxSlotsUsed', 0) <= 3 for v in S['sim'].values())
checks["CO no open WSL target outside frozen PR-231"] = not [k for k, t in T.items() if OPEN(t) and not t['bundle'] == "PR-231" and any("wsl" in f.lower() for f in t['targetFiles'])]
checks["CO status not PRODUCT_READY"] = "PRODUCT_READY" not in M['meta']['status']
for k, v in checks.items():
    print(("PASS " if v else "FAIL ") + k)
    if not v: ok = False
print("SONUÇ:", "PASS" if ok else "FAIL"); sys.exit(0 if ok else 1)
