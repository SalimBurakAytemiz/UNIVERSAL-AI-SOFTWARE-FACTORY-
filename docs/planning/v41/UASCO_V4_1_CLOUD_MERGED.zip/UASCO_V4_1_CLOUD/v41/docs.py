import json, os, sys, collections
OUT = sys.argv[1]
S = json.load(open(f"{OUT}/_summary.json")); M = json.load(open(f"{OUT}/02_V4_1_EXECUTION_MATRIX.json")); T = {t['id']: t for t in M['tasks']}
SIM = json.load(open(f"{OUT}/13_V4_1_DISPATCH_SIMULATION.json"))['scenarios']
W, cp, r1, ev = S['waveEff'], S['cp'], S['r1'], S['evidence']
f = lambda a: f"{a[0]:.0f}–{a[1]:.0f}"; jn = lambda x: ", ".join(x) if x else "—"
CP = " → ".join(cp['chain'])
s1, s2, s3 = SIM['S1_D01_ONLY']['summary'], SIM['S2_D01_GROUP1_NO_FOUNDER_ENV']['summary'], SIM['S3_ALL_DECISIONS_FOUNDER_ENV']['summary']
log3 = SIM['S3_ALL_DECISIONS_FOUNDER_ENV']['log']
r1_done = next((x[0] for x in log3 if x[1] == "done" and x[2] == "UASCO-T0035"), None)
slots2 = [k for k in s2['startedFirst'] if T[k]['slotRequired']][:6]
nonslot2 = [k for k in s2['startedFirst'] if not T[k]['slotRequired']]
G1 = ["D-23", "D-31", "D-03", "D-07", "D-12", "D-08", "D-18", "D-26"]
CMD_LX = "cd <paket-kökü> && python3 v41/verify.py"
CMD_WIN = "cd <paket-kökü>; py -3 v41\\verify.py   # ya da: python v41\\verify.py"
STATES_TXT = "PLANNED → CODING → CODE_READY → REVIEWED → MERGED (kod) · ACCEPTED (Founder kabul) · DONE (karar / deterministik kayıt)"
# ---------------------------------------------------------------- 01
R = f"""# UASCO MASTER EXECUTION ROADMAP V4.1 — FINAL CANDIDATE (patch EX-01..EX-10 + CLOUD-ONLY)

> **CLOUD-ONLY (2026-11-02, Founder yönergesi; birleştirme kuralları CO-1..CO-10: 17_CLOUD_ONLY_MERGE_REPORT.md).** Bütün geliştirme, model, test, güvenlik, sandbox, CI ve teslim bulutta yürür. Founder-PC yalnız imzalı/hash doğrulanmış `.exe`'nin kur/aç/kullan son kullanıcı kabulü (UASCO-T0002, T0002.a) içindir; BIOS/WSL/VM/Node/Claude CLI/yerel worker şartı yoktur. #231 (WSL2) AS-IS merge edilmez (D-07). Bulut sandbox/worker sağlayıcısı (D-03) verilmedikçe çalışma zamanı UNKNOWN: paket en fazla READY_FOR_CODING'dir, PRODUCT_READY değildir. UAT'tan önce cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS zorunludur.

| Alan | Değer |
| --- | --- |
| Durum | **FINAL CANDIDATE — yürürlükte değil.** D-01 olmadan Execution başlamaz ve repo'ya yazılmaz. Bu oturumda kod, commit, PR, merge, CI ve otomasyon yok. |
| Tür | V4'ün uygulanabilirlik revizyonu + bağımsız derin denetimin EX-01..EX-10 patch'i. Yeni roadmap değil. |
| Temel | `v7/integration` @ 16d3a925 · CI 41434581692 ve Windows Installer 41434581581 SUCCESS · artifact 13135209964 (ZIP digest c44e21bf…, son tarih 2026-12-02) — VERIFIED |
| Kanonik kapanış | `uasco/production-reports` @ 770c5513 · ledger @ 122a1b12 — VERIFIED |
| Açık PR'lar | #282 (DEFER), #251, #247, #231, #66 — VERIFIED. Gerçek değişen dosyalar: #231 42 · #251 4 · #247 3 · #282 8 (`git diff --name-only merge-base…head`) |
| Rutinler / yerel | 0/11 etkin CLAIMED · yerel V6 UNKNOWN |
| Tek veri kaynağı | `v41/source.py` + `patch_ex.py` + `decisions.py` + `recon.py` + `sim.py` + `sources/*` → `build.py` + `docs.py` |

## 1. V4'ten ve önceki V4.1'den korunanlar

Beş ilke, execution packet şeması, W0–W5 dalgaları, lane'ler, model aileleri, G/X/B uzlaştırması, tek retry kuralı, kısa rapor biçimi.

## 2. Bu patch'te değişenler (ayrıntı: 12_EX_FINDINGS_CLOSURE.md)

- **Tipli durumlar ve bağımlılıklar (EX-01):** {STATES_TXT}. Her bağımlılık `Task:DURUM` biçiminde. PR paketleri tanımlı: PR-251, PR-231 (merge ön koşulu: Founder kabul kiti), PR-247.
- **Yetki sınıflandırması (EX-02 + bağımsız review R-S1..S5):**
  - `NEW:`/`PR231:` yolları normalize edilir. Korumalı dosya içeren klasör hedefleri korumalı sayılır.
  - T2 (fail-closed) kapsamı: `config/`, `.github/`, `scripts/validate-*`, `scripts/ci/`, `automation/lib/`, `schemas/`, `prompts/`, `.ai/`, `docs/acceptance/`, docs altındaki çalıştırılabilir dosyalar, `docs/routines/`, `docs/planning/dispatch.mjs`, tedarik zinciri (package.json, lock, `.npmrc`), release (`scripts/build-installer.mjs`, `installer/`), ücretli model yönlendirmesi (`core/policy/`, `models/router/`, `models/omniroute/`), supervisor araçları, coord-ledger, GitHub ayarları.
  - Güvenlik uygulayan kod da T2: execution-gate, sandbox, runner, executors, claude-profiles, security-tools, secret-scan, test-surface, action-gateway, preload, devrun.
  - Register'a yalnız deterministik araç yazar (CI'sız); LLM yazmaz.
  - Mühürlü (trust-root) dosyaya dokunan her Task'ın write set'ine manifest eklenir ve aynı PR'da D lane reseal'i yapar.
- **Gerçek write set'ler (EX-03):** PR paketlerinin dosyaları gerçek changed-files listelerinden geliyor. Karma owner'lı 16 Task otomatik olarak `.A/.B/.C/.D/.E/.F` alt Task'larına bölündü. Önek/dizin çakışması algılanıyor. V3-T1014 #231 merge'ünden sonraya alındı (`executors.ts`).
- **Kabul SHA'sı (EX-04 + R-D1/D2):**
  - Sıra: reseal (T0069.c) → reseal'in review'u → Founder kabul kiti (T0031.c) son head'de → merge.
  - **Reseal penceresi kilidi:** reseal başladığı andan paket merge'üne kadar başka merge yapılmaz; base sabit kalır, update-branch gerekmez.
  - Reseal yalnız paketin merge kapıları karara bağlıysa başlar.
  - Head değişirse kit yeniden koşulur.
  - Merge sonrası yeni installer (V4-T0001.a) toplanır ve yeniden kurulur (T0002.a).
- **Yetkilendirme durumları (EX-05):** DESIGN_FINAL_CANDIDATE → FOUNDER_AUTHORIZED (D-01) → CODE_ALLOWED (Task'ın kendi startGates'i; D-12 yoksa 1 slot) → MERGE_ALLOWED → WINDOWS_ACCEPTANCE_ALLOWED. Başlangıç için tek zorunlu karar D-01. D-24, D-01 ile birleştirildi.
- **M0 (EX-06):** V3-T1008 başlangıç kapısı yok. Geçici mod mevcut kurallar içinde: tek merger + update-branch + birleşik SHA'da tam CI. 14 günlük ölçüt yalnız izleme.
- **Doğrulama komutu (EX-07):** `v41/verify.py` (Linux / Windows, salt-okur).
- **Windows ön koşulları (EX-08):** 11_* salt-okur teşhis. Windows 11 dayatılmaz; D-26 teşhisten sonra.
- **Ölçüt ayrımı (EX-09):** uzun pencere ölçütleri `monitoring` alanında; 10 AC STABILITY_MONITORING; merge kapısı değiller.
- **Kanıt sayaçları (EX-10):** EVIDENCE_SPEC_COUNT {ev['EVIDENCE_SPEC_COUNT']} · **EVIDENCE_VERIFIED_PASS_COUNT {ev['EVIDENCE_VERIFIED_PASS_COUNT']}** · LEGACY_UNIT (yeniden bağlanacak) {ev['LEGACY_UNIT_EVIDENCE_TO_RELINK']} · NOT_PRODUCED {ev['NOT_PRODUCED']}.

## 3. Sayılar (makine-okunur kayıtlardan)

- 57 Feature.
- **{S['tasks']} kayıt** = 175 temel kayıt (129 legacy + 35 V3.1 + 11 V4.1; {S['base175']}/175 korundu) + {len(S['exNew'])} EX-04 Task'ı ({', '.join(S['exNew'])}) + {S['exSplitChildren']} EX-03 alt Task'ı (karma owner bölmesi). SPLIT konteynerleri: {S['byStatus'].get('SPLIT', 0)}. Açık iş: **{S['open']}**.
- 102 AC ve 102 kanıt spesifikasyonu; bunlardan PASS kanıtı **0**.
- 31 karar:

  | Grup | Karar sayısı |
  | --- | --- |
  | 0 (başlangıç) | 1 |
  | 1 (alan kapıları) | 8 |
  | 2 (kodlama sürerken) | 14 |
  | 3 (ileri faz) | 7 |
  | Birleştirilen | 1 |

- **Tier (açık Task):** {S['tiers']}.

## 4. Dalgalar (açık Task; efor ESTIMATE)

| Dalga | Açık Task | Efor h |
| --- | --- | --- |
""" + "\n".join(f"| {w} | {S['waves'][w]} | {f(W[w])} |" for w in ["W0", "W1", "W2", "W3", "W4", "W5"]) + f"""

**Kritik yol (R1):** {CP} = {cp['min']:.0f}–{cp['max']:.0f} h. R1 kapanış kümesi {r1['n']} Task, {f(r1['eff'])} h (ESTIMATE).

## 5. Merge sırası (tipli; 3-slot simülasyonuyla doğrulandı)

| Sıra | Ne | Durum geçişi | Kapılar |
| --- | --- | --- | --- |
| M0 | Geçici seri merge modu (V3-T1008) | Mevcut kurallar; karar gerekmez | — |
| M1 | V3-T1001 store-lock | REVIEWED → MERGED | — (T1) |
| M2 | PR-251: V3-T1002 → V3-T1003/V3-T1036 (CODE_READY) → UASCO-T0069.a reseal (üyeler REVIEWED) → paket merge | MERGED | D-18, D-07, D-31 |
| M3 | UASCO-T0016 export | MERGED | D-31 |
| M4 | PR-247: UASCO-T0100.a | MERGED (PR-251'den sonra) | D-07, D-31 |
| M5 | PR-231: T0031 (C, REVIEWED) → T0031.b (B; T0031:CODE_READY'den sonra) → T0069.c reseal (D; PR-251 MERGED'den sonra) → **T0031.c Founder kiti son head'de ACCEPTED** → paket merge. Head değişirse T0031.c yeniden | MERGED | D-03, D-07, D-31, D-23 |
| M6 | V4-T0001.a yeni installer (bütün R1 kodu MERGED) → T0002.a yeniden kurulum → T0029 / T0044 / V3-T1018 / T0014 / T0035 | ACCEPTED | D-23, D-26, D-29, D-19 |
| M7 | UASCO-T0069.b koruma genişletmesi | MERGED | D-07, D-31 |
| — | #282 | DEFER; D-22 ölçütü (3 ardışık tam yeşil Windows + base kontrol); otomatik koşu yok | D-22 |
| — | #66 | Merge yok (D-11) | D-11 |

## 6. İlk paralel dalga (simülasyon S2: D-01 + Grup 1, kabul ortamı henüz yok)

- **Slot gerektirenler (ilk başlayanlar):** {jn(slots2)}.
- **Slot gerektirmeyen (deterministik / Founder):** {jn(nonslot2)}.
- **D-01 tek başına verilirse (S1, 1 slot):** ilk başlayanlar {jn(s1['startedFirst'][:8])} … Tamamlanan {s1['completed']}/{s1['total']}; kalanların hepsi karar ya da Founder ortamı bekliyor, **kilitlenme 0**.

## 7. Simülasyon sonuçları (13_*)

| Senaryo | Verilen kararlar | Kabul ortamı (hosted runner / UAT) | Slot | Tamamlanan | Kilitlenme | Bağımsız denetimde çakışma | Kapı atlaması | Kilit / freeze ihlali | En çok slot |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S0 | — | — | 0 | 0 (repo yazma yok) | 0 | 0 | 0 | 0 | 0 |
""" + "\n".join(f"| {n[:2]} | {', '.join(x['granted']) if len(x['granted']) < 12 else 'hepsi'} | {'var' if x['founderEnv'] else 'yok'} | {x['slots']} | {x['completed']}/{x['total']} | {len(x['deadlocks'])} | {len(x['independentAuditConflicts'])} | {len(x['gateBypass'])} | {len(x['lockViolations'])}/{len(x['headFreezeViolations'])} | {x['maxSlotsUsed']} |" for n, x in ((k, v['summary']) for k, v in SIM.items() if k not in ('S0_NO_DECISION', 'NEGATIVE_TESTS'))) + f"""

- **S4:** bütün kararlar verilmiş ama kabul ortamı (hosted Windows runner / Founder UAT) yok. Reseal kilidi hiç alınmıyor, merge'ler sürüyor (R2-N0).
- **S5:** kabul kiti, kilit zaman aşımını (kit başlatılabilir olduğu andan 24 h) aşıyor. Kilit iki kez iptal ediliyor; PR-231 eskalasyona gidiyor. Güvenli varsayılan: paket ertelenir, claim'ler serbest bırakılır. Kalan işler açıkça D-03 kararını bekliyor; kilit sonda serbest.
- **S6:** kit bir kez NOT_ACCEPTED dönüyor. Kilit bırakılıyor, düzeltme aynı PR paketinde yapılıyor (üyeler yeniden açılıyor, claim'ler pakette kalıyor), kit yeniden koşuyor. Sonuç: 167/167 (R3-L2).
- **S7:** kit iki kez başarısız. Eskalasyon (D-03), paket ertelenir, claim'ler serbest (R3-L3).
- **S9:** Founder kilitten sonra ulaşılamaz oluyor. Kit 8 h içinde başlamadığı için kilit iptal ediliyor (kit öncesi zaman aşımı); iki iptalden sonra eskalasyon (ESC-PR-231); kilit serbest, merge'ler sürüyor (R5).
- **S8:** bütün Founder Task'ları 40 h sürüyor. Kilit yalnız Founder boşken alınıyor, zaman aşımı kit fiilen başlayınca başlıyor. Sonuç: iptal 0, 167/167 (R4-L1).
- **Founder rezervasyonu (R3-L1, R4-L1):** kilit yalnız Founder boşken alınır; kilit süresince Founder yalnız kilitli paketin kitini yapar; zaman aşımı kit fiilen başladığında başlar.

**Negatif (mutasyon) testleri:** claim'ler kapatılınca bağımsız denetim {SIM['NEGATIVE_TESTS']['summary']['NEG_CLAIMS_DISABLED']['independentAuditConflicts']} çakışma buluyor; reseal kilidi kapatılınca {SIM['NEGATIVE_TESTS']['summary']['NEG_LOCK_DISABLED']['lockViolations']} kilit ihlali buluyor. Yani "0" sonuçları tanım gereği değil, ölçülmüş sonuçlar (R-D3, R2-N1).

Bağımsız denetim, claim mantığından ayrı bir kontroldür. Simülasyon günlüğündeki aralıklardan (başlangıç → merge; aynı PR içinde başlangıç → bitiş) dosya ve paylaşılan dış kaynak çakışmasını yeniden hesaplar. Aynı PR'daki eşzamanlı kodlamayı da kapsar (R-D3).

S3'te R1'in son Task'ı (UASCO-T0035) simülasyon saatiyle ~{r1_done} h'de tamamlanıyor. Bu, ortalama efor ve kesintisiz Founder varsayımıyla üretilmiş bir **ESTIMATE**'tir; takvim değildir.

## 8. Doğrulama

`{CMD_LX}` (Linux/macOS) · `{CMD_WIN}` (Windows PowerShell). Kanıt: 14_V4_1_TEST_EVIDENCE.md.

## 9. Doğrulanamayanlar

- `.exe`'nin adı ve SHA'sı.
- Installer smoke ayrıntısı.
- Rutin durumu.
- Bulut sandbox/worker sağlayıcısı ve kalıcılık (D-03, D-08): UNKNOWN.
- Merge queue'nun kullanılabilirliği.
- Claude otomatik güncellemesi.
- #231 rebase çakışma boyutu.
- Efor/maliyet (ESTIMATE).
- Windows'ta `verify.py` çalıştırılmadı (NOT_RUN_ENV_UNAVAILABLE).
"""
open(f"{OUT}/01_UASCO_MASTER_EXECUTION_ROADMAP_V4_1.md", "w").write(R)
# ---------------------------------------------------------------- 05
WIN = """# 05 — Windows `.exe` Teslim ve Kabul Planı (patch EX-04, EX-08 + CLOUD-ONLY)

> **CLOUD-ONLY (2026-11-02, Founder yönergesi; birleştirme kuralları CO-1..CO-10: 17_CLOUD_ONLY_MERGE_REPORT.md).** Bütün geliştirme, model, test, güvenlik, sandbox, CI ve teslim bulutta yürür. Founder-PC yalnız imzalı/hash doğrulanmış `.exe`'nin kur/aç/kullan son kullanıcı kabulü (UASCO-T0002, T0002.a) içindir; BIOS/WSL/VM/Node/Claude CLI/yerel worker şartı yoktur. #231 (WSL2) AS-IS merge edilmez (D-07). Bulut sandbox/worker sağlayıcısı (D-03) verilmedikçe çalışma zamanı UNKNOWN: paket en fazla READY_FOR_CODING'dir, PRODUCT_READY değildir. UAT'tan önce cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS zorunludur.

> Bir aşamanın kanıtı diğerinin yerine geçmez. Gerçek ortam yoksa NOT_RUN_ENV_UNAVAILABLE. CI installer PASS kullanıcı kabulü değildir.

## 1. Kanıt ↔ SHA bağlama kuralları (EX-04)

1. **Kabul kiti (`founder-acceptance.mjs`) `git HEAD`'e bağlıdır.** Temiz checkout ve `npm ci` gerektirir (kit README; #231).
2. **Sıra:** T0031 (kod) → T0031.b (server.ts) → **T0069.c (reseal commit = son commit)** → **T0031.c: hosted Windows runner, PR head SHA'sını temiz checkout eder ve kiti çalıştırır** (#231 AS-IS merge edilmez; bulut sağlayıcı yolu CLOUD-T0002/T0014) → merge.
3. **T0031.c'den sonra PR dalına commit atılmaz.** Atılırsa (rebase ya da düzeltme dahil) T0031.c geçersizdir ve kit yeniden koşulur. Merge öncesi supervisor şunu doğrular: `kit.sha == PR head SHA`.
4. **Merge commit ≠ PR head.** Kit kanıtı PR head kaynağı içindir. Merge sonrası:
   - **V4-T0001.a** merge commit'inin installer'ını toplar (`.exe` SHA + kaynak merge SHA).
   - **T0002.a** bu installer'la yeniden kurulum yapar.
   - R1 koşuları (T0029 …) bu kurulu build üzerinde yapılır.
   - Eşleme kanıtı: merge commit'in ikinci ebeveyni (parent2) = kabul edilen PR head SHA'sı. Ağaç da merge-tree ile aynı olmalı; ledger bunu zaten kontrol ediyor (rapor M.2).
5. **R1 installer'ı bütün R1 kod Task'larını içerir:** V4-T0001.a, R1 kod Task'larının hepsi MERGED olmadan başlamaz (build betiği bu bağımlılıkları ekliyor).

## 2. Aşamalar

| Aşama | Sorumlu | Ortam | Yöntem | Kanıt | Başarısızlıkta |
| --- | --- | --- | --- | --- | --- |
| BUILD_OK | E (deterministik) | Actions | Push CI sonucu | run id + headSha | Merge durur |
| INSTALLER_OK | E (V4-T0001 / V4-T0001.a) | Actions windows-latest | Installer workflow + smoke (job log'u) | `.exe` adı, boyutu, sha256, kaynak SHA | D lane |
| WINDOWS_INSTALL_VERIFIED | E (CLOUD-T0006/T0013) → Founder UAT (UASCO-T0002, T0002.a) | Hosted Windows runner (Win10 19045 + Win11 matrisi) → Founder-PC yalnız kur/aç | Otomatik GUI/API smoke; sonra Founder kur/aç/kullan | JSON + ekran görüntüsü; installer sha256 = V4-T0001(.a) SHA | A/D Task'ı |
| FRONTEND_API_VERIFIED | A_UI + E | Hosted Windows runner (windows-latest E2E UASCO-T0095) | Ekran aksiyonu → `/v1` yanıtı (remote cloud API) | Ekran → route → yanıt kaydı | A Task'ı |
| REAL_AI_EXECUTION_VERIFIED | C/B (bulut) | Bulut worker + cloud model gateway (D-29) | Gerçek pre-dev | Artifact hash'leri; kullanım ya da UNKNOWN | T0061.a akışı |
| SANDBOX_VERIFIED | C (CLOUD-T0002, T0014) | Bulut sandbox (D-03); yerel WSL yok | İzolasyon testleri + fail-closed (`CLOUD_RUNTIME_NOT_CONFIGURED`) | Test raporu (head SHA'ya bağlı) | C Task'ı |
| TEST_ACCEPTED | C/B (CLOUD-T0011) | Bulut E2E | 3 ardışık run; tohumlanmış hata remediation ile düzeltilir | V3-EV-F012-2, F019-2 | Sonnet → Opus |
| SECURITY_ACCEPTED | D (CLOUD-T0007, V3-T1010) | Bulut CI runner image (pinned gitleaks + trivy) | SEC-PROFILE-R1 | security-report + araç hash'leri. PARTIAL → DELIVERED_SECURITY_PARTIAL | D-19 |
| DELIVERY_ACCEPTED | B + script (CLOUD-T0008, T0011) | Bulut temiz worker | Export sha256 + `npm ci && npm test` (şablon kilit dosyası) | V3-EV-F005-1, F057-1/2 | A / B / C |
| FOUNDER_ACCEPTED | Founder | Founder-PC (yalnız `.exe` kur/aç/kullan; bulut koşusunu izler, sonucu indirir) | SOURCE_DELIVERY_ACCEPTED + R1 demo | V3-EV-F015-1, F004-1 | İlgili aşama |

## 3. Founder-PC gereksinimleri (yalnız UAT)

Windows 10 Home (19045) ya da Windows 11, internet bağlantısı ve indirilen `.exe`. Node, Git, WSL, sanallaştırma, Claude CLI, güvenlik aracı ya da test worker kurulmaz. Uyumluluk hosted runner matrisiyle kanıtlanır (CLOUD-T0013, D-26). Eski salt-okur teşhis metni arşivdedir (sources/archive/).

## 4. İlk gerçek `.exe` tesliminin kabul şartları (R1)

1. Bulut sandbox yolu (CLOUD-T0002/T0014, UASCO-T0031 cloud) merge edildi; #231 AS-IS merge edilmedi. Reseal paketleri için: merge commit parent2 = kit'in kabul ettiği head SHA'sı.
2. Cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS; sonra V4-T0001.a installer'ı (bütün R1 kodu MERGED) Founder tarafından kuruldu (T0002.a, yalnız UAT).
3. 10 aşamanın her biri ayrı kanıtla geçti.
4. İki proje tipi, 3 ardışık run.
5. SECURITY PARTIAL ise etiket VERIFIED olmaz.
6. Bağımsız yeniden üretim PASS.
7. Elle düzenleme 0.
8. STOP ve sağlayıcı hatası negatifleri geçti.
9. R1 kapısı: 45 kabul AC'si. 7 izleme AC'si R1'i bloke etmez, STABLE durumuna sayılır.
"""
open(f"{OUT}/05_V4_1_WINDOWS_EXE_ACCEPTANCE_PLAN.md", "w").write(WIN)
# ---------------------------------------------------------------- 08 (kısa, değişmeyen ilkeler)
tok = "# 08 — Token ve Maliyet Kontrol Planı\n\n> ESTIMATE; ölçülmüş tasarruf yok.\n\n## Model dağılımı (açık Task)\n\n" + "\n".join(f"- {m}: {v[0]} Task, {f(v[1])} h" for m, v in S['models'].items()) + """

## Kurallar

- **Bütçe ve kota:** D-08 bütçesi + UASCO-T0110 USAGE_LIMIT koruması; ölçüm UASCO-T0111.
- **Uzlaştırma:** yalnız `v41/verify.py` (deterministik); LLM ile yeniden üretim yok.
- **Keşif:** Task başına ≤10 sembol; tüm repo okunmaz.
- **Review:** tier'a göre model; patch-id cache; base-merge'de yeniden review yok; IR yeniden koşturulmaz.
- **CI:** draft PR'da yalnız L0; Windows shard'ları yalnız Windows'a duyarlı yollarda; "Re-run failed jobs" yok; post-merge CI yalnız ağaç farklıysa.
- **Paketleme:** ajan değil V4-T0001 / V4-T0001.a.
- **Retry:** aynı fingerprint için 1.
- **Supervisor:** kısa ömürlü; olay güdümlü; saatlik tick yok.
- **İzleme ölçütleri (EX-09)** ayrı izlenir. İlk kod kabulünü bekletmedikleri için gereksiz yeniden koşu ve bekleme maliyeti doğmaz.

## Maliyet metrikleri

Accepted Feature başına maliyet · kullanılabilir teslim başına maliyet (R1'de ölçülür) · $/merged PR (ikincil) · kota duruş saati.
"""
open(f"{OUT}/08_V4_1_TOKEN_COST_CONTROL_PLAN.md", "w").write(tok)
# ---------------------------------------------------------------- 09 directive
DIR = f"""# 09 — UASCO V4.1 EXECUTION START DIRECTIVE (patch EX-05/06/07 + CLOUD-ONLY)

> **CLOUD-ONLY (2026-11-02, Founder yönergesi; birleştirme kuralları CO-1..CO-10: 17_CLOUD_ONLY_MERGE_REPORT.md).** Bütün geliştirme, model, test, güvenlik, sandbox, CI ve teslim bulutta yürür. Founder-PC yalnız imzalı/hash doğrulanmış `.exe`'nin kur/aç/kullan son kullanıcı kabulü (UASCO-T0002, T0002.a) içindir; BIOS/WSL/VM/Node/Claude CLI/yerel worker şartı yoktur. #231 (WSL2) AS-IS merge edilmez (D-07). Bulut sandbox/worker sağlayıcısı (D-03) verilmedikçe çalışma zamanı UNKNOWN: paket en fazla READY_FOR_CODING'dir, PRODUCT_READY değildir. UAT'tan önce cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS zorunludur.

> **Tek başlangıç koşulu: Founder'ın D-01 kararı** (V4.1 onayı + yazılı başlatma talimatı).
>
> - D-01 yoksa Execution oturumu repo'ya yazmaz. Yalnız §1'i çalıştırır ve "D-01 bekleniyor" raporlar.
> - D-01 varsa, karar beklemeyen Task'lar kendi `startGates`'leriyle başlar.
> - Diğer kararlar yalnız kendi alanlarını kapılar: merge, paralellik, Windows kabulü.
>
> Bu talimat yetki kapılarını değiştirmez; yeni roadmap yazılmaz.

## 0. Yetkilendirme durumları

| Durum | Anlamı | Gereken |
| --- | --- | --- |
""" + "\n".join(f"| {a} | {b} | {c} |" for a, b, c in M['meta']['authStates']) + f"""

## 1. Doğrulama (deterministik, model yok; D-01'den önce de yapılabilir, salt-okur)

1. Paket kökünde:
   - Linux/macOS: `{CMD_LX}`
   - Windows: `{CMD_WIN}`
   - `verify.py` şunları yapar: (a) `SHA256_MANIFEST.txt` kontrolü; (b) `V41_PACKAGE_ROOT=<paket>` ile üreticiyi geçici dizine yeniden çalıştırır ve çıktıları paketle bayt bayt karşılaştırır; (c) 175 / 57 / 102 / 31 sayımı, hata listesinin boş olması, 3 simülasyon senaryosunda kilitlenme = 0 ve yazma çakışması = 0.
   - Çıkış kodu 0 değilse dur.
2. `git ls-remote origin refs/heads/v7/integration refs/heads/uasco/production-reports refs/heads/uasco/production-queue`. Paketteki SHA'lardan farklıysa fark raporu yaz; matrisi elle değiştirme.
3. Açık PR'ların changed-files listelerini `git diff --name-only <merge-base> <head>` ile yeniden çıkar ve `sources/repo/pr*.txt` ile karşılaştır. Fark varsa ilgili paketin Task'larını **BLOCKED_SOURCE_CHANGED** yap; diğer işler sürer.
4. `list_triggers` ile rutinlerin kapalı olduğunu doğrula. **Hiçbir rutini açma.**

## 2. Dispatch kuralları (simülasyonla aynı; 13_*)

- **Slot:** en fazla 3; **D-12 verilmeden 1.** Deterministik ve Founder Task'ları slot kullanmaz.
- **Seçim:** `state=PLANNED` · bütün `deps` (Task:DURUM) sağlanmış · `startGates` hepsi verilmiş · claim alınabilir · öncelik: R1 → en uzun kalan zincir → dalga → kimlik.
- **Claim:** tek supervisor tutar (tek yazar, atomik). Task başında `targetFiles` için alınır, PR paketi MERGED olana kadar tutulur. Önek/dizin çakışması çakışmadır. Aynı lane'deki Task'lar da aynı dosyayı aynı anda tutamaz. Tek istisna aynı PR paketinin üyeleri; bunlar sıralı devirle çalışır.
- **Durumlar:** kod Task'ı bitince REVIEWED. Tekil Task merge'de MERGED olur. Paket üyeleri paket merge'ünde birlikte MERGED olur. Founder kabul Task'ları ACCEPTED, kararlar ve kayıtlar DONE.
- **Merge (tek merger, seri; M0 geçici modu):** update-branch → birleşik SHA'da tam CI → ledger NO_BLOCKERS (aynı SHA/patch-id) → `mergeGates` verilmiş → T2 için Founder onayı → merge → post-merge push CI + installer. "Re-run failed jobs" yok.
- **PR-231 özel kuralı:** merge öncesi `T0031.c.kit.sha == PR head SHA`. Değilse kit yeniden. Merge sonrası parent2 = kabul edilen head.
- **Reseal penceresi kilidi:**
  - Manifest'e dokunan bir paketin reseal üyesi başladığında merger başka hiçbir merge yapmaz.
  - Reseal ancak şu koşullarla başlar: paketin bütün merge kapıları karara bağlı ve ön koşul Task'ları (ör. kabul kiti) başlatılabilir durumda (kapıları verilmiş, hosted Windows runner hazır).
  - Kilit başında merger paket dalını güncel base'e alır (update-branch), sonra reseal hesaplanır. Base kilitle sabittir; merge anında update-branch gerekmez.
  - **Zaman aşımı 24 h:** kilit bu sürede merge edilmezse ya da kit NOT_ACCEPTED dönerse kilit iptal edilir. Reseal commit'i geçersiz sayılır ve Task PLANNED'e döner; süren kit sonucu eski head için olduğundan geçersizdir. Merge'ler devam eder.
  - **Founder rezervasyonu:** kilit yalnız Founder boşken alınır ve kilit süresince Founder yalnız o paketin kitini yapar. Zaman aşımı, kit fiilen başladığı andan sayılır. Ön koşulsuz paketlerde zaman aşımı yoktur; reseal son üyedir ve hemen merge edilir.
  - **Kit öncesi zaman aşımı (8 h):** kilit alındıktan sonra kit 8 h içinde başlamazsa (ör. Founder ulaşılamaz) kilit iptal edilir.
  - **Eskalasyon kararı ayrı bir karar örneğidir (`ESC-<paket>`):** D-03 ya da D-07 kapsamında yeniden dene, yeniden tasarla ya da ertele. Önceden verilmiş bir D-03 onayı bunu karşılamaz. Devam kararından sonra serbest bırakılan dosyalar için rebase, yeniden review ve yeniden claim zorunludur.
  - **Kit NOT_ACCEPTED:** kilit bırakılır. Düzeltme aynı PR paketinde yapılır: üyeler yeniden açılır, claim'ler pakette kalır, dışarıdan PR gerekmez. Ardından kit yeniden koşulur.
  - **2 iptal ya da başarısızlıktan sonra** paket Founder'a eskalasyon edilir (PR-231 için D-03; diğerleri D-07). Karar yoksa güvenli varsayılan: paket DEFERRED, claim'ler serbest bırakılır, bağımlı Task'lar BLOCKED_DECISION olur. Diğer işler sürer.
  - Kilit süresince kodlama sürer, yalnız merge durur.
- **Mühürlü dosyalar:** trust-root manifest'indeki bir dosyaya dokunan her Task manifest'i de claim eder; reseal aynı PR'da D lane alt Task'ıyla yapılır (`<id>.D`).
- **Register:** yalnız deterministik araçlar yazar (CI'sız supervisor kaydı). LLM register'a, kanıt kaydına ya da supervisor durumuna doğrudan yazmaz.
- **Güvenlik/yetki kodu T2:** execution-gate, sandbox, runner, executors, claude-profiles, security-tools, secret-scan, test-surface, action-gateway, preload, devrun; ayrıca kabul kiti, docs altındaki çalıştırılabilir dosyalar, rutin prompt'ları, tedarik zinciri, release, model yönlendirmesi, supervisor araçları. Hepsi Founder T2 onayıyla merge edilir (D-31 paketi).
- **#282:** DEFER; merge yok, otomatik koşu yok; D-22.
- **Kanıt:** PASS kanıtı yalnız gerçek artifact/işlem/ortam kaydıyla. EVIDENCE_VERIFIED_PASS_COUNT şu an 0. SKIP ve NOT_RUN PASS değildir. PARTIAL güvenlik VERIFIED değildir.
- **İzleme ölçütleri** (`monitoring` alanı ve STABILITY_MONITORING AC'leri) merge'ü bekletmez; ayrı izlenir.
- **Retry:** aynı fingerprint için 1, ardından BLOCKED_WITH_EVIDENCE.
- **Durma:** USAGE_LIMIT ya da D-08 bütçesi.
- **Founder adına karar verilmez.**

## 3. İlk paralel dalga (S2: D-01 + Grup 1)

- **Slotlar:** {jn(slots2)}.
- **Slot dışı:** {jn(nonslot2)}.

## 4. Merge sırası

01_* §5 (M0–M7).

## 5. Rapor

V4 §15 biçimi + `EVIDENCE_VERIFIED_PASS_COUNT` + simülasyondan sapma (beklenen ↔ gerçek sıra).

## 6. Çıkış (R1)

05_* §4.
"""
open(f"{OUT}/09_V4_1_EXECUTION_START_DIRECTIVE.md", "w").write(DIR)
# ---------------------------------------------------------------- 11 diagnostic
DIAG = """# 11 — Founder-PC Salt-Okur Teşhisi: KALDIRILDI (CLOUD-ONLY)

> Cloud-only yönergesiyle Founder-PC'de teşhis, WSL, sanallaştırma ya da yerel worker kontrolü istenmez. Founder-PC yalnız `.exe` kur/aç/kullan kabulü içindir (UASCO-T0002, T0002.a).
> Windows 10/11 istemci uyumluluğu hosted runner matrisiyle kanıtlanır (CLOUD-T0013, D-26).
> Önceki metin yalnız tarihsel kanıt olarak saklanır: `sources/archive/11_FOUNDER_PC_READONLY_DIAGNOSTIC.historical.md` (AKTİF TALİMAT DEĞİLDİR).
"""
open(f"{OUT}/11_FOUNDER_PC_READONLY_DIAGNOSTIC.md", "w").write(DIAG)
print("docs ok")
# ---------------------------------------------------------------- 12 EX closure
st = {k: v for k, v in S['selftest']}
EX = [
("EX-01", "P0", "DONE/MERGE/ACCEPTED kilitlenmesi", "CLOSED", "Tipli durumlar ve bağımlılıklar (patch_ex.STATES, TYPED_DEPS); PR paketleri (BUNDLES). UASCO-T0031 artık REVIEWED'de tamamlanıyor, merge PR-231 paketinde. T0031.b ← T0031:CODE_READY; T0069.c ← T0031:REVIEWED + T0031.b:REVIEWED + T0069.a:MERGED; T0069.a ← V3-T1002/1003/1036:REVIEWED.",
 f"Self-test 'T0031.b ← T0031:CODE_READY' = {st.get('T0031.b ← T0031:CODE_READY')}. Simülasyon S3: {s3['completed']}/{s3['total']} tamamlandı, kilitlenme {len(s3['deadlocks'])}. S1 ve S2'de tamamlanmayanların hepsi DECISION ya da FOUNDER_ENV nedenli (kilitlenme 0)."),
("EX-02", "P0", "Yeni korumalı dosyalarda tier", "CLOSED", "`canon_path()` NEW:/PR231:/PR247: öneklerini ve '(…)' açıklamalarını temizliyor. Repo korumasına ek AUTHORITY_SENSITIVE (fail-closed T2): config/, .github/, scripts/validate-, scripts/ci/, scripts/run-validation, automation/lib/, schemas/, prompts/, coord-ledger. CI'sız supervisor commit'i yalnız register dalı. NEW_PROVISIONAL yollar en az T1 ve keşifte yeniden sınıflanıyor.",
 "Self-test: NEW:config/authority-matrix.json korumalı · NEW:.github/workflows yetki-hassas · V3-T1025/V3-T1026/UASCO-T0095/V3-T1004 = T2 · T0 ve CI'sız commit kontrolü hata 0 — " + str(all(st.get(k) for k in ['V3-T1025 tier T2', 'V3-T1026 tier T2', 'UASCO-T0095 tier T2', 'V3-T1004 (ledger) tier T2']))),
("EX-03", "P0", "Gerçek dosyada paralel yazma", "CLOSED", "PR-231 (42), PR-251 (4), PR-247 (3) gerçek changed-files'tan paket üyelerine dağıtıldı. Karma owner'lı 16 açık Task otomatik bölündü. Önek/dizin çakışması algılanıyor (sim.overlap). Aynı lane'deki Task'lar da claim'e tabi. V3-T1014 ← PR-231 MERGED (executors.ts). Claim'ler MERGED'e kadar tutuluyor.",
 f"Self-test '#231 write set 42 dosya' = {st.get('#231 write set 42 dosya')}; overlap testleri geçti. Simülasyon: yazma çakışması S1 {s1['writeConflicts']} · S2 {s2['writeConflicts']} · S3 {s3['writeConflicts']}; en çok slot {s3['maxSlotsUsed']}. Build kontrolü 'mixed owner remains' = 0."),
("EX-04", "P0", "Kabul kiti SHA'sı", "CLOSED", "Sıra: T0069.c reseal (son commit) → T0031.c kit son head'de → paket merge (ön koşul: T0031.c). Head değişirse kit yeniden. Merge sonrası V4-T0001.a installer + T0002.a yeniden kurulum; R1 koşuları bunun üzerinde. V4-T0001.a bütün R1 kod Task'larını MERGED bekliyor.",
 f"Self-test 'kit ← reseal:CODE_READY' = {st.get('kit ← reseal:CODE_READY')}, 'PR-231 ön koşulu kit' = {st.get('PR-231 ön koşulu kit')}. Kit README'si: sonuç SHA'ya bağlı; bilinmeyen SHA = NOT_ACCEPTED (kaynak #231 docs/acceptance/windows/README.md)."),
("EX-05", "P1", "Başlatma şartları çelişkisi", "CLOSED", "AUTH_STATES (5 durum). Başlangıç için tek zorunlu karar D-01. D-24, D-01 ile birleştirildi. Diğer kararlar yalnız kendi merge/paralellik/Windows alanlarını kapılar. D-12 yoksa 1 slot (tek supervisor + tek builder). 01_* ve 09_* aynı kuralı kullanıyor.",
 f"Simülasyon S1 (yalnız D-01, 1 slot): {s1['completed']} Task tamamlandı, kilitlenme 0. S0 (karar yok): 0 Task."),
("EX-06", "P1", "M0 / D-17", "CLOSED", "V3-T1008'in başlangıç kapısı kaldırıldı. Geçici mod mevcut kurallar içinde (tek merger + update-branch + birleşik SHA'da tam CI). D-17 yalnız V3-T1007 (politika + ci.yml, T2) için. 14 günlük ölçüt `monitoring` alanında.",
 f"Self-test 'V3-T1008 başlangıç kapısı yok' = {st.get('V3-T1008 başlangıç kapısı yok')}."),
("EX-07", "P1", "Doğrulama komutu", "CLOSED (Linux) / Windows NOT_RUN", "`v41/verify.py`: platformdan bağımsız Python; V41_PACKAGE_ROOT'u kendisi ayarlar. Linux ve Windows komutları 09_*'da.",
 "Linux'ta çalıştırıldı (14_*). Windows'ta çalıştırılmadı: bu ortamda Windows/PowerShell yok (NOT_RUN_ENV_UNAVAILABLE)."),
("EX-08", "P1", "Windows ön koşul teşhisi", "CLOSED (doküman) / ortam UNKNOWN", "11_* salt-okur komutlar; D-26 'Windows 11 dayatma' yerine teşhis sonrası karar.",
 "Komutlar bu oturumda çalıştırılmadı (Founder-PC yok)."),
("EX-09", "P1", "Uzun pencere ölçütleri", "CLOSED", "MONITORING_SPLIT (V3-T1001, UASCO-T0088, V3-T1008, V3-T1033, UASCO-T0121): `doneMerge` ↔ `monitoring`. 10 AC STABILITY_MONITORING; R1 kapısı 45 kabul AC'si + 7 izleme AC'si (kapı değil). Test güvenliği değişmedi: deterministik test birleşik SHA'da zorunlu.",
 f"Kanıt sayaçları: {ev}."),
("EX-10", "P2", "102 kanıt ≠ PASS", "CLOSED", "EVIDENCE_SPEC_COUNT 102 ve EVIDENCE_VERIFIED_PASS_COUNT 0 ayrı. LEGACY_UNIT 10, NOT_PRODUCED 92. Rapor ve başlangıç talimatı bu sayaçları kullanıyor.",
 f"EVIDENCE_VERIFIED_PASS_COUNT = {ev['EVIDENCE_VERIFIED_PASS_COUNT']}."),
]
cl = ["# 12 — EX-01..EX-10 Bulgu Kapanış Raporu", "", "Her bulgu kaynakla karşılaştırıldı. Reddedilen bulgu yok: 10 bulgunun 10'u kanıtla doğrulandı. Kısmi kalanlar açıkça işaretli.", "",
      "| ID | Önem | Başlık | Durum | Düzeltme | Kanıt |", "|---|---|---|---|---|---|"] + [f"| {a} | {b} | {c} | **{d}** | {e} | {g} |" for a, b, c, d, e, g in EX]
RV = [
("R-S1", "HIGH", "Korumalı dosya içeren klasör hedefleri T1", "CLOSED", "is_protected/is_auth/is_sec klasör kapsamını kontrol ediyor (as_dir)", "self-test 'registries/ klasörü korumalı', 'renderer/ klasörü korumalı'"),
("R-S2", "HIGH", "Kabul kiti kendini onaylıyor; docs değişikliği T0'a düşüyor", "CLOSED (kısmi risk kabulü)", "docs/acceptance/ ve docs altındaki çalıştırılabilir dosyalar T2 + Opus review; T0 yalnız .md dokümanları (CI'lı PR). Kiti yazan ile koşan farklı: kiti Founder çalıştırır, sonucu supervisor şema ve SHA ile doğrular", "self-test 'kabul kiti yetki-hassas'. Kalan risk: kitin içeriği builder tarafından yazılıyor; T2 Founder onayı + Opus review bunu sınırlıyor, ama ortadan kaldırmıyor"),
("R-S3", "HIGH", "Merge kuralı ve register düşük tier'da", "CLOSED", "EXT:supervisor* yetki-hassas (T2). Register'a yalnız deterministik araç yazar. T0008/T0028 deterministik; T0120 gerçek roadmap dosyaları; T0121/T0122 .md PR'ı; V3-T1005 .github + scripts/ci (T2)", "self-test 'V3-T1008 T2', 'UASCO-T0120 CI'sız değil'; build kontrolü 'ci-less commit not deterministic/register-only' = 0"),
("R-S4", "MEDIUM-HIGH", "Güvenlik uygulayan kod T1", "CLOSED", "SECURITY_SENSITIVE genişletildi (executors, devrun dahil) ve T2'ye bağlandı", "self-test 'UASCO-T0031 T2'; build kontrolü 'security-sensitive below T2' = 0"),
("R-S5", "MEDIUM", "Eksik yetki/güvenlik dosyaları", "CLOSED", "package.json/lock, .npmrc, build-installer, installer/, core/policy, models/router, models/omniroute, docs/routines, supervisor araçları T2; rutin prompt'larında Haiku yok", "self-test 'UASCO-T0077 T2', 'rutin prompt'larında Haiku yok'"),
("R-D1", "HIGH", "PR-231 sırası makineyle zorlanmıyor", "CLOSED", "Kit ← T0069.c:REVIEWED; paket ön koşulu kit; headFreezeAfter; reseal penceresi kilidi (base sabit, update-branch gerekmez); simülasyonda head-freeze denetimi", "self-test 'kit ← reseal:REVIEWED'; simülasyon lockViolations = 0, headFreezeViolations = 0"),
("R-D2", "HIGH", "Manifest write set'lerde yok", "CLOSED", "Mühürlü (373 dosya) bir dosyaya dokunan her Task'a manifest eklendi → `<id>.D` reseal alt Task'ı (aynı PR, sıralı devir). Reseal penceresi kilidi araya merge girmesini engelliyor", "self-test 'UASCO-T0016 reseal gerekiyor'; build kontrolü 'sealed file without manifest' = 0; simülasyon lockViolations = 0"),
("R-D3", "MEDIUM", "'0 çakışma' tanım gereği", "CLOSED", "Claim mantığından ayrı bağımsız denetim (günlük aralıkları, ayrı normalizasyon); EXT kaynakları (register, coord-ledger, supervisor, GitHub, claude.ai) claim edilir; aynı PR'da eşzamanlı kodlama yasak", "simülasyon independentAuditConflicts = 0 (S1, S2, S3)"),
("R-D4", "MEDIUM", "Kod dışı Task'larda merge kapısı yok sayılıyor", "CLOSED", "Kod dışı Task'lar bütün kapılar verilmeden başlamaz", "simülasyon gateBypass = 0"),
("R-D5", "LOW", "Slot sınırı, neden sırası, belirsiz yol", "CLOSED", "Slot D-12'den türetiliyor; belirsiz NEW yol dizin öneki; UASCO-T0125 ← PR-231 MERGED", "simülasyon kodu; statik döngü kontrolü build'de (dfs)"),
]
cl += ["", "## Bağımsız review (tur 1) bulguları ve kapanışı", "", "| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |", "|---|---|---|---|---|---|"] + [f"| {a} | {b} | {c} | **{d}** | {e} | {g} |" for a, b, c, d, e, g in RV]
RV2 = [
("R2-N0", "HIGH", "Reseal kilidi bütün merge'leri süresiz dondurabilir", "CLOSED", "Kilit yalnız ön koşullar başlatılabilirken alınır; 24 h zaman aşımı + iptal (reseal ve süren kit geçersiz); 2 iptalden sonra Founder'a eskalasyon; kilitte bekleyen Task'ın nedeni MERGE_LOCK olarak raporlanır", "S2: 54/167 (önce 28); S4 (Founder-PC yok): kilit alınmadı; S5: 2 iptal + eskalasyon, kilit sonda serbest, kilitlenme 0"),
("R2-N1", "MEDIUM", "Normalizasyon boşluğu; denetim bağımsız değil", "CLOSED", "Uzantısız ya da açıklamalı yollar dizin öneki. Denetim ayrı normalizasyonla (audit_norm, posixpath) ve deneme bazında aralıklarla çalışıyor", "self-test 'norm NEW:docs/routines dizin', 'bağımsız normalizasyon da dizin'; negatif test: claim'ler kapalıyken denetim çakışma buluyor"),
("R2-N2", "MEDIUM", "Reseal öncesi update-branch kuralı yok", "CLOSED", "Reseal üyesinin iş tanımına eklendi: kilit başında update-branch, sonra reseal; base kilitle sabit", "02_* matrisinde ilgili Task'ların `work` alanı; 09_* reseal kuralı"),
("R2-N3", "MEDIUM", "LLM Task'ları register'a yazıyor", "CLOSED", "UASCO-T0101 ve T0102 Founder kararı oldu; V3-T1021 eşleme dosyasını repo PR'ı olarak yazıyor (deterministik içe aktarma); UASCO-T0123 `registries/` (T2). Build kuralı: register-yalnız hedefli Task'lar yalnız deterministik olabilir", "self-test 'register'a LLM yazmıyor'; build kontrolü 'LLM writes register' = 0"),
("R2-N4", "LOW", "docs/policy düşük tier", "CLOSED", "docs/policy/ yetki-hassas (T2); Haiku yok", "self-test 'docs/policy T2'"),
]
cl += ["", "## Bağımsız review (tur 2) bulguları ve kapanışı", "", "| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |", "|---|---|---|---|---|---|"] + [f"| {a} | {b} | {c} | **{d}** | {e} | {g} |" for a, b, c, d, e, g in RV2]
RV3 = [
("R3-L1", "MEDIUM", "Kilit süresince Founder rezerve değil; sahte iptaller", "CLOSED", "Kilit süresince Founder yalnız kilitli paketin kitini yapar; zaman aşımı kit başlatılabilir olunca başlar; ön koşulsuz paketlerde zaman aşımı yok", "S3: iptal 0; S6: iptal 0 (yalnız gerçek kit başarısızlığı)"),
("R3-L2", "MEDIUM", "Kit başarısızlığında düzeltme yolu yok", "CLOSED", "NOT_ACCEPTED → kilit bırakılır, paket üyeleri yeniden açılır (aynı PR'da düzeltme, claim'ler pakette), kit yeniden koşulur", "S6: kit 1 kez başarısız → onarım → 167/167, kilitlenme 0, kilit/freeze ihlali 0"),
("R3-L3", "MEDIUM", "Eskalasyonun çıkışı yok", "CLOSED", "Eskalasyon kararı: PR-231 → D-03 (yeniden dene / yeniden tasarla / ertele); karar yoksa paket DEFERRED, claim'ler serbest, bağımlılar BLOCKED_DECISION", "S5 ve S7: eskalasyon sonrası claim'ler serbest; kalan Task'ların nedeni 'D-03 (eskalasyon)'; kilit sonda serbest"),
("R3-L4", "LOW", "V3-T1021 register'a T1 yoldan giriyor", "CLOSED", "docs/register/ yetki-hassas → T2 (Opus review + Founder onayı)", "self-test 'V3-T1021 (docs/register) T2'"),
]
cl += ["", "## Bağımsız review (tur 3) bulguları ve kapanışı", "", "| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |", "|---|---|---|---|---|---|"] + [f"| {a} | {b} | {c} | **{d}** | {e} | {g} |" for a, b, c, d, e, g in RV3]
RV4 = [
("R4-L1", "MEDIUM", "Kilit alınırken Founder zaten meşgul → sahte iptal", "CLOSED", "Kilit yalnız Founder boşken alınır; zaman aşımı kit fiilen başlayınca başlar", "S8 (Founder Task'ları 40 h): iptal 0, 167/167; S3: iptal 0"),
("R4-L2", "LOW", "S6'da kit başarısızlığı lockAborts'ta görünmüyor", "CLOSED", "Kit NOT_ACCEPTED da iptal sayacına yazılıyor", "S6 lockAborts: 1 (kit NOT_ACCEPTED)"),
("R4-L3", "LOW", "Eskalasyon mevcut D-03 kimliğini yeniden kullanıyor", "CLOSED", "Eskalasyon ayrı karar örneği (ESC-<paket>, D-03/D-07 kapsamında); devamda rebase + yeniden review + yeniden claim zorunlu", "S5/S7 nedeni: 'ESC-PR-231 (yeni karar örneği …)'"),
]
RV4.append(("R5-LOW", "LOW", "Kilit alındıktan sonra kit başlamazsa kilit süresi sınırsız", "CLOSED", "Kit öncesi zaman aşımı 8 h (LOCK_PREKIT_TIMEOUT_H) → iptal; 2 iptal → eskalasyon", "S9: Founder kilitten sonra kayboluyor → iptal + eskalasyon, kilit sonda serbest"))
cl += ["", "## Bağımsız review (tur 4) bulguları ve kapanışı", "", "| ID | Önem | Bulgu | Durum | Düzeltme | Kanıt |", "|---|---|---|---|---|---|"] + [f"| {a} | {b} | {c} | **{d}** | {e} | {g} |" for a, b, c, d, e, g in RV4]
cl += ["", f"**Bedel (Founder'ın bilmesi gereken):** güvenlik sıkılaştırmasından sonra açık Task'ların T2 sayısı **{S['tiers'].get('T2', 0)}** (önceki: 35). Bunların hepsi Founder T2 onayıyla merge edilir. D-31 (toplu onay takvimi) bu yüzden daha kritik hâle geldi. S1'de (yalnız D-01) {s1['completed']} Task tamamlanabiliyor; geri kalanların çoğu D-31'i bekliyor."]
cl += ["", "## Doğrulama sırasında bulunan ek hatalar (denetimde yoktu; düzeltildi)", "",
       "1. Sahiplik eşleşmesinde boş önek (`PR247:` normalize edilince boş string) her yolla eşleşiyordu; register ve EXT yolları D lane'e düşüyordu. Düzeltildi: önek ham eşleştirme + kanonik eşleştirme ayrımı.",
       "2. tests/docs dosyaları Feature'ın V4 lane'ine düşüyor ve sahte karma owner üretiyordu (ör. UASCO-T0031.a). Düzeltildi: tests/docs Task'ın birincil lane'inde kalır; claim yine yol bazında.",
       "3. Founder karar Task'ları (UASCO-T0113, T0082) Feature modül varsayılanıyla repo dosyası 'tutuyordu' (S3'te 1 sahte çakışma). Düzeltildi: hedef EXT:Founder kararı; Founder Task'ları claim tutmaz.",
       "4. Dispatch önceliği kritik yolu ikinci sıraya atıyordu. Düzeltildi: öncelik R1 → en uzun kalan zincir.", "",
       "## Kalan açık noktalar (hazır olma hükmünü etkileyenler)", "",
       "- Windows'ta `verify.py` NOT_RUN (ortam yok).",
       "- Bulut çalışma zamanı (D-03 sandbox/worker sağlayıcısı) UNKNOWN: paket READY_FOR_CODING olabilir, PRODUCT_READY değildir. Founder-PC yalnız `.exe` UAT.",
       "- Bağımsız reviewer sonucu: 15_INDEPENDENT_REVIEW.md."]
open(f"{OUT}/12_EX_FINDINGS_CLOSURE.md", "w").write("\n".join(cl) + "\n")
# ---------------------------------------------------------------- 14 test evidence (build-time)
te = ["# 14 — Test Kanıtları (üretim anında)", "", "## Self-test'ler (build.py)", "", "| Test | Sonuç |", "|---|---|"] + [f"| {k} | {'PASS' if v else 'FAIL'} |" for k, v in S['selftest']]
te += ["", f"## Statik kontroller", "", f"- Hata listesi: {S['errors'] if S['errors'] else 'boş (0)'}",
       "- Kontrol edilenler: eksik bağımlılık · geçersiz durum · SPLIT konteynerine bağımlılık · dalga tersliği · döngü · kapsanmayan AC · Task'sız Feature · kalan karma owner · Haiku'nun hassas dosyada kullanılması · korumalı dosyada T0 · repo dosyasında CI'sız commit · bilinmeyen karar kapısı · R1 kapanışında W1 sonrası Task",
       "", "## Simülasyon", "", "| Senaryo | Tamamlanan | Kilitlenme | Yazma çakışması | En çok slot |", "|---|---|---|---|---|"]
for n, v in SIM.items():
    if n == "NEGATIVE_TESTS": te.append(f"| NEGATIVE_TESTS (beklenen > 0) | claim'ler kapalı: {v['summary']['NEG_CLAIMS_DISABLED']['independentAuditConflicts']} çakışma | kilit kapalı: {v['summary']['NEG_LOCK_DISABLED']['lockViolations']} ihlal | — | — |"); continue
    sm = v['summary']; te.append(f"| {n} | {sm.get('completed')}/{sm.get('total', '—')} | {len(sm.get('deadlocks', []))} | {sm.get('writeConflicts', 0)} | {sm.get('maxSlotsUsed', 0)} |")
te += ["", "Kalan kapı nedenleri (S2):", "", "```", json.dumps(s2['blockedBy'], ensure_ascii=False, indent=1), "```", "", "Yeniden üretim ve manifest kontrolü sonuçları: `verify.py` çıktısı (16_VERIFY_RUN_LINUX.txt)."]
open(f"{OUT}/14_V4_1_TEST_EVIDENCE.md", "w").write("\n".join(te) + "\n")
# ---------------------------------------------------------------- 17 cloud-only merge report
co = M['meta']['cloudOnly']
rep17 = ["# 17 — Cloud-Only Birleştirme Raporu (V4.1 PATCHED 241 + CLOUD_ONLY_CHANGE_REQUEST 2026-11-02)", "",
         "Kaynaklar: `sources/v41_patched/` (PATCHED 241 çıktısı, SHA manifestiyle doğrulandı), `sources/cloud/CLOUD_ONLY_CHANGE_MATRIX.json` (MERGE_ONLY; 175 tabanlı). Üretici: `v41/cloud_only.py` (kurallar CO-1..CO-10).", "",
         f"- Task: {S['tasks']} (= 241 PATCHED + {len(co['newTasks'])} CLOUD-T). Override uygulanan mevcut Task: {len(co['overrides'])}.",
         f"- Statik hata: {len(S['errors'])} · self-test: {sum(1 for x in S['selftest'] if x[1])}/{len(S['selftest'])} · kanıt PASS sayacı: {S['evidence']['EVIDENCE_VERIFIED_PASS_COUNT']}",
         "- Durum: READY_FOR_CODING adayı (bulut çalışma zamanı UNKNOWN) · PRODUCT_READY DEĞİL.", "", "## Uygulama günlüğü", ""] + [f"- {x}" for x in co['log']]
rep17 += ["", "## Bilinçli olarak uygulanmayan / farklı uygulanan alanlar", "",
          "- Override `authorityTier` daha düşükse uygulanmadı (CO-2; ör. V3-T1010 T1, UASCO-T0003/T0061 T1, V3-T1019 T0).",
          "- Override `lane` yalnız öneri; PATCHED owner + karma-owner bölme kuralı geçerli; sapmalar `laneHint` alanında.",
          "- PR-231 üyelerinin targetFiles'ı korunur (CO-4); bulut hedef dosyaları CLOUD-T0002/T0014 kapsamında.",
          "- D-23 hiçbir Task'tan kaldırılmadı (gate düşürme yok); D-23 anlamı artık yalnız `.exe` UAT.",
          "- sim.py R4-L1 düzeltmesi: kit süresi kit başladığı anda başlar (önceden bir sonraki olaya kadar gecikebiliyordu). Düzeltilmiş sim orijinal PATCHED verisinde de 0 hata verir."]
open(f"{OUT}/17_CLOUD_ONLY_MERGE_REPORT.md", "w").write("\n".join(rep17) + "\n")
print("closure ok")
