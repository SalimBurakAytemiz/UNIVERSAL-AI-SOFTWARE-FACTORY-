# Cloud-only birleştirme aşaması (CLOUD_ONLY_CHANGE_REQUEST 2026-11-02 → V4.1 PATCHED 241). Yeni roadmap değildir.
# Kurallar (CO-1..CO-9):
#  CO-1 241 PATCHED Task'ın hiçbiri silinmez/yeniden adlandırılmaz (ID korunur); 15 CLOUD-T Task eklenir.
#  CO-2 Tier asla düşmez: max(PATCHED tier, override tier, yeniden türetilen tier).
#  CO-3 Gate ve bağımlılıklar birleşim (union) olarak uygulanır; override yalnız sıkılaştırır.
#  CO-4 PR paketi üyeleri (PR-231) gerçek changed-files write-set'ini korur; #231 DO_NOT_MERGE_AS_IS (D-07, D-03).
#  CO-5 Split ebeveynde (V3-T1010, V3-T1013) override, Founder-PC çocuğunu buluta taşır (ID korunur).
#  CO-6 Founder-PC yalnız .exe kur/aç/kullan kabulü: UASCO-T0002, UASCO-T0002.a. Diğer EXT:Founder-PC hedefleri kalmaz.
#  CO-7 #231 kabul kiti (UASCO-T0031.c) hosted Windows runner'da koşar (EXT:Cloud-Windows-Runner); reseal-lock,
#       kit SHA, kit hatası ve eskalasyon mekaniği aynen korunur (sim ext-env = Founder-PC ∪ Cloud-Windows-Runner).
#  CO-8 AC kimlikleri korunur; AC ölçütü ortam bazlı değişir, tarihsel ölçüt saklanır; kanıt PASS sayacı 0.
#  CO-9 31 karar kimliği korunur; override alanları başlık/seçenek/öneri/bloke üzerine yazılır, eskisi 'historical' altında.
import json, os
H = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(H)
PKG = os.environ.get("V41_PACKAGE_ROOT") or ROOT
CM = json.load(open(f"{PKG}/sources/cloud/CLOUD_ONLY_CHANGE_MATRIX.json", encoding="utf-8"))
BASE = json.load(open(f"{PKG}/sources/v41_patched/02_V4_1_EXECUTION_MATRIX.json", encoding="utf-8"))
BASE_T = {t['id']: t for t in BASE['tasks']}
OV = CM['existingTaskOverrides']; NEW = {t['id']: t for t in CM['newTasks']}
UAT_ONLY = ("UASCO-T0002", "UASCO-T0002.a")
CLOUD_RUNNER = "EXT:Cloud-Windows-Runner (hosted; GitHub-hosted windows-latest)"
CLOUD_EVIDENCE = "EXT:Actions artifact (cloud hosted run evidence)"
KIT = "UASCO-T0031.c"
TIER_RANK = {"T0": 0, "T1": 1, "T2": 2, "T3": 3}
PH_OF_WAVE = {"W0": "P0", "W1": "P1", "W2": "P2", "W3": "P3", "W4": "P4", "W5": "P5"}
LOG = []   # uygulanan / bilinçli uygulanmayan alanlar (rapor)

def ext_env(t):
    return any(f.startswith(("EXT:Founder-PC", "EXT:Cloud-Windows-Runner")) for f in t['targetFiles'])

def split_parent(tid): return BASE_T.get(tid, {}).get('v31Status') == "SPLIT"

def add_new_tasks(T, mk):
    """H1: 15 CLOUD-T Task'ı (CO-1)."""
    for tid, n in NEW.items():
        assert tid not in T, f"CLOUD id clash {tid}"
        mk(tid, dict(feature=n['v3Feature'], name=n['name'], phase=n['phase'], work=n['work'], done=n['done'], deps=n['dependsOn'], eff=n['effort'], parent="", src=n['source']))
        T[tid]['v31Status'] = "PROPOSED_CLOUD_ONLY"
        T[tid].update(executionLocation="CLOUD", localRuntimeRequired=False, cloudOnlyOverride=True)
    LOG.append(f"CO-1 added {len(NEW)} CLOUD tasks")
    for u in UAT_ONLY:
        have = {d[0] for d in T[u]['deps']}
        for d in UAT_PREREQ:
            if d not in have: T[u]['deps'].append([d, None]); T[u]['dependsOn'].append(d); LOG.append(f"CO-6 {u}: UAT ön koşulu {d}")

UAT_PREREQ = ["CLOUD-T0011", "CLOUD-T0006"]   # UAT öncesi cloud e2e CI + hosted Windows installer PASS
def apply_text_deps(T, bundle_members):
    """H1: name/work/done ve bağımlılık birleşimi (CO-3). Split ebeveynde metin ebeveyne, iş Founder-PC çocuğuna (CO-5, H3'te)."""
    for tid, o in OV.items():
        t = T[tid]
        t['cloudOnlyOverride'] = True; t['executionLocation'] = o.get('executionLocation', "CLOUD"); t['localRuntimeRequired'] = bool(o.get('localRuntimeRequired', False))
        t['historicalName'] = t['name']; t['name'] = o['name']; t['work'] = o['work']; t['done'] = o['done']
        if split_parent(tid): LOG.append(f"CO-5 {tid}: split parent; deps/files applied to Founder-PC child"); continue
        have = {d[0] for d in t['deps']}
        for d in o.get('dependsOn', []):
            if d not in have: t['deps'].append([d, None]); t['dependsOn'].append(d)
        if tid in bundle_members:
            t['cloudOnlyStatus'] = "DO_NOT_MERGE_AS_IS (#231; D-07/D-03 + CLOUD-T0002 önce)"

def apply_files(T, bundle_members):
    """H2 (bundle atamasından sonra, lane'den önce): targetFiles yer değiştirme; paket üyeleri ve split ebeveynler hariç (CO-4/CO-5)."""
    for tid, o in OV.items():
        if 'targetFiles' not in o or split_parent(tid): continue
        if tid in bundle_members:
            LOG.append(f"CO-4 {tid}: targetFiles kept (PR-231 real write set); cloud target {o['targetFiles']} owned by CLOUD-T0002/T0014"); continue
        T[tid]['historicalTargetFiles'] = T[tid]['targetFiles']; T[tid]['targetFiles'] = list(o['targetFiles'])
    for tid, n in NEW.items(): T[tid]['targetFiles'] = list(n['targetFiles'])
    T[KIT]['historicalTargetFiles'] = T[KIT]['targetFiles']; T[KIT]['targetFiles'] = [CLOUD_RUNNER]
    T[KIT]['executionLocation'] = "CLOUD"; T[KIT]['cloudOnlyOverride'] = True
    T[KIT]['work'] = "#231 son head SHA'sı (reseal sonrası) üzerinde kabul kiti hosted Windows runner'da koşar; Founder-PC'de koşmaz. Kit SHA, lock timeout ve kit hatası kuralları aynen geçerli. #231 AS-IS merge edilmez (D-07)."

DETERMINISTIC_CLOUD = {KIT} | {tid for tid, n in NEW.items() if n['targetFiles'] and all(f.startswith("EXT:register") for f in n['targetFiles'])}
def lane_override(tid):
    """H3a: override/yeni/kit Task'ları FOUNDER sabit listesinden çıkar; lane PATCHED owner + karma-owner bölme kuralıyla türetilir (AUTO).
    UAT Task'ları F_FOUNDER kalır. Override'daki lane yalnız öneri: sapma 'laneHint' olarak kaydedilir."""
    if tid in UAT_ONLY: return None
    if tid == KIT or (tid in OV and not split_parent(tid)) or tid in NEW: return "AUTO"
    return None

def after_split(T, splits, lane_of_file):
    """H3b: Founder-PC çocuklarını buluta taşı (CO-5, CO-6)."""
    for p in ("V3-T1010", "V3-T1013"):
        o = OV[p]
        for k in splits.get(p, []):
            c = T[k]
            if any(f.startswith("EXT:Founder-PC") for f in c['targetFiles']):
                c['historicalTargetFiles'] = c['targetFiles']; c['targetFiles'] = list(o['targetFiles'])
                c['lane'] = lane_of_file(c['targetFiles'][0], c) or o['lane']; c['name'] = o['name'] + " — bulut koşusu"; c['work'] = o['work']; c['done'] = o['done']
                c.update(executionLocation="CLOUD", localRuntimeRequired=False, cloudOnlyOverride=True, v31Status="PROPOSED_CLOUD_ONLY")
                have = {d[0] for d in c['deps']}
                for d in o.get('dependsOn', []):
                    if d not in have: c['deps'].append([d, None])
                c['dependsOn'] = [d[0] for d in c['deps']]
                LOG.append(f"CO-5 {k}: Founder-PC → cloud ({o['targetFiles']})")
    left = [k for k, t in T.items() if k not in UAT_ONLY and t.get('v31Status') != "SPLIT" and any(f.startswith("EXT:Founder-PC") for f in t['targetFiles'])]
    assert not left, f"CO-6 Founder-PC remains: {left}"
    for tid, o in list(OV.items()) + list(NEW.items()):
        if tid in T and o.get('lane') and T[tid].get('lane') not in (o['lane'], "—"): T[tid]['laneHint'] = f"override önerisi {o['lane']}; PATCHED owner kuralı {T[tid]['lane']}"

def completes_override(t):
    if t['id'] == KIT: return "ACCEPTED"   # kit kabulü: tip korunur (TYPED_DEPS)
    return None

def tier_floor(T):
    """H4: CO-2."""
    for tid, t in T.items():
        cands = [t['authorityTier']]
        if tid in BASE_T and BASE_T[tid]['authorityTier'] in TIER_RANK: cands.append(BASE_T[tid]['authorityTier'])
        o = OV.get(tid) or NEW.get(tid)
        if o and o.get('authorityTier') in TIER_RANK: cands.append(o['authorityTier'])
        top = max(cands, key=TIER_RANK.get)
        if top != t['authorityTier']:
            t['tierReason'] = f"CO-2 tier floor ({t['authorityTier']}→{top}; PATCHED/override düşürülmez) · " + t['tierReason']; t['authorityTier'] = top

def gates_union(T, MERGE_GATES):
    """H5: CO-3 (D-31 T2 kuralı da yeniden uygulanır)."""
    for tid, t in T.items():
        o = OV.get(tid) or NEW.get(tid)
        sg, mg = list(t['startGates']), list(t['mergeGates'])
        if tid in BASE_T and not split_parent(tid):
            sg += [g for g in BASE_T[tid]['startGates'] if g not in sg]
            mg += [g for g in BASE_T[tid]['mergeGates'] if g not in mg]
        if o:
            sg += [g for g in o.get('startGates', []) if g not in sg]; mg += [g for g in o.get('mergeGates', []) if g not in mg]
        if tid in OV and tid.startswith(("UASCO-T0031", "UASCO-T0069.c")):
            for g in ("D-03", "D-07"):
                if g not in mg: mg.append(g)
        if tid == KIT:
            for g in ("D-03", "D-07"):
                if g not in sg: sg.append(g)
        if t['authorityTier'] in ("T2", "T3") and "D-31" not in mg and t['v31Status'] not in ("ASSET_DONE", "ASSET_CODED_UNWIRED", "DONE_OBSERVED", "SPLIT"): mg.append("D-31")
        t['startGates'], t['mergeGates'] = sg, mg; t['gates'] = sg + mg

def wave_override(T):
    for tid, o in list(OV.items()) + list(NEW.items()):
        if o.get('wave') and not split_parent(tid): T[tid]['wave'] = o['wave']

import re as _re
_FPC = [(r"Founder-PC'de", "hosted Windows runner'da (cloud E2E)"), (r"Founder-PC kanıtı", "hosted Windows runner kanıtı (cloud E2E)"), (r"Founder-PC", "hosted Windows runner (cloud E2E)")]
def done_override(T):
    for tid, o in OV.items():
        if not split_parent(tid): T[tid]['doneMerge'] = o['done']
    # CO-11: override'sız Task'larda Founder-PC kanıt şartı → hosted Windows runner (UAT Task'ları hariç)
    for tid, t in T.items():
        if tid in UAT_ONLY or tid in OV or tid in NEW or tid == KIT or t.get('cloudOnlyOverride') or t.get('parentId') in OV: continue
        for f in ("doneMerge", "work"):
            v = t.get(f, "")
            if "Founder-PC" in v and "never Founder-PC" not in v and "Founder-PC worker YOK" not in v:
                nv = v
                for a, b in _FPC: nv = _re.sub(a, b, nv)
                t.setdefault('historicalDone', {})[f] = v; t[f] = nv; LOG.append(f"CO-11 {tid}.{f}: Founder-PC kanıtı → hosted Windows runner")

def apply_ac(AC):
    """CO-8."""
    n = 0
    for a in CM['acceptanceOverrides']:
        r = AC[a['acId']]
        r['historicalCriterion'] = a.get('historicalCriterion', r['criterion']); r['historicalEnvironment'] = a.get('historicalEnvironment', "")
        r['criterion'] = a['criterion']; r['environment'] = a['environment']; n += 1
    LOG.append(f"CO-8 AC overrides {n}")

def apply_decisions(dj):
    """CO-9: dj = 06 JSON karar listesi (dict)."""
    by = {d['id']: d for d in dj}
    for did, o in CM['decisionOverrides'].items():
        d = by[did]; d['historical'] = {k: d.get(k) for k in o}
        d.update(o); d['cloudOnlyOverride'] = True
        for f in ("why", "riskCost"):
            if any(w in str(d.get(f, "")) for w in ("WSL", "Founder-PC", "Win11", "40–120")):
                d['historical'][f] = d[f]; d[f] = "CLOUD-ONLY: önceki yerel/WSL gerekçesi ve tahmini STALE (historical altında). Bulut sağlayıcı tahminleri geçici; teslim tarihi garantisi yok."
    LOG.append(f"CO-9 decision overrides {len(CM['decisionOverrides'])}")

RANK = {"PLANNED": 0, "READY": 1, "CODING": 2, "CODE_READY": 3, "REVIEWED": 4, "MERGED": 5, "ACCEPTED": 6, "DONE": 6}
def retype_deps(T):
    """CO-10: Founder-PC → bulut dönüşümüyle tamamlanma durumu değişen Task'a tipli bağımlılık, ulaşılamaz bir duruma
    (ör. ACCEPTED, artık MERGED ile biten bulut Task'ı) işaret ediyorsa yeni tamamlanma durumuna yeniden tiplenir. Bağımlılık silinmez."""
    for k, t in T.items():
        for d in t['deps']:
            dep = T.get(d[0])
            if not dep or dep.get('completesAt') in (None, "—"): continue
            if d[0] in BASE_T and BASE_T[d[0]]['completesAt'] != dep['completesAt'] and RANK.get(d[1], 0) > RANK.get(dep['completesAt'], 0):
                LOG.append(f"CO-10 {k}: dep {d[0]}:{d[1]} → {d[0]}:{dep['completesAt']} (Founder-PC → cloud)"); d[1] = dep['completesAt']
