# V4.1 tek veri kaynağı (yazılmış kurallar + override'lar). build.py bunu V3.1 JSON + V4 manifest + kanonik JSON ile birleştirir.
BASE = dict(repo="SalimBurakAytemiz/UNIVERSAL-AI-SOFTWARE-FACTORY-", branch="v7/integration", sha="16d3a925b8a3f4ffc08dea2ea64c53862a7bcb03",
            ci_run=41434581692, installer_run=41434581581, artifact_id=13135209964, artifact_bytes=111397611, artifact_zip_digest="sha256:c44e21bfdfd61cfed5470dfe8a2a5abae199a8ed5ca29eee03dce705c583872d",
            artifact_expires="2026-12-02T11:14:14Z", reports_branch="uasco/production-reports", reports_sha="770c5513ac74", queue_sha="122a1b12d539",
            open_prs=["#282 (DEFER_TO_ROADMAP, head 5d66b03, auto-merge kapalı)", "#251 (draft, f40bea3)", "#247 (draft, 323c14f)", "#231 (draft, c9a3e2d)", "#66 (draft, ffeaf79)"],
            waiting_runs=["39687649214 (UASCO Independent Review, 2026-10-21, waiting)"])
# ---- Feature → hedef modüller (doğrulanır: tree / PR231 / NEW / EXT)
MODULES = {
 "V3-F001":["apps/desktop/main.mjs","apps/control-api/src/packaged-entry.ts","apps/desktop/renderer/views/setup-check.js"],
 "V3-F002":["apps/desktop/renderer/","apps/desktop/renderer/app.js"],
 "V3-F003":["core/mission/command-intake.ts","apps/control-api/src/routes/intake.ts","apps/desktop/renderer/views/intake.js"],
 "V3-F004":["apps/desktop/renderer/views/work.js","core/workos/plan.ts"],
 "V3-F005":["apps/desktop/main.mjs","apps/desktop/renderer/views/delivery-panel.js"],
 "V3-F006":["apps/desktop/renderer/","NEW:core/workos/revision (keşif)"],
 "V3-F007":["apps/desktop/renderer/","apps/desktop/main.mjs"],
 "V3-F008":["apps/desktop/renderer/views/home.js","apps/control-api/src/routes/"],
 "V3-F009":["apps/desktop/main.mjs","installer/electron-builder.json","core/workos/store.ts"],
 "V3-F010":["installer/","scripts/build-installer.mjs"],
 "V3-F011":["core/workos/predev/"],
 "V3-F012":["core/workos/runner.ts","core/workos/executors.ts"],
 "V3-F013":["core/workos/execution-gate.ts","core/agents/linux-unshare-sandbox.ts","PR231:core/sandbox/wsl-unshare-sandbox.ts","PR231:core/sandbox/select-provider.ts"],
 "V3-F014":["core/workos/security-tools.ts","core/workos/secret-scan.ts","core/qa/"],
 "V3-F015":["apps/control-api/src/server.ts","core/workos/zip.ts"],
 "V3-F016":["core/workos/project-templates.ts","templates/"],
 "V3-F017":["NEW:core/delivery/github-adapter (keşif)","apps/control-api/src/routes/"],
 "V3-F018":["NEW:core/workos/docs-generator (keşif)"],
 "V3-F019":["core/workos/runner.ts","core/workos/run-state.ts"],
 "V3-F020":["core/workos/crew/"],
 "V3-F021":["core/workos/runner.ts","core/workos/crew/"],
 "V3-F022":["core/workos/runner.ts","core/workos/run-state.ts"],
 "V3-F023":["docs/planning/dispatch.mjs","automation/lib/"],
 "V3-F024":["core/agents/first-delivery-bindings.ts","registries/"],
 "V3-F025":["core/workos/executors.ts","core/workos/claude-profiles.ts","core/workos/executor-setup.ts"],
 "V3-F026":["models/router/router.ts","core/policy/model-routing.ts"],
 "V3-F027":["core/workos/executors.ts","core/workos/store.ts"],
 "V3-F028":["models/omniroute/client.ts","config/omniroute-policy.json"],
 "V3-F029":["core/workos/test-surface.ts"],
 "V3-F030":["config/protected-paths.json","config/trust-root-manifest.json"],
 "V3-F031":["EXT:GitHub ruleset","/.github/workflows/uasco-independent-review.yml"],
 "V3-F032":["core/action-gateway/","apps/control-api/src/server.ts"],
 "V3-F033":["package.json","package-lock.json"],
 "V3-F034":["EXT:GitHub repo security settings"],
 "V3-F035":["apps/mobile/","config/validation.json"],
 "V3-F036":["apps/mobile/","apps/control-api/src/routes/"],
 "V3-F037":["apps/mobile/","apps/control-api/src/routes/"],
 "V3-F038":[".github/workflows/ci.yml","scripts/validate-shards.mjs","core/workos/store.ts"],
 "V3-F039":[".github/workflows/windows-installer.yml","scripts/build-installer.mjs","scripts/installer-install-test.mjs"],
 "V3-F040":["installer/","NEW:.github/workflows/release (keşif)"],
 "V3-F041":["scripts/e2e-first-delivery-electron.mjs","NEW:.github/workflows/desktop-e2e (keşif)"],
 "V3-F042":[".github/workflows/uasco-independent-review.yml","scripts/ci/uasco-review/"],
 "V3-F043":["EXT:register dalı (supervisor)"],
 "V3-F044":["EXT:GitHub Actions runners ayarı"],
 "V3-F045":["EXT:coord-ledger (uasco/production-queue)","docs/planning/dispatch.mjs"],
 "V3-F046":["NEW:supervisor bütçe aracı (register dalı)"],
 "V3-F047":["EXT:claude.ai routines","NEW:docs/routines (prompt sürümleri)"],
 "V3-F048":["EXT:register dalı (supervisor)"],
 "V3-F049":["EXT:register dalı (supervisor)"],
 "V3-F050":["core/workos/plan.ts","core/workos/predev/","apps/desktop/renderer/views/work.js"],
 "V3-F051":["core/workos/runner.ts","core/workos/task-selector.ts"],
 "V3-F052":["EXT:GitHub ruleset",".github/workflows/ci.yml"],
 "V3-F053":["EXT:coord-ledger (uasco/production-queue)"],
 "V3-F054":["scripts/validate-shards.mjs",".github/workflows/ci.yml"],
 "V3-F055":["NEW:tests/eval/ (keşif)","registries/"],
 "V3-F056":["NEW:config/authority-matrix.json"],
 "V3-F057":["apps/control-api/src/server.ts","NEW:scripts/delivery-repro.mjs"],
}
# Task-özel hedef dosyalar (feature varsayılanını daraltır)
TASK_FILES = {
 "UASCO-T0038":["EXT:Founder kararı (D-02)"], "UASCO-T0028":["EXT:register dalı (supervisor)"], "UASCO-T0008":["EXT:register dalı (supervisor)"],
 "UASCO-T0023":["installer/electron-builder.json"], "UASCO-T0125":["core/workos/claude-profiles.ts","core/workos/executors.ts"], "UASCO-T0126":["core/workos/store.ts"],
 "UASCO-T0026":["core/workos/predev/","NEW:docs/predev-rubric.md"], "V3-T1022":["core/workos/plan.ts","NEW:core/workos/plan-schema (keşif)"], "V3-T1023":["apps/desktop/renderer/views/work.js"],
 "UASCO-T0091":[".github/workflows/ci.yml"], "UASCO-T0080":["apps/mobile/"], "V3-T1007":[".github/workflows/ci.yml","NEW:docs/ci/BASE-RED-POLICY.md"],
 "UASCO-T0016":["apps/desktop/main.mjs"], "UASCO-T0031":["PR231:core/sandbox/wsl-unshare-sandbox.ts","PR231:core/sandbox/select-provider.ts","core/workos/execution-gate.ts"],
 "UASCO-T0031.b":["apps/control-api/src/server.ts"], "UASCO-T0069.c":["config/trust-root-manifest.json"], "UASCO-T0100.a":["config/trust-root-manifest.json","PR247:scripts/autonomy-hardening-selftest.mjs"],
 "UASCO-T0031.a":["apps/desktop/renderer/views/setup-check.js","NEW:docs/acceptance/windows/WSL2-PREP.md"],
 "V3-T1001":["core/workos/store.ts"], "V3-T1002":["scripts/validate-shards.mjs",".github/workflows/ci.yml"], "V3-T1003":["scripts/validate-shards.mjs"], "V3-T1036":["scripts/validate-shards.mjs"],
 "V3-T1012":["NEW:scripts/delivery-repro.mjs"], "V3-T1012.a":["core/workos/project-templates.ts"], "V3-T1011":["apps/control-api/src/server.ts","core/workos/zip.ts"],
 "V3-T1014":["core/workos/executors.ts"], "V3-T1015":["core/workos/executors.ts","core/workos/store.ts"], "V3-T1016":["core/workos/run-state.ts","core/workos/runner.ts"],
 "UASCO-T0003":["core/workos/claude-profiles.ts"], "UASCO-T0061":["core/workos/claude-profiles.ts","core/workos/executor-setup.ts"], "UASCO-T0061.a":["core/workos/claude-profiles.ts"],
 "UASCO-T0069.a":["config/protected-paths.json","config/trust-root-manifest.json"], "UASCO-T0069.b":["config/protected-paths.json","config/trust-root-manifest.json"],
 "UASCO-T0023.a":["apps/desktop/main.mjs"],
 "UASCO-T0004":["apps/desktop/main.mjs"], "UASCO-T0006":["NEW:tests/ (renderer→real-server)"], "UASCO-T0088":["core/workos/store.ts","NEW:tests/ (Windows deterministik)"],
 "UASCO-T0090":["EXT:PR #282 (karar)"], "UASCO-T0100":["EXT:PR #251/#247/#231 (karar)"], "UASCO-T0096":["EXT:PR #66 (karar)"],
 "UASCO-T0081":["config/validation.json"], "UASCO-T0122":["EXT:register dalı (supervisor)"], "V4-T0001":["EXT:Actions artifact 13135209964","EXT:register dalı (supervisor)"],
 "V4-T0002":["EXT:Founder-PC (Task Scheduler, süreçler)"], "UASCO-T0002":["EXT:Founder-PC"], "V3-T1019":["NEW:docs/acceptance/windows/R1-CHECKLIST.md"],
 "UASCO-T0014":["EXT:Founder-PC"], "UASCO-T0029":["EXT:Founder-PC"], "UASCO-T0035":["EXT:Founder-PC"], "UASCO-T0044":["EXT:Founder-PC"], "V3-T1018":["EXT:Founder-PC"],
 "V3-T1013":["core/workos/predev/","EXT:Founder-PC"], "V3-T1010":["core/workos/security-tools.ts","EXT:Founder-PC"], "UASCO-T0110":["NEW:supervisor bütçe aracı (register dalı)"],
 "V3-T1004":["EXT:coord-ledger (uasco/production-queue)"], "V3-T1008":["EXT:supervisor merge kuralı"], "V3-T1020":["EXT:GitHub ruleset",".github/workflows/ci.yml"],
 "V3-T1034":["EXT:GitHub environment uasco-review (secret)"], "UASCO-T0115":["EXT:claude.ai routines"],
}
# Dosya sahipliği (X-07): önek → lane. İlk eşleşen kazanır.
OWNER_BY_PATH = [
 ("core/workos/predev/","B_API"), ("apps/control-api/","B_API"), ("NEW:scripts/delivery-repro","B_API"),
 ("core/workos/","C_ENGINE"), ("core/agents/","C_ENGINE"), ("PR231:core/sandbox/","C_ENGINE"), ("core/sandbox/","C_ENGINE"), ("core/mission/","B_API"),
 ("models/","C_ENGINE"), ("core/policy/","C_ENGINE"), ("core/action-gateway/","B_API"), ("core/qa/","C_ENGINE"), ("templates/","C_ENGINE"), ("registries/","C_ENGINE"),
 ("NEW:tests/eval","C_ENGINE"), ("NEW:core/","C_ENGINE"),
 ("apps/desktop/","A_UI"), ("NEW:docs/acceptance/","A_UI"), ("NEW:tests/ (renderer","A_UI"),
 (".github/","D_CI_RELEASE"), ("/.github/","D_CI_RELEASE"), ("scripts/validate-","D_CI_RELEASE"), ("scripts/ci/","D_CI_RELEASE"), ("scripts/build-installer","D_CI_RELEASE"),
 ("scripts/installer","D_CI_RELEASE"), ("PR247:","D_CI_RELEASE"), ("scripts/e2e","D_CI_RELEASE"), ("installer/","D_CI_RELEASE"), ("config/","D_CI_RELEASE"), ("package","D_CI_RELEASE"),
 ("NEW:.github","D_CI_RELEASE"), ("NEW:tests/ (Windows","C_ENGINE"),
 ("apps/mobile/","E_CONTROL"), ("docs/planning/","E_CONTROL"), ("automation/","E_CONTROL"), ("NEW:supervisor","E_CONTROL"), ("NEW:docs/routines","E_CONTROL"),
 ("EXT:register","E_CONTROL"), ("EXT:coord-ledger","E_CONTROL"), ("EXT:supervisor","E_CONTROL"), ("EXT:claude.ai","E_CONTROL"), ("EXT:Actions artifact","E_CONTROL"),
 ("EXT:Founder","F_FOUNDER"), ("EXT:PR #","F_FOUNDER"), ("EXT:GitHub","F_FOUNDER"),
]
BUILDER_LANES = ["A_UI", "B_API", "C_ENGINE", "D_CI_RELEASE"]   # en fazla 3 eşzamanlı slot
# T3: dış sistem / secret / ücretli / release / deploy
T3 = {"UASCO-T0093":"İmzalı release (code-signing)","UASCO-T0039":"Müşteri repo'suna push/PR (dış sistem)","UASCO-T0040":"Deploy (dış ortam)","UASCO-T0066":"İkinci sağlayıcı/ücretli API",
      "UASCO-T0097":"Reviewer App/OAuth secret","V3-T1034":"Environment secret (CLAUDE_CODE_OAUTH_TOKEN)","V3-T1020":"Ruleset değişikliği","UASCO-T0072":"Ruleset değişikliği","UASCO-T0078":"Repo güvenlik ayarları",
      "UASCO-T0103":"Actions runner ayarı","UASCO-T0113":"Repo görünürlüğü"}
# Model kuralları: (start, escalate)
OPUS_FIRST = {"UASCO-T0031":"Opus: tek seferlik çakışma/tehdit analizi + T2 review; rebase Sonnet","V3-T1022":"Opus: şema + idempotency anahtarı tasarımı (≤1 sayfa), sonra Sonnet",
              "UASCO-T0023.a":"Opus: utilityProcess göç tasarımı, sonra Sonnet","V3-T1031":"Opus: DAG checkpoint tasarımı, sonra Sonnet","UASCO-T0051":"Opus: lease zorunlu mod tasarımı",
              "UASCO-T0070":"Opus: imza/anahtar tasarımı (güvenlik)","V3-T1035":"Opus: ürün bulut devri tasarımı","UASCO-T0125":"Opus: CLI sandbox tehdit modeli"}
HAIKU = {"V3-T1012.a":"Şablona kilit dosyası (mekanik, testli)","UASCO-T0121":"Kural dokümanı","UASCO-T0120":"Arşiv işaretleme (D-01 sonrası)","UASCO-T0117":"Prompt kopyalarını repo'ya alma (docs)",
         "UASCO-T0116":"Heartbeat kararını uygulama notu","V3-T1019":"Kontrol listesi dokümanı","UASCO-T0008":"Arşivleme","UASCO-T0028":"Tarihsel kaydı kapatma"}
DETERMINISTIC = {"V4-T0001","V3-T1005","V3-T1006","UASCO-T0124","UASCO-T0119","UASCO-T0115"}
FOUNDER_TASKS = {"UASCO-T0101","UASCO-T0102","UASCO-T0002","UASCO-T0100","UASCO-T0096","UASCO-T0103","UASCO-T0113","UASCO-T0038","V4-T0002","UASCO-T0082","UASCO-T0090"}
# Kararla kapılanan Task'lar (merge/başlangıç kapısı)
GATES = {
 "UASCO-T0016":["D-31"], "UASCO-T0031":["D-03"], "UASCO-T0069.c":["D-03","D-07","D-31","D-23"], "UASCO-T0100.a":["D-07","D-31"], "UASCO-T0069.a":["D-07","D-31"], "UASCO-T0069.b":["D-07","D-31"],
 "V3-T1002":["D-18","D-31"], "V3-T1003":["D-18","D-31"], "V3-T1036":["D-18","D-31"], "UASCO-T0002":["D-23","D-26"], "UASCO-T0014":["D-23","D-29"],
 "UASCO-T0029":["D-23","D-03"], "UASCO-T0035":["D-23","D-19"], "UASCO-T0044":["D-23"], "V3-T1018":["D-23"], "V3-T1013":["D-23"], "V3-T1010":["D-19","D-23"],
 "UASCO-T0110":["D-08"], "V3-T1034":["D-21"], "UASCO-T0098":["D-21"], "V3-T1004":["D-06"], "V3-T1020":["D-04"], "V3-T1008":["D-17"], "V3-T1007":["D-17"],
 "UASCO-T0090":["D-22"], "UASCO-T0096":["D-11"], "UASCO-T0120":["D-01"], "UASCO-T0038":["D-02"], "UASCO-T0113":["D-14"], "UASCO-T0061.a":["D-29"],
 "UASCO-T0023":["D-27"], "UASCO-T0023.a":["D-27"], "UASCO-T0037":["D-28"], "UASCO-T0040":["D-28","D-02"], "UASCO-T0066":["D-09"], "UASCO-T0059":["D-10"],
 "UASCO-T0093":["D-13"], "UASCO-T0072":["D-05"], "UASCO-T0097":["D-05"], "UASCO-T0082":["D-15"], "UASCO-T0018":["D-15"], "V4-T0002":["D-12"], "V4-T0001":["D-30"],
 "V3-T1021":["D-01"], "UASCO-T0026":["D-19"], "V3-T1037":["D-10"],
}
# Yeni / bölünmüş Task'lar (kaynak: denetim X-## / G-## / DELTA B#)
NEW_TASKS = {
 "UASCO-T0069.a":dict(parent="UASCO-T0069",feature="V3-F030",phase="P1",name="Reseal batch 1: #251 (provenance) + W1'de değişmeyecek güven sınırı dosyalarının korunması",work="#251 dalında V3-T1002/1003/1036 sonrası manifest reseal; W1'de değişmeyecek dosyalar protected-paths'e; Founder T2 onayı; merge",done="verifyTrustRoot ok; Founder T2 onayı kayıtlı; korumalı dosyaya onaysız dokunan negatif PR reddedilir; merge sonrası push CI yeşil",deps=["V3-T1002","V3-T1003","V3-T1036"],eff=(2,5),src="X-03, G-03, DELTA B3/B7"),
 "UASCO-T0069.b":dict(parent="UASCO-T0069",feature="V3-F030",phase="P1",name="Koruma genişletmesi: runner, execution-gate, security-tools, sandbox, claude-profiles (W1 kodu merge edildikten sonra)",work="RW-006 listesinin kalanını protected-paths'e ekle + reseal",done="protected-paths RW-006 listesini tam kapsar; reseal verify ok; negatif test",deps=["UASCO-T0069.c","UASCO-T0029","UASCO-T0016"],eff=(2,5),src="X-03"),
 "UASCO-T0031.a":dict(parent="UASCO-T0031",feature="V3-F013",phase="P1",name="WSL2 hazırlık runbook'u + setup-check'te sandbox self-test reason kodları",work="Ayrı UASCO WSL dağıtımı (interop=false, appendWindowsPath=false), dağıtımda node ve perl; setup-check görünümünde WSL_* / PROBE_* kodlarını göster",done="Dağıtımsız ortamda setup-check WSL_DISTRO_NOT_CONFIGURED gösterir (renderer→real-server testi); runbook Founder-PC'de uygulanabilir",deps=[],eff=(4,10),src="G-02, X-04"),
 "UASCO-T0061.a":dict(parent="UASCO-T0061",feature="V3-F025",phase="P1",name="Claude launcher değişimi senaryosu",work="Launcher hash değişiminde net Founder aksiyonu (tek tık yeniden doğrulama) + yarıda kalan run BLOCKED_RESUMABLE",done="Birim testi; Founder-PC'de 1 güncelleme sonrası yeniden doğrulama kaydı",deps=["V3-T1016"],eff=(3,8),src="G-09, X-09"),
 "UASCO-T0023.a":dict(parent="UASCO-T0023",feature="V3-F009",phase="P2",name="Paketli backend'i utilityProcess'e taşıma (RunAsNode fuse ön koşulu)",work="main.mjs backend başlatmasını ELECTRON_RUN_AS_NODE yerine utilityProcess ile yap",done="Fuse'lar uygulanmış installer'da backend HEALTHY (CI Windows)",deps=[],eff=(8,20),src="G-11, X-11"),
 "V3-T1012.a":dict(parent="V3-T1012",feature="V3-F057",phase="P1",name="Şablonlara kilit dosyası + teslimde kilit dosyası zorunlu",work="web-node/node-lib şablonlarına boş-bağımlılıklı package-lock.json; teslim kuralı",done="Temiz dizinde npm ci && npm test PASS (Linux + Windows CI)",deps=[],eff=(1,3),src="G-08 (VERIFIED npm 10.9.9), X-06"),
 "UASCO-T0031.b":dict(parent="UASCO-T0031",feature="V3-F013",phase="P1",name="#231 server.ts sağlayıcı seçici bağlaması (B_API sahipliğinde)",work="#231'deki defaultSandboxProviderFor() bağlamasını güncel server.ts'e uygula (aynı PR dalında, C'nin rebase'inden sonra)",done="SBX-GATE testleri yeşil; env/config/gövde ile sağlayıcı kaydı hâlâ reddediliyor",deps=["UASCO-T0031"],eff=(1,3),src="G-04, X-04 (sahiplik)"),
 "UASCO-T0069.c":dict(parent="UASCO-T0069",feature="V3-F030",phase="P1",name="Reseal batch 2: #231 manifest yeniden üretimi + Founder T2 onayı + merge",work="#231 dalında son commit olarak manifest reseal; FA-5 kabul kiti sonucu ACCEPTED (aynı head SHA) olmadan merge yok",done="verifyTrustRoot ok; founder-acceptance.mjs ACCEPTED (head SHA'ya bağlı); Founder T2 onayı; merge sonrası push CI + installer yeşil",deps=["UASCO-T0031","UASCO-T0031.b","UASCO-T0031.a","UASCO-T0069.a"],eff=(1,3),src="D-07 batch 2, B7"),
 "UASCO-T0100.a":dict(parent="UASCO-T0100",feature="V3-F030",phase="P1",name="#247 rebase + reseal + merge (gating değil)",work="#247'yi güncel base'e al, manifest reseal, Opus delta review, Founder T2 onayı",done="Selftest testleri yeşil; verifyTrustRoot ok; Founder T2 onayı",deps=["UASCO-T0069.a"],eff=(1,3),src="X-15, G-17, B7"),
 "V4-T0001":dict(parent="",feature="V3-F039",phase="P0",name="Installer artifact toplama ve .exe SHA kaydı (latest-known-good)",work="Deterministik: artifact 13135209964 indir → aç → .exe adı/boyut/sha256 → register EV; installer workflow smoke sonucunu job log'undan oku",done="Register'da BUILD_OK ve INSTALLER_OK EV kayıtları + .exe SHA; artifact son tarihi kayıtlı",deps=[],eff=(0.5,1),src="X-05, X-14, G-12"),
 "V4-T0002":dict(parent="",feature="V3-F047",phase="P0",name="Founder-PC yerel otomasyon doğrulaması (FA-7)",work="Founder rapor M.7'deki PowerShell adımlarını uygular; UASCO görevleri Disabled ya da yok; sonuç register'a",done="Kontrol çıktısı register'da; UASCO Task Scheduler görevleri Disabled/yok; uasco-orchestrator süreci yok",deps=[],eff=(0.25,0.5),src="DELTA B8, G-20, D-12"),
}
# Bağımlılık değişiklikleri (X-02, X-04, X-10, X-06, X-11)
DEP_SET = {"UASCO-T0016":[], "UASCO-T0031":["UASCO-T0069.a"], "UASCO-T0110":[], "V3-T1012":["V3-T1012.a"], "UASCO-T0023":["UASCO-T0023.a"],
           "UASCO-T0090":["V3-T1001","UASCO-T0088"], "UASCO-T0029":["UASCO-T0069.c","UASCO-T0031.a","UASCO-T0003","UASCO-T0061","UASCO-T0016","UASCO-T0002"], "UASCO-T0031":[],
           "UASCO-T0002":["V3-T1019","V4-T0001"]}
SPLIT_PARENTS = {"UASCO-T0069":["UASCO-T0069.a","UASCO-T0069.c","UASCO-T0069.b"]}
# Özel keşif adımları
DISCOVERY = {
 "V3-T1001":"#282 diff'ini (head 5d66b03, store.ts withLock ölçümü) ve rapor N/P'deki 4 başarısız test özetini oku; #282'yi merge etme.",
 "UASCO-T0031":"#231 merge-base → 16d3a925 farkı (173 commit); 42 dosyanın güncel base'le çakışma listesi; server.ts file-claim'i B_API'den al.",
 "V3-T1002":"#251 (f40bea3) diff'ini temel al; yeniden yazma. ci.yml ve validate-shards.mjs korumalı (T2).",
 "UASCO-T0016":"main.mjs:240-312 (deliveryExportCheck, sanitizePostBody, export-delivery handler). Kök neden: başarılı yanıtta scrubText yolu [path] yapar.",
 "UASCO-T0069.a":"#251/#247 manifest diff'leri; trust-root üretim komutu; protected-paths exactPaths/prefixes.",
 "UASCO-T0002":"Founder-PC kontrol listesi (V3-T1019) + V4-T0001 .exe SHA.",
}
# ---- DELTA_HANDOVER_V3 B1–B8 eşlemesi
BLOCKERS = [
 ("B1","#282 DEFER_TO_ROADMAP (store.ts withLock ölçümü; Windows'ta 2 farklı test kırmızı)","V3-F038","UASCO-T0090, V3-T1001, UASCO-T0088","D-22","DEFER korunur; otomatik yeniden koşu yok. Yeniden değerlendirme: V3-T1001 merge edildikten sonra, aynı head'de 3 ardışık tam yeşil Windows koşusu + base kontrol koşusu. Ölçümün Windows zamanlamasına etkisi dışlanamadığı için V3-T1001 #282 diff'ini yalnız teşhis girdisi olarak okur; store.ts tek owner C_ENGINE."),
 ("B2","Windows shard kararsızlığı (F-B1-006, relfx-c3:200, relfx-1:459, role-context:826)","V3-F038","V3-T1001, UASCO-T0088","D-20","Store-lock düzeltmesi (C_ENGINE) + deterministik test ve karantina (D_CI_RELEASE testleri). Kabul: 20 ardışık base push'ta bilinen-flake kırmızısı 0."),
 ("B3","COORD-001: 'Re-run failed jobs' aggregator'ı yeşile çeviremiyor","V3-F054","V3-T1002, V3-T1003, V3-T1036","D-18, D-31","#251 temel alınır; provenance kuralları; merge T2 (ci.yml, validate-shards.mjs korumalı). Ara kural: yalnız 'Re-run all jobs'."),
 ("B4","IR reviewer token reddi (REVIEWER_AUTH_REJECTED)","V3-F042","V3-T1034, UASCO-T0098","D-21","Founder secret işlemi ya da IR'ı resmen opsiyonel yapmak; o zamana kadar tek yetkili yol: taze alt ajan reviewer + ledger. FA-8 (39687649214 waiting) aynı kararla iptal/red."),
 ("B5","Ledger ↔ Founder environment onayı senkron değil","V3-F053","V3-T1004","D-06","API'den okunan founder-authority kaydı; o zamana kadar T2 PR'larında Founder manuel merge."),
 ("B6","Aynı dosyaya dokunan PR'lar birleşik CI olmadan merge oluyor","V3-F052","V3-T1008, V3-T1020","D-04, D-17","W0'da seri merge kuralı (V3-T1008); W2'den önce merge queue ya da zorunlu up-to-date (D-04)."),
 ("B7","Founder-tier: #251/#247/#231 manifest çakışması; #231 Windows 11/WSL2 kabulü; #66 ortak geçmişsiz","V3-F030, V3-F013, V3-F041","UASCO-T0100, UASCO-T0069.a, UASCO-T0031, UASCO-T0031.a, UASCO-T0096","D-07, D-31, D-03, D-11","Merge planı §5 (batch 1: #251→#247; batch 2: #231 FA-5 sonrası; #66 SUPERSEDED önerisi)."),
 ("B8","Founder-PC: V6 Supervisor, Task Scheduler, yerel worker UNKNOWN","V3-F047, V3-F045","V4-T0002","D-12","Founder PowerShell kontrolü; W1 paralel lane'leri açılmadan."),
]
FD_ALIAS = {"FD-A":"D-20","FD-B":"D-07","FD-C":"D-11","FD-D":"D-21","FD-E":"D-04","FD-F":"D-06","FD-G":"D-12","FD-H":"D-01 (+ D-08 bütçe)",
            "FD-01":"tamamlandı (#293 merge 6b174dc)","FD-02":"D-21","FD-03":"D-03","FD-04":"D-07","FD-05":"D-11","FD-06":"D-01/D-08","FD-07":"D-12","FD-08":"D-21 (FA-8)","FD-09":"D-01","FD-10":"D-06",
            "FA-1":"tamamlandı (#295 merge)","FA-2":"tamamlandı (#294 merge; #282 DEFER)","FA-3":"D-21","FA-4":"D-07","FA-5":"D-03 / UASCO-T0031","FA-6":"D-11","FA-7":"D-12 / V4-T0002","FA-8":"D-21","FA-9":"D-06"}

MERGE_GATES = {"D-31","D-07","D-18","D-03","D-06","D-04","D-08","D-30"}   # kodlamayı engellemez; merge/aktivasyonu engeller
