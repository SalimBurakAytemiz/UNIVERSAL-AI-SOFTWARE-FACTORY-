# V4.1 candidate patch (EX-01..EX-10) — source.py'nin üzerine uygulanan veri. build.py bunu import eder.
# EX-01/EX-04: tipli durumlar ve PR paketleri
STATES = ["PLANNED", "READY", "CODING", "CODE_READY", "REVIEWED", "MERGED", "ACCEPTED", "DONE"]
# PR paketleri: üyeler sırayla; preconditions = merge'den önce ACCEPTED/DONE olması gereken Task'lar
BUNDLES = {
 "PR-251": dict(pr="#251", members=["V3-T1002", "V3-T1003", "V3-T1036", "UASCO-T0069.a"], preconditions=[], files="prfiles/pr251.txt"),
 "PR-231": dict(pr="#231", members=["UASCO-T0031", "UASCO-T0031.b", "UASCO-T0069.c"], preconditions=["UASCO-T0031.c"], files="prfiles/pr231.txt", headFreezeAfter="UASCO-T0031.c"),
 "PR-247": dict(pr="#247", members=["UASCO-T0100.a"], preconditions=[], files="prfiles/pr247.txt"),
}
# PR dosyalarının paket içi sahibi (gerçek changed-files; tests/docs paket birincil sahibine)
PR_FILE_OWNER_TASK = {
 "PR-231": {"apps/control-api/src/server.ts": "UASCO-T0031.b", "config/trust-root-manifest.json": "UASCO-T0069.c", "*": "UASCO-T0031"},
 "PR-251": {"config/trust-root-manifest.json": "UASCO-T0069.a", "*": "V3-T1002"},
 "PR-247": {"*": "UASCO-T0100.a"},
}
# Tipli bağımlılık override'ları: task -> [(hedef, durum)]
TYPED_DEPS = {
 "UASCO-T0031.b": [("UASCO-T0031", "CODE_READY")],
 "UASCO-T0069.c": [("UASCO-T0031", "REVIEWED"), ("UASCO-T0031.b", "REVIEWED"), ("UASCO-T0069.a", "MERGED")],
 "UASCO-T0031.c": [("UASCO-T0069.c", "REVIEWED")],   # R-review D1: reseal review'u kitten önce
 "V3-T1003": [("V3-T1002", "CODE_READY")],
 "V3-T1036": [("V3-T1002", "CODE_READY")],
 "UASCO-T0069.a": [("V3-T1002", "REVIEWED"), ("V3-T1003", "REVIEWED"), ("V3-T1036", "REVIEWED")],
 "UASCO-T0100.a": [("UASCO-T0069.a", "MERGED")],
 "V4-T0001.a": [("UASCO-T0069.c", "MERGED"), ("UASCO-T0016", "MERGED")],
 "UASCO-T0002.a": [("V4-T0001.a", "DONE"), ("UASCO-T0002", "ACCEPTED")],
 "UASCO-T0029": [("UASCO-T0002.a", "ACCEPTED"), ("UASCO-T0031.a", "MERGED"), ("UASCO-T0003", "MERGED"), ("UASCO-T0061", "MERGED"), ("UASCO-T0061.a", "MERGED")],
 "V3-T1014": [("UASCO-T0069.c", "MERGED")],   # EX-03: #231 executors.ts ile seri
 "UASCO-T0069.b": [("UASCO-T0069.c", "MERGED"), ("UASCO-T0029", "ACCEPTED"), ("UASCO-T0016", "MERGED")],
}
# Yeni Task'lar (EX-04, EX-03)
NEW_TASKS_EX = {
 "UASCO-T0031.c": dict(parent="UASCO-T0031", feature="V3-F013", phase="P1", name="Founder kabul kiti: #231 son head SHA'sı üzerinde (reseal sonrası)", lane="F_FOUNDER",
   work="Founder, #231 dalının reseal sonrası SON head'ini temiz checkout + npm ci ile alır; `node docs/acceptance/windows/founder-acceptance.mjs --distro <ad>` (git HEAD'e bağlı). Kit JSON'u register'a",
   done="Kit sonucu ACCEPTED ve JSON'daki SHA = PR #231'in merge anındaki head SHA'sı. Head sonradan değişirse kanıt geçersiz; kit yeniden koşulur", eff=(1, 3), src="EX-04, B7", files=["EXT:Founder-PC"], ac="V3-AC-F013-1"),
 "V4-T0001.a": dict(parent="V4-T0001", feature="V3-F039", phase="P1", name="#231 ve export sonrası installer artifact toplama + .exe SHA", lane="E_CONTROL",
   work="Merge sonrası base'in Windows Installer artifact'ını deterministik topla (V4-T0001 ile aynı script)", done="Register'da yeni BUILD_OK/INSTALLER_OK EV + .exe SHA; kaynak merge commit SHA'sı", eff=(0.5, 1), src="EX-04", files=["EXT:Actions artifact (merge sonrası)", "EXT:register dalı (supervisor)"], ac="V3-AC-F039-1"),
 "UASCO-T0002.a": dict(parent="UASCO-T0002", feature="V3-F001", phase="P1", name="Founder: merge sonrası yeni installer ile kurulum kabulü", lane="F_FOUNDER",
   work="V4-T0001.a'nın .exe'si Founder-PC'ye kurulur; kontrol listesi tekrar", done="WINDOWS_INSTALL_VERIFIED kanıtı; installer sha256 = V4-T0001.a SHA; build SHA = merge commit", eff=(0.5, 1.5), src="EX-04", files=["EXT:Founder-PC"], ac="V3-AC-F001-1"),
}
# EX-02: yetki-hassas yollar (repo korumasına ek olarak fail-closed T2)
AUTHORITY_SENSITIVE = [".github/", "config/", "scripts/validate-", "scripts/ci/", "scripts/run-validation", "automation/lib/", "schemas/", "prompts/", ".ai/",
    # R-review S2/S3/S5: kabul kiti, dispatch/claim motoru, rutin prompt'ları, tedarik zinciri, release, ücretli model yönlendirmesi, supervisor araçları
    "docs/acceptance/", "docs/planning/dispatch.mjs", "docs/routines/", "package.json", "package-lock.json", ".npmrc", "scripts/build-installer.mjs", "scripts/installer", "installer/",
    "core/policy/", "models/router/", "models/omniroute/", "supervisor", "docs/policy/", "docs/register/",   # R2-N4, R3-L4
    "EXT:coord-ledger", "EXT:supervisor", "EXT:GitHub ruleset", "EXT:GitHub repo security", "EXT:GitHub environment", "EXT:GitHub Actions runners", "EXT:claude.ai routines"]
EXEC_SUFFIX = (".mjs", ".js", ".cjs", ".ts", ".mts", ".ps1", ".sh", ".py")   # docs/ altındaki çalıştırılabilir dosyalar yetki-hassas
# R-review S4: güvenlik uygulayan kod → T2 (RW-006 listesi + sandbox köprüsü, executor, secret/test-surface)
SECURITY_SENSITIVE = ["core/workos/execution-gate.ts", "core/workos/security-tools.ts", "core/agents/", "core/sandbox/", "core/workos/claude-profiles.ts", "core/workos/runner.ts",
                      "core/workos/secret-scan.ts", "core/action-gateway/", "core/workos/test-surface.ts", "apps/desktop/preload.mjs", "core/workos/executors.ts", "core/workos/devrun-bridge.ts", "core/workos/devrun.ts"]
# EX-03: Task dosya düzeltmeleri (tek owner)
TASK_FILES_EX = {
 # R2-N3: register'a yalnız deterministik araç yazar
 "UASCO-T0101": ["EXT:Founder kararı (fsmonitor/untrackedCache yetkisi)"], "UASCO-T0102": ["EXT:Founder kararı (Master V2 FD'leri)"],
 "V3-T1021": ["NEW:docs/register/legacy-backfill-mapping.json"], "UASCO-T0123": ["registries/"],
 # R-review S3: register'a LLM yazmaz; politika/kayıt değişiklikleri repo PR'ı ya da deterministik kayıt
 "UASCO-T0008": ["EXT:register dalı (supervisor)"], "UASCO-T0028": ["EXT:register dalı (supervisor)"],
 "UASCO-T0121": ["NEW:docs/policy/LOW-FINDINGS.md"], "UASCO-T0122": ["NEW:docs/planning/SCREEN-CLASSIFICATION.md"],
 "UASCO-T0120": ["ROADMAP.md", ".ai/MASTER_STATE.json", "docs/planning/BACKLOG_CHECKPOINT.json"],
 "V3-T1005": ["NEW:.github/pull_request_template.md", "NEW:scripts/ci/register-verify.mjs"],
 "V3-T1008": ["EXT:supervisor merge kuralı"], "UASCO-T0099": ["EXT:supervisor Founder kuyruğu aracı"],
 "UASCO-T0110": ["EXT:supervisor bütçe aracı"], "UASCO-T0111": ["EXT:supervisor telemetri aracı"], "UASCO-T0112": ["EXT:supervisor uyanma aracı"], "UASCO-T0106": ["EXT:supervisor oturum aracı"],
 "UASCO-T0116": ["NEW:docs/routines/heartbeat.md"], "UASCO-T0117": ["NEW:docs/routines/"],
 "UASCO-T0113": ["EXT:Founder kararı (D-14)"], "UASCO-T0082": ["EXT:Founder kararı (D-15)"],
 "V3-T1011": ["apps/control-api/src/server.ts", "NEW:apps/control-api/src/delivery-labels.ts"],
 "UASCO-T0031.a": ["apps/desktop/renderer/views/setup-check.js", "NEW:tests/v7-v41-setup-check-wsl.test.ts", "NEW:docs/acceptance/windows/WSL2-PREP.md"],
 "V3-T1025": ["NEW:config/authority-matrix.json"], "V3-T1026": ["core/action-gateway/", "NEW:config/authority-matrix.json"],
 "UASCO-T0094": ["scripts/e2e-first-delivery-electron.mjs"], "UASCO-T0095": ["NEW:.github/workflows/desktop-e2e.yml"],
}
# EX-09: uzun pencere ölçütleri → STABILITY_MONITORING (ilk kod kabulünün önünde değil)
MONITORING_SPLIT = {
 "V3-T1001": ("Deterministik Windows testi (öldürülen yazar sonrası LOCK_TIMEOUT yok) eklendi ve birleşik SHA'da L1 + Windows shard'ları yeşil", "relfx-1:459 ailesinden kırmızı 20 ardışık base push'ta 0"),
 "UASCO-T0088": ("4 bilinen flake testi deterministik hâle getirildi ya da sahipli ve süreli karantinada; birleşik SHA'da Windows shard'ları yeşil", "20 ardışık base push'ta bilinen-flake kırmızısı 0; 50 PR'da ≥ %95 (V3-AC-F038-3)"),
 "V3-T1008": ("Seri merge kuralı yazılı; supervisor her merge öncesi update-branch + birleşik SHA'da tam CI uyguluyor; ilk merge'de kanıt", "14 günde M.3 sınıfı olay 0"),
 "V3-T1033": ("Claim'ler log-only olarak refs/uasco/claims/* altına yazılıyor; çakışma raporu üretiliyor", "7 gün boyunca çift claim 0"),
 "UASCO-T0121": ("Ürün/meta bütçesi ve LOW toplama kuralı yazılı ve uygulanıyor", "30 PR'lık pencerede ürün satır payı ≥ %40"),
}
STABILITY_ACS = ["V3-AC-F033-1", "V3-AC-F038-2", "V3-AC-F038-3", "V3-AC-F042-2", "V3-AC-F043-1", "V3-AC-F045-1", "V3-AC-F046-3", "V3-AC-F047-2", "V3-AC-F023-1", "V3-AC-F052-1"]
# EX-05: yetkilendirme durumları
AUTH_STATES = [
 ("DESIGN_FINAL_CANDIDATE", "Şu an. Repo'ya yazma yok.", "—"),
 ("FOUNDER_AUTHORIZED", "D-01 verildi. Execution oturumu açılabilir; deterministik doğrulama ve register işleri başlar.", "D-01"),
 ("CODE_ALLOWED", "Task kendi startGates'i karara bağlıysa kodlanabilir, PR açılabilir. Slot sayısı: D-12 verilmeden 1, verildikten sonra 3.", "D-01 + Task startGates (+ D-12 → 3 slot)"),
 ("MERGE_ALLOWED", "PR paketi review'dan geçti, mergeGates karara bağlı, T2 için Founder onayı var (D-31 paketi), birleşik SHA'da CI yeşil.", "mergeGates (D-31, D-07, D-18, D-03, D-06, D-04, D-08, D-30)"),
 ("WINDOWS_ACCEPTANCE_ALLOWED", "Founder `.exe` UAT Task'ları (UASCO-T0002, T0002.a) başlayabilir; Founder-PC'de yalnız kur/aç/kullan.", "D-23 + D-26 + cloud e2e CI PASS (CLOUD-T0011) + hosted Windows installer PASS (CLOUD-T0006)"),
]
# EX-06: V3-T1008 başlangıç kapısı yok (mevcut kurallar içinde geçici mod)
DETERMINISTIC_EX = {"UASCO-T0008", "UASCO-T0028"}   # yalnız durum kaydı (deterministik)
EXTRA_DEPS = {"UASCO-T0125": [("UASCO-T0069.c", "MERGED")]}   # R-review: executors.ts
GATE_OVERRIDES = {"V3-T1008": [], "UASCO-T0031.c": ["D-23", "D-03"], "UASCO-T0002.a": ["D-23", "D-26"], "V4-T0001.a": ["D-30"]}
SLOT_LIMIT_WITHOUT_D12 = 1
LOCK_TIMEOUT_H = 24   # R3-L1: süre kitin başlatılabilir olduğu andan sayılır; kilit süresince Founder kit için ayrılır
LOCK_PREKIT_TIMEOUT_H = 8   # R5: kilit alındıktan sonra kit 8 h içinde başlamazsa kilit iptal edilir
ESCALATION_DECISION = {"PR-231": "D-03"}   # R3-L3: eskalasyon çıkışı; diğer paketler için D-07
KIT_FAILURE_RULE = "Kit NOT_ACCEPTED → kilit bırakılır; düzeltme AYNI PR paketinde yapılır (paket üyeleri yeniden açılır, claim'ler paket tarafından korunur); kit yeniden koşulur. 2 başarısızlık/iptal → Founder eskalasyonu (ESCALATION_DECISION); karar yoksa güvenli varsayılan: paket DEFERRED, claim'ler serbest, bağımlı Task'lar BLOCKED_DECISION"   # R2-N0: reseal kilidi en fazla 24 h (gerçek saat) tutulur; sonra iptal
RESEAL_WORK = "Kilit alındıktan sonra kit 8 h içinde başlamazsa (Founder ulaşılamaz) kilit iptal edilir. Merger, kilit başında paket dalını güncel base'e alır (update-branch; base kilitle sabit), ardından manifest reseal'i hesaplanır (R2-N2). Kilit LOCK_TIMEOUT_H içinde merge edilmezse ya da kabul kiti NOT_ACCEPTED olursa kilit iptal edilir: reseal commit'i geçersiz sayılır, Task PLANNED'e döner, merge'ler sürer."
