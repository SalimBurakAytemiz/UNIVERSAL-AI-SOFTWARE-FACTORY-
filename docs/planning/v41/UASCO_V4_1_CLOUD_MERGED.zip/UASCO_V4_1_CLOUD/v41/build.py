# V4.1 Final Candidate üreticisi — patch EX-01..EX-10 (tek veri kaynağı). Yeni roadmap değildir.
import json, csv, os, sys, collections, copy, re, subprocess
H = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, H)
import sim as _s
from source import *; from patch_ex import *; from decisions import D; from recon import G, X
import cloud_only as CO
SP = os.path.dirname(H); OUT = sys.argv[1]
PKG = os.environ.get("V41_PACKAGE_ROOT")
def src(rel_pkg, rel_sp): return f"{PKG}/{rel_pkg}" if PKG else f"{SP}/{rel_sp}"
tm = json.load(open(src("sources/v31/V3_TASK_DEPENDENCY_MATRIX.json", "UASCO_V3_1_DELIVERY/V3_TASK_DEPENDENCY_MATRIX.json")))
fc = json.load(open(src("sources/v31/V3_FEATURE_CROSSWALK.json", "UASCO_V3_1_DELIVERY/V3_FEATURE_CROSSWALK.json")))
am = json.load(open(src("sources/v31/V3_ACCEPTANCE_EVIDENCE_MATRIX.json", "UASCO_V3_1_DELIVERY/V3_ACCEPTANCE_EVIDENCE_MATRIX.json")))
man = json.load(open(src("sources/v4/UASCO_EXECUTION_MANIFEST_V4.json", "v4in/UASCO_EXECUTION_MANIFEST_V4.json")))
canon = json.load(open(src("sources/canonical/UASCO_REMAINING_WORK.json", "r/rw2.json")))
tree = set(open(src("sources/repo/tree-16d3a925.txt", "tree.txt")).read().split("\n"))
pp = json.load(open(src("sources/repo/protected-paths-16d3a925.json", "v41/_pp.json")))
SEALED = {(x['path'] if isinstance(x, dict) else x) for x in json.load(open(src("sources/repo/trust-root-manifest-16d3a925.json", "v41/_trm.json")))['files']}
MANIFEST = "config/trust-root-manifest.json"
PRF = {b: [l.strip() for l in open(src("sources/repo/" + v['files'].split("/")[-1], "v41/" + v['files'])) if l.strip()] for b, v in BUNDLES.items()}
PEX, PPRE = set(pp['exactPaths']), pp['protectedPrefixes']
F = {f['id']: f for f in fc['features']}; AC = {a['acId']: a for a in am['rows']}; W4F = {f['feature_id']: f for f in man['features']}
PH2W = {"BASE": "W0", "P0": "W0", "P1": "W1", "P2": "W2", "P3": "W3", "P4": "W4", "P5": "W5"}
wi = lambda w: int(w[1]); errs, warns = [], []
assert len(F) == 57 and len(tm['tasks']) == 164 and len(am['rows']) == 102
canon_tasks = {t['id'] for t in canon['roadmap']['tasks']}; assert len(canon_tasks) == 129
assert {t['id'] for t in tm['tasks'] if t['legacyId']} == canon_tasks
DONE_ST = ("ASSET_DONE", "ASSET_CODED_UNWIRED", "DONE_OBSERVED")
# ------------------------------------------------ tasks
T = {t['id']: copy.deepcopy(t) for t in tm['tasks']}
r1 = set(tm['r1CriticalPath']['closureTasks'])
def mk(tid, n, extra_src=""):
    T[tid] = dict(id=tid, legacyId="", legacyFeature="", v3Feature=n['feature'], name=n['name'], legacyStatus="—", v31Status="PROPOSED_V4_1", statusEvidence="", phase=n['phase'],
                  work=n['work'], done=n['done'], dependsOn=list(n.get('deps', [])), effort=list(n['eff']), acId="", alsoCovers=[], evidenceId="", deliveryScenario="", inventoryId="",
                  parentId=n['parent'], source=n['src'])
for tid, n in NEW_TASKS.items(): mk(tid, n)
for tid, n in NEW_TASKS_EX.items(): mk(tid, n)
NEW_AC = {"UASCO-T0069.a": "V3-AC-F030-1", "UASCO-T0069.b": "V3-AC-F030-1", "UASCO-T0069.c": "V3-AC-F030-1", "UASCO-T0100.a": "V3-AC-F030-1", "UASCO-T0031.a": "V3-AC-F013-1",
          "UASCO-T0031.b": "V3-AC-F013-2", "UASCO-T0061.a": "V3-AC-F025-1", "UASCO-T0023.a": "V3-AC-F009-2", "V3-T1012.a": "V3-AC-F057-2", "V4-T0001": "V3-AC-F039-1", "V4-T0002": "V3-AC-F047-1"}
NEW_AC.update({k: v['ac'] for k, v in NEW_TASKS_EX.items()})
for tid, a in NEW_AC.items(): T[tid].update(acId=a, evidenceId=AC[a]['evidenceId'], deliveryScenario=AC[a]['deliveryScenario'])
for tid, deps in DEP_SET.items(): T[tid]['dependsOn'] = list(deps)
# typed deps: önce düz bağımlılıklar varsayılan duruma, sonra override
for t in T.values(): t['deps'] = [[d, None] for d in t['dependsOn']]
for tid, lst in TYPED_DEPS.items(): T[tid]['deps'] = [list(x) for x in lst]
for p, kids in SPLIT_PARENTS.items():
    T[p].update(v31Status="SPLIT", effort=[0, 0], splitInto=kids, deps=[])
    for t in T.values():
        t['deps'] = [d for d in t['deps'] if d[0] != p] + ([["UASCO-T0069.a", None]] if any(d[0] == p for d in t['deps']) else [])
for k in list(r1): pass
r1 |= {"UASCO-T0069.a", "UASCO-T0069.c", "UASCO-T0031.a", "UASCO-T0031.b", "UASCO-T0031.c", "UASCO-T0061.a", "V3-T1012.a", "V4-T0001", "V4-T0001.a", "V4-T0002", "UASCO-T0002.a"}
r1.discard("UASCO-T0069")
for t in T.values(): t.setdefault('parentId', ""); t['source'] = t.get('source') or "V3.1"
# ------------------------------------------------ cloud-only (H1)
CO.apply_ac(AC)
CO.add_new_tasks(T, mk)
for tid in CO.NEW: T[tid]['deps'] = [[d, None] for d in T[tid]['dependsOn']]
r1 |= {tid for tid, n in CO.NEW.items() if n.get('r1Critical')}
CO.apply_text_deps(T, {m for v in BUNDLES.values() for m in v['members']})
# ------------------------------------------------ paths
def canon_path(p):
    q = p.split(":", 1)[1] if p.startswith(("NEW:", "PR231:", "PR247:")) else p
    q = re.sub(r"\s*\(.*\)$", "", q).lstrip("/").strip()
    return q
def basis(p):
    if p.startswith("EXT:"): return "EXT"
    if p.startswith(("PR231:", "PR247:", "PR251:")): return p.split(":")[0]
    q = canon_path(p)
    if p.startswith("NEW:"): return "NEW_PROVISIONAL" if "(keşif)" in p or q.endswith("/") or "." not in q.split("/")[-1] else "NEW"
    return "VERIFIED" if (q in tree or any(x.startswith(q) for x in tree)) else "MISSING"
def owner(p):
    c = None if p.startswith("EXT:") else canon_path(p)
    if c is not None and c.startswith(("tests/", "docs/")): return None   # tests/docs: Task'ın birincil lane'i; claim yine yol bazında
    for pre, lane in OWNER_BY_PATH:
        if p.startswith(pre): return lane
        if c is not None and ":" not in pre and "(" not in pre and c.startswith(pre.lstrip("/")): return lane
    return None
def as_dir(q, p): return q if q.endswith("/") else (q + "/" if basis(p) == "NEW_PROVISIONAL" or (q and "." not in q.split("/")[-1]) else None)
def is_protected(p):
    if p.startswith("EXT:"): return False
    q = canon_path(p)
    if q in PEX or any(q.startswith(x) for x in PPRE): return True
    d = as_dir(q, p)   # R-review S1: korumalı dosya içeren klasör hedefi
    return bool(d) and (any(e.startswith(d) for e in PEX) or any(x.startswith(d) for x in PPRE))
def is_sealed(p):
    if p.startswith("EXT:"): return False
    q = canon_path(p)
    if q in SEALED: return q != MANIFEST
    d = as_dir(q, p); return bool(d) and any(e.startswith(d) for e in SEALED)
def is_auth(p):
    if p.startswith("EXT:"): return any(p.startswith(x) for x in AUTHORITY_SENSITIVE if x.startswith("EXT:"))
    q = canon_path(p)
    if q.startswith("docs/") and q.endswith(EXEC_SUFFIX): return True   # R-review S2
    d = as_dir(q, p)
    return any(q.startswith(x) for x in AUTHORITY_SENSITIVE if not x.startswith("EXT:")) or bool(d and any(x.startswith(d) for x in AUTHORITY_SENSITIVE if not x.startswith("EXT:") and "/" in x))
def is_sec(p):
    if p.startswith("EXT:"): return False
    q = canon_path(p); d = as_dir(q, p)
    return any(q.startswith(x) for x in SECURITY_SENSITIVE) or bool(d and any(x.startswith(d) for x in SECURITY_SENSITIVE))
for tid, t in T.items():
    t['targetFiles'] = list(TASK_FILES_EX.get(tid) or TASK_FILES.get(tid) or NEW_TASKS_EX.get(tid, {}).get('files') or MODULES[t['v3Feature']])
# PR paketleri: gerçek changed-files → paket üyelerine
bundle_of = {}
for b, v in BUNDLES.items():
    for m in v['members']: bundle_of[m] = b
    own = PR_FILE_OWNER_TASK[b]; per = collections.defaultdict(list)
    for f in PRF[b]: per[own.get(f, own["*"])].append(f)
    for m, fs in per.items(): T[m]['targetFiles'] = sorted(fs); T[m]['writeSetSource'] = f"gerçek changed-files ({v['pr']}, git diff --name-only merge-base…head)"
CO.apply_files(T, set(bundle_of))   # cloud-only (H2)
for t in T.values():
    if t['id'] not in bundle_of and t['v31Status'] not in DONE_ST and any(is_sealed(f) for f in t['targetFiles']) and MANIFEST not in [canon_path(f) for f in t['targetFiles']]:
        t['targetFiles'] = t['targetFiles'] + [MANIFEST]; t['resealRequired'] = True   # R-review D2
for t in T.values():
    t['targetBasis'] = {f: basis(f) for f in t['targetFiles']}
    for f, b in t['targetBasis'].items():
        if b == "MISSING" and not t['id'] in sum([v['members'] for v in BUNDLES.values()], []): errs.append(f"{t['id']} missing path {f}")
    t.setdefault('writeSetSource', "Task hedef dosyaları (keşifte daraltılır; NEW_PROVISIONAL yollar kesinleşince yeniden doğrulanır)")
# ------------------------------------------------ lanes (+ EX-03 karma owner bölme)
PREC = ["C_ENGINE", "B_API", "D_CI_RELEASE", "A_UI", "E_CONTROL", "F_FOUNDER"]
LETTER = {"A_UI": "A", "B_API": "B", "C_ENGINE": "C", "D_CI_RELEASE": "D", "E_CONTROL": "E", "F_FOUNDER": "F"}
def lane_of_file(f, t):
    o = owner(f)
    if o: return o
    if not f.startswith("EXT:") and canon_path(f).startswith(("tests/", "docs/")): return None
    if t['id'] in bundle_of: return None  # paket tests/docs → paket sahibi
    return W4F[t['v3Feature']]['responsible_lane']
splits = {}
for tid in list(T):
    t = T[tid]
    if t['v31Status'] in DONE_ST or t['v31Status'] == "SPLIT": t['lane'] = W4F[t['v3Feature']]['responsible_lane']; continue
    _lo = CO.lane_override(tid)   # cloud-only (H3a)
    if _lo != "AUTO" and (tid in FOUNDER_TASKS or NEW_TASKS_EX.get(tid, {}).get('lane') == "F_FOUNDER"): t['lane'] = "F_FOUNDER"; continue
    if _lo != "AUTO" and tid in NEW_TASKS_EX and NEW_TASKS_EX[tid].get('lane'): t['lane'] = NEW_TASKS_EX[tid]['lane']; continue
    byl = collections.defaultdict(list)
    for f in t['targetFiles']:
        l = lane_of_file(f, t)
        if l: byl[l].append(f)
    if tid in bundle_of:
        ls = [l for l in byl if l != "F_FOUNDER"]
        t['lane'] = ls[0] if len(ls) == 1 else ("C_ENGINE" if "C_ENGINE" in ls else ls[0])
        # paket içi tests/docs ve yabancı lane dosyaları: paket istisnası (tek PR dalı, sıralı devir)
        t['bundleFileException'] = sorted(f for f in t['targetFiles'] if lane_of_file(f, t) not in (None, t['lane']))
        continue
    if len(byl) <= 1:
        t['lane'] = next(iter(byl), W4F[t['v3Feature']]['responsible_lane']); continue
    # karma owner → alt Task'lar
    lanes = sorted(byl, key=PREC.index)
    if "D_CI_RELEASE" in lanes and [canon_path(f) for f in byl["D_CI_RELEASE"]] == [MANIFEST]: lanes = [l for l in lanes if l not in ("D_CI_RELEASE", "F_FOUNDER")] + ["D_CI_RELEASE"] + (["F_FOUNDER"] if "F_FOUNDER" in lanes else [])
    kids = []
    n = len(lanes)
    for i, l in enumerate(lanes):
        cid = f"{tid}.{LETTER[l]}"
        T[cid] = dict(copy.deepcopy(t), id=cid, parentId=tid, legacyId="", v31Status="PROPOSED_V4_1_SPLIT", lane=l, targetFiles=byl[l], targetBasis={f: basis(f) for f in byl[l]},
                      name=f"{t['name']} — {l} kısmı", work=f"{t['work']} [yalnız {l} dosyaları: {', '.join(byl[l])}]", effort=[round(t['effort'][0] / n, 2), round(t['effort'][1] / n, 2)],
                      source=f"EX-03 otomatik bölme ({tid})", splitInto=[])
        if i == 0: T[cid]['deps'] = copy.deepcopy(t['deps'])
        elif l == "F_FOUNDER": T[cid]['deps'] = [[k, "MERGED"] for k in kids]
        else: T[cid]['deps'] = [[k, "REVIEWED"] for k in kids]   # aynı PR dalında sıralı devir
        kids.append(cid)
    code_kids = [k for k in kids if T[k]['lane'] != "F_FOUNDER"]
    if len(code_kids) > 1:
        bname = f"PR-{tid}"
        BUNDLES[bname] = dict(pr=f"(yeni PR: {tid})", members=code_kids, preconditions=[], files="")
        for k in code_kids: bundle_of[k] = bname
    t.update(v31Status="SPLIT", effort=[0, 0], splitInto=kids, deps=[], lane="—")
    splits[tid] = kids
    if tid in r1: r1 |= set(kids); r1.discard(tid)
# bölünen ebeveyne bağımlılıklar → bütün çocuklar
for t in T.values():
    nd = []
    for d, s in t['deps']:
        if d in splits: nd += [[k, None] for k in splits[d]]
        else: nd.append([d, s])
    t['deps'] = nd
CO.after_split(T, splits, lane_of_file)   # cloud-only (H3b)
for b, v in BUNDLES.items():
    v['lock'] = any(MANIFEST in [canon_path(f) for f in T[m]['targetFiles']] for m in v['members'])
    v['lockStartsWith'] = next((m for m in v['members'] if MANIFEST in [canon_path(f) for f in T[m]['targetFiles']]), None)
for k, lst in EXTRA_DEPS.items(): T[k]['deps'] += [list(x) for x in lst]
for b, v in BUNDLES.items():
    if v.get('lockStartsWith'):
        m = v['lockStartsWith']; T[m]['work'] = T[m]['work'] + " · RESEAL PROSEDÜRÜ: " + RESEAL_WORK + " · KİT BAŞARISIZLIĞI: " + KIT_FAILURE_RULE; v['lockTimeoutH'] = LOCK_TIMEOUT_H; v['lockPrekitTimeoutH'] = LOCK_PREKIT_TIMEOUT_H
        v['escalationDecision'] = ESCALATION_DECISION.get(b, "D-07")
# Founder koşuları R1 installer'ına bağlı (EX-04)
for k in ("V3-T1013.F",):
    if k in T: T[k]['deps'].append(["UASCO-T0002.a", "ACCEPTED"])
# ------------------------------------------------ completion state, tier, slots
def completes(t):
    if CO.completes_override(t): return CO.completes_override(t)
    if t['v31Status'] in DONE_ST: return "MERGED"
    if t['lane'] == "F_FOUNDER": return "ACCEPTED" if any(f.startswith("EXT:Founder-PC") for f in t['targetFiles']) else "DONE"
    if t['id'] in bundle_of: return "REVIEWED"
    if all(f.startswith(("EXT:register", "EXT:Actions artifact")) for f in t['targetFiles']): return "DONE"
    return "MERGED"
for tid, t in T.items():
    if t['v31Status'] == "SPLIT": t['completesAt'] = "—"; continue
    t['completesAt'] = completes(t)
for t in T.values():
    for d in t['deps']:
        if d[1] is None and d[0] in T: d[1] = T[d[0]]['completesAt'] if T[d[0]]['completesAt'] != "—" else "MERGED"
    t['dependsOn'] = [d[0] for d in t['deps']]
CO.retype_deps(T)   # cloud-only (CO-10)
for tid, t in T.items():
    files = t['targetFiles']
    pf = [f for f in files if is_protected(f)]; af = [f for f in files if is_auth(f)]
    prov = any(t['targetBasis'].get(f) == "NEW_PROVISIONAL" for f in files)
    t['protectedFiles'] = pf; t['authorityFiles'] = af; t['tierProvisional'] = prov
    if tid in T3: tier, why = "T3", T3[tid]
    elif pf or af or any(is_sec(f) for f in files): tier, why = "T2", "korumalı/yetki-hassas/güvenlik: " + ", ".join(sorted(set(pf + af + [f for f in files if is_sec(f)])))
    elif t['lane'] in ("F_FOUNDER",) or all(f.startswith(("EXT:register", "EXT:Actions artifact", "EXT:Founder", "EXT:PR #", "EXT:claude.ai")) for f in files): tier, why = "T0", "register/Founder aksiyonu/salt-okur"
    elif all(canon_path(f).startswith("docs/") and canon_path(f).endswith(".md") for f in files if not f.startswith("EXT:")) and not prov and any(not f.startswith("EXT:") for f in files): tier, why = "T0", "yalnız .md dokümanı (PR + L1; CI'lı)"
    else: tier, why = "T1", "korumasız ürün kodu" + (" (NEW_PROVISIONAL: keşif sonrası yeniden sınıflanır, en az T1)" if prov else "")
    t['authorityTier'], t['tierReason'] = tier, why
    t['securitySensitive'] = any(is_sec(f) for f in files)
CO.tier_floor(T)   # cloud-only (H4)
# ------------------------------------------------ model
for tid, t in T.items():
    sec = t['securitySensitive']
    if t['v31Status'] in DONE_ST or t['v31Status'] == "SPLIT": m, esc = "—", "—"
    elif t['lane'] == "F_FOUNDER": m, esc = "FOUNDER (model yok)", "Claude yalnız runbook/özet hazırlar (Haiku)"
    elif tid in DETERMINISTIC or tid in DETERMINISTIC_EX or tid in CO.DETERMINISTIC_CLOUD or tid in ("V4-T0001.a",): m, esc = "deterministic", "Haiku: yalnız sonuç özeti; araç hatasında Sonnet"
    elif tid in OPUS_FIRST: m, esc = "opus→sonnet", OPUS_FIRST[tid] + "; uygulamada aynı fingerprint 2× başarısızsa BLOCKED_WITH_EVIDENCE"
    elif tid in HAIKU and t['authorityTier'] in ("T0", "T1") and not sec: m, esc = "haiku", HAIKU[tid] + "; diff > 80 satır ya da test 2× FAIL → Sonnet"
    else: m, esc = "sonnet", "2 farklı hipotez başarısız ya da aynı fingerprint 2× → Opus tek seferlik teşhis; sonra Sonnet uygular"
    rv = {"T0": "deterministik kontrol + Haiku özet", "T1": "taze Sonnet", "T2": "taze Opus", "T3": "taze Opus + Founder"}[t['authorityTier']]
    if sec and t['authorityTier'] in ("T0", "T1"): rv = "taze Opus (güvenlik-hassas)"
    if t['lane'] == "F_FOUNDER" or m == "—": rv = "—"
    t['model'], t['escalation'], t['reviewModel'] = m, esc, rv
    t['slotRequired'] = m in ("sonnet", "haiku", "opus→sonnet")
    mx = t['effort'][1]
    t['costClass'] = "—" if mx == 0 else ("XS" if mx <= 1 else "S" if mx <= 4 else "M" if mx <= 12 else "L" if mx <= 40 else "XL")
    regbranch = all(f.startswith(("EXT:register", "EXT:Actions artifact")) for f in t['targetFiles']) and m == "deterministic"   # R-review S3: register'a yalnız deterministik araç yazar
    if m == "—": t['prMerge'] = "—"
    elif t['lane'] == "F_FOUNDER": t['prMerge'] = "PR yok; Founder aksiyonu → kanıt JSON'u register'a (supervisor doğrular)"
    elif regbranch and t['authorityTier'] == "T0": t['prMerge'] = "Supervisor deterministik kayıt: yalnız register dalı (CI'sız), yalnız araç çıktısı; LLM yazmaz"
    else:
        b = bundle_of.get(tid)
        base = (f"Paket {b} ({BUNDLES[b]['pr']}) üyesi: completesAt={t['completesAt']}; merge paket olarak (üyeler REVIEWED + ön koşullar + kapılar)" if b else
                "Draft PR (L0) → ready (L1) → taze review (" + t['reviewModel'] + ") → ledger NO_BLOCKERS (aynı SHA/patch-id) → tek merger: update-branch + birleşik SHA'da tam CI → merge → post-merge push CI + installer")
        if t['authorityTier'] == "T2": base += " · Founder T2 onayı (D-31 paketi)"
        if t['authorityTier'] == "T3": base += " · Founder T3 açık onayı (" + T3[tid] + ")"
        t['prMerge'] = base
# ------------------------------------------------ gates
for tid, t in T.items():
    g = list(GATE_OVERRIDES.get(tid, GATES.get(tid, GATES.get(t['parentId'], []) if t['v31Status'] == "PROPOSED_V4_1_SPLIT" else [])))
    if t['authorityTier'] == "T2" and "D-31" not in g and t['v31Status'] not in DONE_ST + ("SPLIT",): g.append("D-31")
    if t['lane'] == "F_FOUNDER" and any(f.startswith("EXT:Founder-PC") for f in t['targetFiles']) and "D-23" not in g and tid not in ("V4-T0002",): g.append("D-23")
    t['gates'] = g; t['startGates'] = [x for x in g if x not in MERGE_GATES]; t['mergeGates'] = [x for x in g if x in MERGE_GATES]
CO.gates_union(T, MERGE_GATES)   # cloud-only (H5)
_k = T[CO.KIT]; _k.update(reviewModel="deterministik kontrol (kit SHA + JSON şeması)", slotRequired=False, prMerge="PR yok; hosted Windows runner kit koşusu → kanıt JSON'u register'a (supervisor doğrular)")
# ------------------------------------------------ done/monitoring split (EX-09)
for tid, t in T.items():
    if tid in MONITORING_SPLIT: t['doneMerge'], t['monitoring'] = MONITORING_SPLIT[tid]
    else: t['doneMerge'], t['monitoring'] = t['done'], ""
    if t['acId'] in STABILITY_ACS: t['acType'] = "STABILITY_MONITORING"
    else: t['acType'] = "ACCEPTANCE"
CO.done_override(T)   # cloud-only
# R1 installer kapsamı: V4-T0001.a bütün R1 kod Task'larını MERGED bekler (EX-04)
def downstream(x):
    seen, st = set(), [x]
    while st:
        u = st.pop()
        for k, t in T.items():
            if u in t['dependsOn'] and k not in seen: seen.add(k); st.append(k)
    return seen
ds = downstream("V4-T0001.a")
for k in sorted(r1):
    if k in T and T[k]['slotRequired'] and k not in ds and k != "V4-T0001.a" and T[k]['completesAt'] == "MERGED" and wi(PH2W[T[k]['phase']]) <= 1 and k not in ("UASCO-T0069.b",):
        if k not in T["V4-T0001.a"]['dependsOn']: T["V4-T0001.a"]['deps'].append([k, "MERGED"])
T["V4-T0001.a"]['dependsOn'] = [d[0] for d in T["V4-T0001.a"]['deps']]
# ------------------------------------------------ waves
for tid, t in T.items():
    if t['v31Status'] in DONE_ST or t['v31Status'] == "SPLIT": t['wave'] = "W0"; continue
    if tid in r1 or t['phase'] == "P0": t['wave'] = PH2W[t['phase']]
    else: t['wave'] = "W" + str(max(wi(PH2W[t['phase']]), wi(W4F[t['v3Feature']]['delivery_wave'])))
CO.wave_override(T)   # cloud-only
for _ in range(60):
    ch = False
    for tid, t in T.items():
        for d in t['dependsOn']:
            if d in T and wi(T[d]['wave']) > wi(t['wave']): T[d]['wave'] = t['wave']; T[d].setdefault('pulledForwardBy', []).append(tid); ch = True
    if not ch: break
# ------------------------------------------------ static checks
OPEN = lambda t: t['v31Status'] not in DONE_ST and t['v31Status'] != "SPLIT"
for tid, t in T.items():
    for d, s in t['deps']:
        if d not in T: errs.append(f"{tid} dep missing {d}")
        elif s not in STATES: errs.append(f"{tid} bad dep state {d}:{s}")
        elif T[d]['v31Status'] == "SPLIT": errs.append(f"{tid} depends on SPLIT container {d}")
        elif wi(T[d]['wave']) > wi(t['wave']): errs.append(f"wave inversion {tid}<-{d}")
st = {}
def dfs(u, path):
    st[u] = 1
    for v in T[u]['dependsOn']:
        if st.get(v) == 1: errs.append("cycle " + "->".join(path + [v]))
        elif not st.get(v): dfs(v, path + [v])
    st[u] = 2
for u in T:
    if not st.get(u): dfs(u, [u])
for a in AC:
    if not any(t['acId'] == a or a in t.get('alsoCovers', []) for t in T.values()): errs.append("uncovered AC " + a)
for fid in F:
    if not any(t['v3Feature'] == fid for t in T.values()): errs.append("feature without task " + fid)
for tid, t in T.items():
    if OPEN(t) and t['lane'] not in ("F_FOUNDER",) and tid not in bundle_of:
        bad = [f for f in t['targetFiles'] if lane_of_file(f, t) not in (None, t['lane'])]
        if bad: errs.append(f"mixed owner remains {tid}: {bad}")
    if t['model'] == "haiku" and (t['protectedFiles'] or t['authorityFiles'] or t['securitySensitive']): errs.append("haiku on sensitive " + tid)
    if t['authorityTier'] in ("T0",) and (t['protectedFiles'] or t['authorityFiles']): errs.append("T0 on protected/authority " + tid)
    if "CI'sız" in t.get('prMerge', "") and (any(not f.startswith(("EXT:register", "EXT:Actions artifact")) for f in t['targetFiles']) or t['model'] != "deterministic"): errs.append("ci-less commit not deterministic/register-only " + tid)
    if t['securitySensitive'] and t['authorityTier'] in ("T0", "T1") and OPEN(t): errs.append("security-sensitive below T2 " + tid)
    if OPEN(t) and t['targetFiles'] and all(f.startswith("EXT:register") for f in t['targetFiles']) and t['model'] not in ("deterministic",): errs.append("LLM writes register " + tid)
    if OPEN(t) and t['lane'] != "F_FOUNDER" and any(is_sealed(f) for f in t['targetFiles']) and tid not in bundle_of and MANIFEST not in [canon_path(f) for f in t['targetFiles']]: errs.append("sealed file without manifest " + tid)
# self-tests (negatif): sınıflandırıcının kendisi
SELFTEST = []
def chk(name, cond): SELFTEST.append((name, bool(cond)));  (None if cond else errs.append("SELFTEST FAIL " + name))
chk("NEW:config/authority-matrix.json → protected", is_protected("NEW:config/authority-matrix.json"))
chk("NEW:.github/workflows/x.yml → authority", is_auth("NEW:.github/workflows/desktop-e2e.yml"))
chk("PR231:core/sandbox/x → security", is_sec("PR231:core/sandbox/wsl-unshare-sandbox.ts"))
chk("docs/ → not protected", not is_protected("NEW:docs/x.md"))
chk("EXT:coord-ledger → authority", is_auth("EXT:coord-ledger (uasco/production-queue)"))
chk("V3-T1025 tier T2", T["V3-T1025"]['authorityTier'] == "T2")
chk("V3-T1026 tier T2", T["V3-T1026"]['authorityTier'] == "T2")
chk("UASCO-T0095 tier T2", T["UASCO-T0095"]['authorityTier'] == "T2")
chk("V3-T1004 (ledger) tier T2", T["V3-T1004"]['authorityTier'] == "T2")
chk("#231 write set 42 dosya", sum(len(T[m]['targetFiles']) for m in BUNDLES["PR-231"]['members']) == 42)
chk("#251 write set 4", sum(len(T[m]['targetFiles']) for m in BUNDLES["PR-251"]['members'] if m in ("V3-T1002", "UASCO-T0069.a")) == 4)
chk("T0031.b ← T0031:CODE_READY", ["UASCO-T0031", "CODE_READY"] in T["UASCO-T0031.b"]['deps'])
chk("kit, reseal'in review'undan sonra", ["UASCO-T0069.c", "REVIEWED"] in T["UASCO-T0031.c"]['deps'])
chk("PR-231 ön koşulu kit", "UASCO-T0031.c" in BUNDLES["PR-231"]['preconditions'])
chk("V3-T1014 ← #231 MERGED", ["UASCO-T0069.c", "MERGED"] in T["V3-T1014"]['deps'])
chk("V3-T1008 başlangıç kapısı yok", T["V3-T1008"]['startGates'] == [])
chk("R: registries/ klasörü korumalı (içinde korumalı dosya)", is_protected("registries/"))
chk("R: renderer/ klasörü korumalı", is_protected("apps/desktop/renderer/"))
chk("R: kabul kiti yetki-hassas", is_auth("docs/acceptance/windows/founder-acceptance.mjs"))
chk("R: docs/x.mjs yetki-hassas", is_auth("docs/lanes/x.mjs"))
chk("R: V3-T1008 T2", T["V3-T1008"]['authorityTier'] == "T2")
chk("R: UASCO-T0031 T2", T["UASCO-T0031"]['authorityTier'] == "T2")
chk("R: UASCO-T0077 (package.json) T2", T["UASCO-T0077"]['authorityTier'] == "T2")
chk("R: rutin prompt'larında Haiku yok", T["UASCO-T0116"]['model'] != "haiku" and T["UASCO-T0117"]['model'] != "haiku")
chk("R: kit ← reseal:REVIEWED", ["UASCO-T0069.c", "REVIEWED"] in T["UASCO-T0031.c"]['deps'])
chk("R: UASCO-T0016 reseal gerekiyor (manifest write set)", any(MANIFEST in [canon_path(f) for f in T[k]['targetFiles']] for k in [T["UASCO-T0016"]['id']] + T["UASCO-T0016"].get('splitInto', [])))
chk("R: UASCO-T0120 CI'sız değil", "CI'sız" not in T["UASCO-T0120"]['prMerge'])
chk("R3: V3-T1021 (docs/register) T2", T["V3-T1021"]['authorityTier'] == "T2")
chk("R2: docs/policy T2", T["UASCO-T0121"]['authorityTier'] == "T2" and T["UASCO-T0121"]['model'] != "haiku")
chk("R2: register'a LLM yazmıyor", not any(OPEN(t) and t['targetFiles'] and all(f.startswith("EXT:register") for f in t['targetFiles']) and t['model'] != "deterministic" for t in T.values()))
chk("R2: norm 'NEW:docs/routines (…)' dizin", _s.overlap("NEW:docs/routines (prompt sürümleri)", "docs/routines/heartbeat.md"))
chk("R2: bağımsız normalizasyon da dizin", _s.audit_norm("NEW:docs/routines (prompt sürümleri)") == "docs/routines/")
import sim as _s
chk("overlap dizin/dosya", _s.overlap("core/workos/predev/", "core/workos/predev/claude-builder.ts"))
chk("overlap NEW/PR önek normalize", _s.overlap("NEW:config/authority-matrix.json", "config/authority-matrix.json") and _s.overlap("PR231:core/sandbox/x.ts", "core/sandbox/"))
chk("overlap farklı dosya yok", not _s.overlap("core/workos/store.ts", "core/workos/store-x.ts"))
chk("overlap EXT yok", not _s.overlap("EXT:Founder-PC", "EXT:Founder-PC"))
# ------------------------------------------------ simulation
import sim
SIM = sim.run_all(T, BUNDLES, bundle_of, r1, D, errs)
# ------------------------------------------------ critical path
cl = set()
def addc(x):
    if x in cl: return
    cl.add(x)
    for d in T[x]['dependsOn']:
        if OPEN(T[d]): addc(d)
for x in r1:
    if x in T and OPEN(T[x]): addc(x)
memo = {}
def lp(x, i):
    if (x, i) in memo: return memo[(x, i)]
    b = (0, [])
    for d in T[x]['dependsOn']:
        if d in cl:
            c = lp(d, i)
            if c[0] > b[0]: b = c
    memo[(x, i)] = (b[0] + T[x]['effort'][i], b[1] + [x]); return memo[(x, i)]
cpmax = max((lp(x, 1) for x in sorted(cl)), key=lambda v: v[0]); cpmin = lp(cpmax[1][-1], 0)
for x in cl:
    if wi(T[x]['wave']) > 1: errs.append(f"R1 closure after W1: {x}")
# ------------------------------------------------ evidence counters (EX-10)
ev = dict(EVIDENCE_SPEC_COUNT=len(AC), EVIDENCE_VERIFIED_PASS_COUNT=0, LEGACY_UNIT_EVIDENCE_TO_RELINK=sum(1 for a in AC.values() if a['currentStatus'].startswith("LEGACY")),
          NOT_PRODUCED=sum(1 for a in AC.values() if a['currentStatus'] == "NOT_PRODUCED"), STABILITY_MONITORING_ACS=len(STABILITY_ACS),
          R1_GATE_ACS_ACCEPTANCE=sum(1 for a in AC.values() if a['releaseGate'] == "R1" and a['acId'] not in STABILITY_ACS), R1_GATE_ACS_MONITORING=sum(1 for a in AC.values() if a['releaseGate'] == "R1" and a['acId'] in STABILITY_ACS))
# ------------------------------------------------ outputs
os.makedirs(OUT, exist_ok=True)
def wj(n, o): json.dump(o, open(f"{OUT}/{n}.json", "w"), ensure_ascii=False, indent=1, sort_keys=False)
esc_ = lambda s: str(s).replace("|", "\\|").replace("\n", " ")
jn = lambda x: ", ".join(x) if x else "—"
for t in T.values(): t['epic'] = F[t['v3Feature']]['epic']; t['bundle'] = bundle_of.get(t['id'], "")
COLS = ["id", "parentId", "legacyId", "v3Feature", "epic", "name", "v31Status", "phase", "wave", "lane", "bundle", "completesAt", "deps", "slotRequired", "model", "escalation", "reviewModel",
        "authorityTier", "tierReason", "tierProvisional", "securitySensitive", "costClass", "effort", "targetFiles", "targetBasis", "writeSetSource", "bundleFileException", "protectedFiles", "authorityFiles",
        "startGates", "mergeGates", "work", "doneMerge", "monitoring", "acId", "acType", "evidenceId", "deliveryScenario", "prMerge", "source"]
DISC = "DISCOVER (≤15 dk): base SHA; targetFiles varlığı + açık PR çakışması (git diff --name-only); claim (supervisor claim tablosu, atomik); ilgili testler; ≤10 sembol; tüm repo okunmaz"
for t in T.values():
    t['discovery'] = DISC + ((" · ÖZEL: " + DISCOVERY[t['id']]) if t['id'] in DISCOVERY else "")
    t['acText'] = AC[t['acId']]['criterion'] if t['acId'] else ""
COLS += ["executionLocation", "localRuntimeRequired", "cloudOnlyOverride", "cloudOnlyStatus", "historicalName", "historicalTargetFiles", "historicalDone", "laneHint"]
COLS.insert(COLS.index("work"), "discovery"); COLS.insert(COLS.index("acType"), "acText")
order = sorted(T, key=lambda x: (wi(T[x]['wave']), x))
rows = [{c: T[k].get(c, "" if c not in ("deps", "targetFiles", "startGates", "mergeGates", "protectedFiles", "authorityFiles", "bundleFileException") else []) for c in COLS} for k in order]
meta = dict(schema="UASCO_V4_1_EXECUTION/1.2-patchEX-cloudOnly", status="FINAL_CANDIDATE_NOT_IN_FORCE", cloudOnly=dict(rules="v41/cloud_only.py CO-1..CO-9", log=CO.LOG, newTasks=sorted(CO.NEW), overrides=sorted(CO.OV)), base=BASE, bundles=BUNDLES, authStates=AUTH_STATES, states=STATES,
            generator="v41/build.py + patch_ex.py + cloud_only.py + sim.py (tek veri kaynağı)")
wj("02_V4_1_EXECUTION_MATRIX", dict(meta=meta, acNotes={"V3-AC-F009-2": "RunAsNode off D-27'ye bağlı (G-11)", "V3-AC-F057-2": "şablon kilit dosyası ön koşul (G-08)"}, stabilityAcs=STABILITY_ACS, tasks=rows))
with open(f"{OUT}/02_V4_1_EXECUTION_MATRIX.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh); w.writerow(COLS)
    for r in rows: w.writerow([json.dumps(r[c], ensure_ascii=False) if isinstance(r[c], (list, dict)) else r[c] for c in COLS])
fmt_deps = lambda ds: ", ".join(f"{d}:{s}" for d, s in ds) if ds else "—"
mm = ["# 02 — V4.1 Yürütme Matrisi (patch EX-01..EX-10)", "", "> Bütün alanlar: `02_V4_1_EXECUTION_MATRIX.json` / `.csv`. Bağımlılıklar tipli: `Task:DURUM` (CODE_READY · REVIEWED · MERGED · ACCEPTED · DONE). Tamamlanma durumu `completesAt`.", "",
      "| Task | Üst | Feature | Ad | Durum | Dalga | Lane | Paket | completesAt | Bağımlılık (tipli) | Model | Review | Tier | START | MERGE | AC (tip) | Merge ölçütü | İzleme (kapı değil) |", "|" + "---|" * 18]
for r in rows:
    if r['v31Status'] in DONE_ST: continue
    mm.append(f"| {r['id']} | {r['parentId'] or '—'} | {r['v3Feature']} | {esc_(r['name'])} | {r['v31Status']} | {r['wave']} | {r['lane']} | {r['bundle'] or '—'} | {r['completesAt']} | {fmt_deps(r['deps'])} | {esc_(r['model'])} | {esc_(r['reviewModel'])} | {r['authorityTier']}{'*' if r['tierProvisional'] else ''} | {jn(r['startGates'])} | {jn(r['mergeGates'])} | {r['acId'] or '—'} ({r['acType']}) | {esc_(r['doneMerge'])} | {esc_(r['monitoring']) or '—'} |")
mm += ["", "`*` = tier geçici (NEW_PROVISIONAL yol; keşifte kesinleşince yeniden sınıflanır, düşürülmez).", "", "## ASSET / DONE_OBSERVED kayıtları", "", ", ".join(r['id'] for r in rows if r['v31Status'] in DONE_ST)]
fcov = ["", "## Feature kapsamı (57/57)", "", "| Feature | Epic | Ad | Açık Task | Dalgalar | AC |", "|---|---|---|---|---|---|"]
for fid in sorted(F):
    ts = [t for t in T.values() if t['v3Feature'] == fid and OPEN(t)]
    fcov.append(f"| {fid} | {F[fid]['epic']} | {esc_(F[fid]['name'])} | {len(ts)} | {jn(sorted({t['wave'] for t in ts}))} | {jn(F[fid]['acceptanceCriteria'])} |")
open(f"{OUT}/02_V4_1_EXECUTION_MATRIX.md", "w").write("\n".join(mm + fcov) + "\n")
# graph
edges = [(d, s, k) for k, t in T.items() for d, s in t['deps']]
wj("03_V4_1_WAVE_DEPENDENCY_GRAPH", dict(meta=meta, waves={w: sorted(k for k, t in T.items() if t['wave'] == w and OPEN(t)) for w in ["W0", "W1", "W2", "W3", "W4", "W5"]},
                                       edges=edges, r1Closure=sorted(cl), criticalPath=dict(chain=cpmax[1], hoursMin=round(cpmin[0], 1), hoursMax=round(cpmax[0], 1))))
nid = lambda x: x.replace("-", "_").replace(".", "_")
g = ["# 03 — Dalga ve Bağımlılık Grafiği (tipli)", "", f"Kritik yol: **{' → '.join(cpmax[1])}** = {cpmin[0]:.0f}–{cpmax[0]:.0f} h (ESTIMATE). R1 kapanış kümesi {len(cl)} Task.", "", "```mermaid", "flowchart LR"]
for x in sorted(cl): g.append(f'  {nid(x)}["{x}<br/>{T[x]["lane"]}·{T[x]["wave"]}·{T[x]["completesAt"]}"]')
for d, s, k in sorted(edges):
    if d in cl and k in cl: g.append(f'  {nid(d)} -->|{s}| {nid(k)}')
g += ["```", "", "## PR paketleri", ""] + [f"- **{b}** ({v['pr']}): üyeler {' → '.join(v['members'])}; merge ön koşulu: {jn(v['preconditions'])}; write set {len(PRF[b]) if b in PRF else sum(len(T[m]['targetFiles']) for m in v['members'])} dosya{' (gerçek PR)' if b in PRF else ' (yeni PR; sıralı devir)'}; reseal penceresi kilidi: {'evet' if v.get('lock') else 'hayır'}" for b, v in BUNDLES.items()]
g += ["", "## Dalga başına açık Task'lar", ""]
for w in ["W0", "W1", "W2", "W3", "W4", "W5"]:
    ks = sorted(k for k, t in T.items() if t['wave'] == w and OPEN(t))
    g += [f"### {w} — {len(ks)} Task · {sum(T[k]['effort'][0] for k in ks):.0f}–{sum(T[k]['effort'][1] for k in ks):.0f} h", "", ", ".join(ks), ""]
open(f"{OUT}/03_V4_1_WAVE_DEPENDENCY_GRAPH.md", "w").write("\n".join(g) + "\n")
# model/lane
open_t = [t for t in T.values() if OPEN(t)]
mc = collections.Counter(t['model'] for t in open_t); me = collections.defaultdict(lambda: [0, 0])
for t in open_t: me[t['model']][0] += t['effort'][0]; me[t['model']][1] += t['effort'][1]
lc = collections.Counter((t['wave'], t['lane']) for t in open_t)
LN = ["A_UI", "B_API", "C_ENGINE", "D_CI_RELEASE", "E_CONTROL", "F_FOUNDER"]
ml = ["# 04 — Model / Ajan / Lane Atama Matrisi", "", "## Kurallar", "",
      "- **Lane = dosya sahipliği; slot = eşzamanlılık.** En fazla 3 kodlama slotu (D-12 verilmeden 1). Deterministik ve Founder Task'ları slot kullanmaz.",
      "- **Claim:** Execution'da tek supervisor bütün slotları dağıtır; claim tablosu supervisor'dadır (tek yazar, atomik). Claim Task başlarken alınır, PR paketi MERGED olana kadar tutulur. Önek/dizin çakışması da çakışma sayılır. Aynı lane'deki iki Task da aynı dosyayı aynı anda tutamaz.",
      "- **PR paketleri (tek PR dalında sıralı devir):** " + "; ".join(f"{b}: {' → '.join(v['members'])}" for b, v in BUNDLES.items()) + ". Paket içindeki tests/docs dosyaları paket birincil sahibine aittir.",
      "- **Karma owner:** birden çok lane'e dokunan açık Task'lar otomatik olarak `<id>.<A|B|C|D|E|F>` alt Task'larına bölündü (EX-03). Ebeveyn SPLIT olur.",
      "- **Review modeli:** T0 deterministik · T1 taze Sonnet · T2 taze Opus · T3 taze Opus + Founder · güvenlik-hassas dosyalar taze Opus.",
      "- **Yükselme:** Haiku → Sonnet (diff > 80 satır ya da 2× FAIL); Sonnet → Opus (2 farklı hipotez ya da aynı fingerprint 2×), tek seferlik; ardından BLOCKED_WITH_EVIDENCE.",
      "- **Haiku yasak:** korumalı, yetki-hassas ve güvenlik-hassas dosyalar (build kontrolü).", "",
      "## Model dağılımı (açık Task; ESTIMATE)", "", "| Model | Task | Efor h |", "|---|---|---|"] + [f"| {m} | {n} | {me[m][0]:.0f}–{me[m][1]:.0f} |" for m, n in mc.most_common()]
ml += ["", "## Dalga × lane", "", "| Dalga | " + " | ".join(LN) + " |", "|" + "---|" * 7] + [f"| {w} | " + " | ".join(str(lc.get((w, l), 0)) for l in LN) + " |" for w in ["W0", "W1", "W2", "W3", "W4", "W5"]]
ml += ["", "## EX-03 ile bölünen Task'lar", "", "| Ebeveyn | Alt Task'lar |", "|---|---|"] + [f"| {p} | {', '.join(k)} |" for p, k in sorted(splits.items())]
open(f"{OUT}/04_V4_1_MODEL_LANE_ASSIGNMENT.md", "w").write("\n".join(ml) + "\n")
# decisions
dj = []
for d in D:
    rec = dict(id=d[0], group=d[1], deadline=d[2], title=d[3], why=d[4], options=d[5], recommendation=d[6], riskCost=d[7], blocks=d[8], defaultIfUndecided=d[9], aliases=d[10], status="AWAITING_FOUNDER")
    dj.append(rec)
CO.apply_decisions(dj)   # cloud-only (CO-9)
assert len(dj) == 31
ids = {d['id'] for d in dj}
for t in T.values():
    for gg in t['gates']:
        if gg not in ids: errs.append(f"unknown gate {gg} in {t['id']}")
for d in dj: d['gatedTasks'] = sorted(k for k, t in T.items() if d['id'] in t['gates'])
wj("06_V4_1_FOUNDER_DECISION_CENTER", dict(meta=meta, note="Hiçbir karar verilmedi.", authStates=AUTH_STATES, aliases=FD_ALIAS, decisions=dj))
names = {0: "0. Execution başlangıcı (tek zorunlu karar)", 1: "1. Alan kapıları — ilgili merge / paralellik / Windows kabulünden önce", 2: "2. Kodlama sürerken", 3: "3. İleri fazlar", 9: "Birleştirilen kararlar"}
dc = ["# 06 — Founder Karar Merkezi (V4.1 patch)", "", "> Hiçbir karar verilmedi. Güvenlik, harcama, secret, dış dağıtım ve korunan yol onayları kaldırılmadı.", "",
      "## Yetkilendirme durumları (EX-05)", "", "| Durum | Anlamı | Gereken |", "|---|---|---|"] + [f"| {a} | {b} | {c} |" for a, b, c in AUTH_STATES]
dc += ["", "## Alias (kapanış → V4.1)", "", "| Eski | V4.1 |", "|---|---|"] + [f"| {k} | {v} |" for k, v in FD_ALIAS.items()]
for gid in (0, 1, 2, 3, 9):
    ds_ = [d for d in dj if d['group'] == gid]
    if not ds_: continue
    dc += ["", f"## {names[gid]} ({len(ds_)})", ""]
    for d in ds_:
        dc += [f"### {d['id']} — {d['title']}", f"- **Neden:** {d['why']}", f"- **Seçenekler:** {d['options']}", f"- **Öneri:** {d['recommendation']}", f"- **Risk / maliyet:** {d['riskCost']}",
               f"- **Bloke ettiği:** {d['blocks']}" + (f" · matriste: {', '.join(d['gatedTasks'])}" if d['gatedTasks'] else ""), f"- **Karar yoksa:** {d['defaultIfUndecided']}", f"- **En geç:** {d['deadline']}", f"- **Alias:** {d['aliases']}", ""]
open(f"{OUT}/06_V4_1_FOUNDER_DECISION_CENTER.md", "w").write("\n".join(dc) + "\n")
# reconciliation (G/X/B) — önceki ile aynı
gx = dict(findings=[dict(zip(["id", "severity", "title", "verdict", "evidence", "features", "tasks", "change", "rationale", "dependencyEffect", "modelLaneEffect", "exeEffect", "decision", "closureBlocker"], x)) for x in G],
          revisions=[dict(zip(["id", "title", "verdict", "findings", "appliedAs"], x)) for x in X], closureBlockers=[dict(zip(["id", "title", "feature", "tasks", "decisions", "plan"], b)) for b in BLOCKERS])
for b in gx['closureBlockers']:
    for tok in b['tasks'].split(","):
        if tok.strip() and tok.strip() not in T: errs.append(f"{b['id']} unknown task {tok}")
wj("07_V4_1_AUDIT_CLOSURE_RECONCILIATION", dict(meta=meta, **gx))
rc = ["# 07 — Uzlaştırma: G-01..G-21 · X-01..X-16 · B1–B8", "", "> CLOUD-ONLY: G/X/B kayıtları denetim anının tarihsel kaydıdır. Founder-PC/WSL doğrulama yöntemleri bulut eşdeğerleriyle değişti (hosted Windows runner, bulut sandbox; Founder-PC yalnız `.exe` UAT). Geçerli kurallar: 17_CLOUD_ONLY_MERGE_REPORT.md.", "", "(EX-01..EX-10 kapanışı ayrı: 12_EX_FINDINGS_CLOSURE.md)", "", "| ID | Önem | Başlık | Karar | Task | Değişiklik | Founder | B |", "|---|---|---|---|---|---|---|---|"]
rc += [f"| {x[0]} | {x[1]} | {esc_(x[2])} | {x[3]} | {esc_(x[6])} | {esc_(x[7])} | {x[12]} | {x[13]} |" for x in G]
rc += ["", "| X | Başlık | Karar | G | Uygulanış |", "|---|---|---|---|---|"] + [f"| {x[0]} | {esc_(x[1])} | {x[2]} | {x[3]} | {esc_(x[4])} |" for x in X]
rc += ["", "| B | Blokaj | Feature | Task | Karar | Plan |", "|---|---|---|---|---|---|"] + [f"| {b[0]} | {esc_(b[1])} | {b[2]} | {b[3]} | {b[4]} | {esc_(b[5])} |" for b in BLOCKERS]
open(f"{OUT}/07_V4_1_AUDIT_CLOSURE_RECONCILIATION.md", "w").write("\n".join(rc) + "\n")
# simulation output
wj("13_V4_1_DISPATCH_SIMULATION", SIM)
base175 = set(t['id'] for t in tm['tasks']) | set(NEW_TASKS)
if len(base175) != 175 or not base175 <= set(T): errs.append('base175 missing')
summ = dict(tasks=len(T), base175=len(base175 & set(T)), cloudNew=sorted(CO.NEW), cloudLog=CO.LOG, exNew=sorted(NEW_TASKS_EX), exSplitChildren=sum(len(v) for v in splits.values()), legacy=129, v31new=35, v41new=sum(1 for t in T.values() if t['v31Status'].startswith("PROPOSED_V4_1")), open=len(open_t),
            byStatus=dict(collections.Counter(t['v31Status'] for t in T.values())), waves={w: sum(1 for t in open_t if t['wave'] == w) for w in ["W0", "W1", "W2", "W3", "W4", "W5"]},
            waveEff={w: [round(sum(t['effort'][0] for t in open_t if t['wave'] == w), 2), round(sum(t['effort'][1] for t in open_t if t['wave'] == w), 2)] for w in ["W0", "W1", "W2", "W3", "W4", "W5"]},
            cp=dict(chain=cpmax[1], min=round(cpmin[0], 2), max=round(cpmax[0], 2)), r1=dict(n=len(cl), eff=[round(sum(T[x]['effort'][0] for x in cl), 2), round(sum(T[x]['effort'][1] for x in cl), 2)]),
            models={m: [n, [round(me[m][0], 2), round(me[m][1], 2)]] for m, n in mc.items()}, tiers=dict(collections.Counter(t['authorityTier'] for t in open_t)),
            splits=splits, evidence=ev, selftest=SELFTEST, sim=dict((k, v['summary']) for k, v in SIM['scenarios'].items()), errors=errs, warnings=warns,
            first=SIM['scenarios']['S1_D01_ONLY']['summary']['startedFirst'])
json.dump(summ, open(f"{OUT}/_summary.json", "w"), ensure_ascii=False, indent=1, default=str)
print(json.dumps(dict(errors=errs, sim=summ['sim'], tiers=summ['tiers'], splits=list(splits), ev=ev), ensure_ascii=False, default=str)[:4000])
