# 3-slot dispatch simülasyonu (EX-01, EX-03, EX-05): tipli bağımlılık, PR paketleri, karar kapıları, claim tutma, kilitlenme analizi.
import re
RANK = {"PLANNED": 0, "READY": 1, "CODING": 2, "CODE_READY": 3, "REVIEWED": 4, "MERGED": 5, "ACCEPTED": 6, "DONE": 6}
DONE_ST = ("ASSET_DONE", "ASSET_CODED_UNWIRED", "DONE_OBSERVED")
RESOURCE_EXT = ("EXT:register", "EXT:coord-ledger", "EXT:supervisor", "EXT:GitHub", "EXT:claude.ai")   # paylaşılan dış kaynaklar da claim edilir (R-review D3)
def norm(p):
    if p.startswith("EXT:"):
        for r in RESOURCE_EXT:
            if p.startswith(r): return r + "/"
        return None
    q = p.split(":", 1)[1] if p.startswith(("NEW:", "PR231:", "PR247:")) else p
    q = re.sub(r"\s*\(.*\)$", "", q).lstrip("/").strip()
    if q and not q.endswith("/") and ("(keşif)" in p or "." not in q.split("/")[-1]): q += "/"   # uzantısız ya da belirsiz yol: dizin öneki (R2-N1)
    return q
import posixpath
# cloud-only CO-7: kabul ortamı = Founder-PC (yalnız UAT) ∪ hosted Windows runner (#231 kiti). Kit dışı Task'larda davranış birebir aynıdır.
def ext(t): return t["lane"] == "F_FOUNDER" or any(f.startswith("EXT:Cloud-Windows-Runner") for f in t["targetFiles"])
def env(t): return any(f.startswith(("EXT:Founder-PC", "EXT:Cloud-Windows-Runner")) for f in t['targetFiles'])
def audit_norm(p):
    """Claim normalizasyonundan bağımsız uygulama (R2-N1): ayrı kurallar, aynı amaç."""
    if p.startswith("EXT:"):
        head = p.split(" ")[0].split("(")[0]
        for r in ("EXT:register", "EXT:coord-ledger", "EXT:supervisor", "EXT:GitHub", "EXT:claude.ai"):
            if head.startswith(r) or p.startswith(r): return r + "/"
        return None
    body = p.split(":", 1)[1] if p.split(":", 1)[0] in ("NEW", "PR231", "PR247", "PR251") else p
    body = body.split(" (")[0].split("(")[0].strip().strip("/")
    norm_ = posixpath.normpath(body) if body else ""
    if not norm_ or norm_ == ".": return None
    is_dir = p.rstrip().endswith("/") or body.endswith("/") or posixpath.splitext(norm_)[1] == "" or "(keşif)" in p
    return norm_ + "/" if is_dir else norm_
def overlap(a, b):
    a, b = norm(a), norm(b)
    if not a or not b: return False
    if a == b: return True
    if a.endswith("/") and b.startswith(a): return True
    if b.endswith("/") and a.startswith(b): return True
    return False
def sat(state, need):
    if need in ("ACCEPTED", "DONE"): return state in ("ACCEPTED", "DONE", "MERGED") if need == "DONE" else state == "ACCEPTED"
    return RANK.get(state, 0) >= RANK[need]
def run(T, BUNDLES, bundle_of, r1, granted, founder_env, slots_max, name, dur_override=None, disable_claims=False, disable_lock=False, kit_fail_first=0, founder_off_after_lock=False):
    tasks = {k: t for k, t in T.items() if t['v31Status'] not in DONE_ST and t['v31Status'] != "SPLIT"}
    state = {k: ("MERGED" if T[k]['v31Status'] in DONE_ST else ("SPLIT" if T[k]['v31Status'] == "SPLIT" else "PLANNED")) for k in T}
    dur = {k: max(0.25, (t['effort'][0] + t['effort'][1]) / 2) for k, t in tasks.items()}
    dur.update(dur_override or {})
    abort_count = {}; invalid_on_finish = set(); escalated = set(); kit_fails = {}; kit_ready_t = [None]; reopened = []
    held, running = {}, {}
    founder_free, merge_free = 0.0, 0.0
    slots_max = min(slots_max, 3 if "D-12" in granted else 1)   # R-review D5
    now = 0.0; log = []; conflicts = 0; maxslots = 0; started_first = []
    unit = lambda k: bundle_of.get(k, k)
    deps_ok = lambda k: all(sat(state[d], s) for d, s in T[k]['deps'])
    gates_ok = lambda k, kind: all(g in granted for g in T[k][kind])
    def claim_ok(k):
        if disable_claims: return True
        for o, fs in held.items():
            if o == k: continue
            if unit(o) == unit(k) and o not in running: continue   # aynı PR: yalnız eşzamanlı kodlama yasak
            if any(overlap(a, b) for a in T[k]['targetFiles'] for b in fs): return False
        return True
    lock = [None]; lock_t = [0.0]; aborts = []; lock_start = [0.0]; founder_gone = [False]
    tail = {}
    rev = {}
    for k2, t2 in tasks.items():
        for d, _ in t2['deps']: rev.setdefault(d, []).append(k2)
    def tl(k):
        if k in tail: return tail[k]
        tail[k] = 0.0
        tail[k] = dur.get(k, 0) + max([tl(c) for c in rev.get(k, []) if c in tasks] or [0]); return tail[k]
    for k in tasks: tl(k)
    prio = lambda k: (0 if k in r1 else 1, -round(tail[k], 2), int(T[k]['wave'][1]), k)   # kritik yol (en uzun kalan zincir) önce
    def is_code(k): return T[k]['completesAt'] in ("MERGED", "REVIEWED") and not ext(T[k])
    for _ in range(100000):
        changed = False
        for k, e in sorted(running.items(), key=lambda x: (x[1], x[0])):
            if e <= now + 1e-9:
                del running[k]; changed = True
                state[k] = "REVIEWED" if is_code(k) else T[k]['completesAt']
                if k in invalid_on_finish: state[k] = "PLANNED"; invalid_on_finish.discard(k); log.append((round(now, 2), "invalidated", k, "kit eski head için"))
                ub = next((b for b, v in BUNDLES.items() if k in v['preconditions']), None)
                if ub and state[k] == "ACCEPTED" and kit_fails.get(k, 0) < kit_fail_first:   # R3-L2: kit NOT_ACCEPTED
                    kit_fails[k] = kit_fails.get(k, 0) + 1; state[k] = "PLANNED"
                    for m in BUNDLES[ub]['members']: state[m] = "PLANNED"   # aynı paket içinde düzeltme; claim'ler pakette kalır
                    reopened.append((round(now, 2), ub)); log.append((round(now, 2), "kit_failed", ub, k)); aborts.append((round(now, 2), ub + " (kit NOT_ACCEPTED)"))
                    abort_count[ub] = abort_count.get(ub, 0) + 1
                    if lock[0] == ub: lock[0] = None; kit_ready_t[0] = None; log.append((round(now, 2), "lock_abort", ub, "kit NOT_ACCEPTED"))
                    if abort_count[ub] >= 2: escalated.add(ub)
                if not is_code(k): held.pop(k, None)
                log.append((round(now, 2), "done", k, state[k]))
        if merge_free <= now + 1e-9:
            units = sorted({unit(k) for k in tasks if is_code(k) and state[k] == "REVIEWED"})
            for u in units:
                mem = BUNDLES[u]['members'] if u in BUNDLES else [u]
                if not all(state[m] == "REVIEWED" for m in mem): continue
                pre = BUNDLES[u]['preconditions'] if u in BUNDLES else []
                if not all(sat(state[p], T[p]['completesAt']) for p in pre): continue
                if not all(gates_ok(m, 'mergeGates') for m in mem): continue
                if lock[0] and lock[0] != u and not disable_lock: continue   # reseal penceresi: başka merge yok (base sabit)
                for m in mem: state[m] = "MERGED"; held.pop(m, None)
                if lock[0] == u: lock[0] = None
                merge_free = now + 1.0; changed = True
                log.append((round(now, 2), "merge", u, "")); break
        if lock[0] and kit_ready_t[0] is None and BUNDLES[lock[0]]['preconditions'] and any(pr in running for pr in BUNDLES[lock[0]]['preconditions']):
            kit_ready_t[0] = now; lock_t[0] = now   # R4-L1: süre kit fiilen başladığında başlar
        prekit_expired = bool(lock[0] and BUNDLES[lock[0]]['preconditions'] and kit_ready_t[0] is None and BUNDLES[lock[0]]['lockStartsWith'] not in running
                              and now - lock_start[0] > BUNDLES[lock[0]].get('lockPrekitTimeoutH', 8) + 1e-9)   # R5: kit başlamadan bekleme sınırı
        if lock[0] and (prekit_expired or (kit_ready_t[0] is not None and now - lock_t[0] > BUNDLES[lock[0]].get('lockTimeoutH', 24) + 1e-9)):   # zaman aşımı → iptal
            u = lock[0]; m = BUNDLES[u]['lockStartsWith']
            if m not in running:
                state[m] = "PLANNED"; held.pop(m, None)
                for pr in BUNDLES[u]['preconditions']:
                    if pr in running: invalid_on_finish.add(pr)
                    elif state[pr] != "PLANNED": state[pr] = "PLANNED"
                abort_count[u] = abort_count.get(u, 0) + 1
                if abort_count[u] >= 2: escalated.add(u)
                aborts.append((round(now, 2), u)); log.append((round(now, 2), "lock_abort", u, m)); lock[0] = None; kit_ready_t[0] = None; changed = True
        for ub in sorted(escalated):   # R3-L3: güvenli varsayılan — paket DEFERRED, claim'ler serbest
            for mm in BUNDLES[ub]['members']:
                if mm not in running and state[mm] != "DEFERRED_ESCALATED": state[mm] = "DEFERRED_ESCALATED"; held.pop(mm, None); changed = True; log.append((round(now, 2), "deferred", mm, ub))
        free = slots_max - sum(1 for k in running if T[k]['slotRequired'])
        for k in sorted([k for k in tasks if state[k] == "PLANNED" and deps_ok(k) and gates_ok(k, 'startGates') and (is_code(k) or gates_ok(k, 'mergeGates'))], key=prio):
            t = T[k]
            u = unit(k)
            if u in BUNDLES and BUNDLES[u].get('lockStartsWith') == k:
                if lock[0] and lock[0] != u: continue
                if u in escalated: continue   # 2 iptalden sonra Founder'a eskalasyon; yeni kilit yok
                if not all(gates_ok(m, 'mergeGates') for m in BUNDLES[u]['members']): continue   # reseal yalnız merge yetkisi varken başlar
                pre_ok = True
                for pr in BUNDLES[u]['preconditions']:
                    tp = T[pr]
                    if not all(g in granted for g in tp['startGates'] + tp['mergeGates']): pre_ok = False
                    if ext(tp) and env(tp) and not founder_env: pre_ok = False
                if not pre_ok: continue   # R2-N0: ön koşul başlatılamıyorsa kilit alınmaz
                if BUNDLES[u]['preconditions'] and founder_free > now + 1e-9: continue   # R4-L1: Founder meşgulken kilit alınmaz
                if any(running.get(x) for x in running if unit(x) != u and is_code(x) and x in tasks and False): pass
            if ext(t):
                if env(t) and not founder_env: continue
                if lock[0] and k not in BUNDLES[lock[0]]['preconditions'] and not all(sat(state[p], T[p]['completesAt']) for p in BUNDLES[lock[0]]['preconditions']): continue   # R3-L1: Founder kit için ayrılmış
                if founder_free > now + 1e-9: continue
                if founder_gone[0]: continue
                founder_free = now + dur[k]
            elif t['slotRequired']:
                if free <= 0 or not claim_ok(k): continue
                free -= 1
            elif not claim_ok(k): continue
            if u in BUNDLES and BUNDLES[u].get('lockStartsWith') == k:
                lock[0] = u; lock_t[0] = now; lock_start[0] = now; log.append((round(now, 2), "lock", u, k))
                if founder_off_after_lock and BUNDLES[u]['preconditions']: founder_gone[0] = True
            state[k] = "CODING"; running[k] = now + dur[k]; changed = True
            if lock[0] and kit_ready_t[0] is None and k in BUNDLES[lock[0]]['preconditions']: kit_ready_t[0] = now; lock_t[0] = now   # CO-7/R4-L1 düzeltmesi: lock süresi kit başladığı anda başlar (sonraki olayı beklemez)
            if not ext(t): held[k] = list(t['targetFiles'])
            if len(started_first) < 15: started_first.append(k)
            log.append((round(now, 2), "start", k, t['lane']))
        ks = sorted(held)
        for i in range(len(ks)):
            for j in range(i + 1, len(ks)):
                if unit(ks[i]) != unit(ks[j]) and any(overlap(x, y) for x in held[ks[i]] for y in held[ks[j]]):
                    conflicts += 1; log.append((round(now, 2), "CONFLICT", ks[i], ks[j]))
        maxslots = max(maxslots, sum(1 for k in running if T[k]['slotRequired']))
        nxt = [e for e in running.values() if e > now + 1e-9] + [x for x in (founder_free, merge_free) if x > now + 1e-9]
        if lock[0]:
            to = lock_t[0] + BUNDLES[lock[0]].get('lockTimeoutH', 24) + 0.01
            if to > now + 1e-9: nxt.append(to)
            if BUNDLES[lock[0]]['preconditions'] and kit_ready_t[0] is None:
                to2 = lock_start[0] + BUNDLES[lock[0]].get('lockPrekitTimeoutH', 8) + 0.01
                if to2 > now + 1e-9: nxt.append(to2)
        if not nxt:
            if not changed: break
            continue
        if not changed or True: now = min(nxt)
    # ---- bağımsız denetim (claim mantığından ayrı): günlükten aralıklar
    starts = {x[2]: x[0] for x in log if x[1] == "start"}; dones = {x[2]: x[0] for x in log if x[1] == "done"}
    merged_at = {}
    for x in log:
        if x[1] == "merge":
            for m in (BUNDLES[x[2]]['members'] if x[2] in BUNDLES else [x[2]]): merged_at[m] = x[0]
    def files2(k): return {x for x in (audit_norm(p) for p in T[k]['targetFiles']) if x}
    def clash(a, b): return any(x == y or (x.endswith("/") and y.startswith(x)) or (y.endswith("/") and x.startswith(y)) for x in a for y in b)
    # deneme bazında aralıklar: start → (aynı Task için lock_abort | birimin merge'ü | kod dışı/aynı birim için done)
    def intervals(k, same_unit_view):
        out, cur = [], None
        for x in log:
            if x[1] == "start" and x[2] == k: cur = x[0]
            elif cur is not None:
                end = None
                if x[1] == "lock_abort" and x[3] == k: end = x[0]
                elif x[1] == "merge" and x[2] == unit(k) and not same_unit_view and is_code(k): end = x[0]
                elif x[1] == "done" and x[2] == k and (same_unit_view or not is_code(k)): end = x[0]
                elif x[1] == "invalidated" and x[2] == k: end = x[0]
                elif x[1] == "deferred" and x[2] == k: end = x[0]
                if end is not None: out.append((cur, end)); cur = None
        if cur is not None: out.append((cur, now))
        return out
    audit = []
    ks = sorted({x[2] for x in log if x[1] == "start" and not ext(T[x[2]])})
    F2 = {k: files2(k) for k in ks}
    for i in range(len(ks)):
        for j in range(i + 1, len(ks)):
            a, b = ks[i], ks[j]
            if not clash(F2[a], F2[b]): continue
            same = unit(a) == unit(b)
            if any(s1 < e2 - 1e-9 and s2 < e1 - 1e-9 for s1, e1 in intervals(a, same) for s2, e2 in intervals(b, same)): audit.append((a, b))
    gate_bypass = [k for k in starts if any(g not in granted for g in T[k]['startGates'] + ([] if is_code(k) else T[k]['mergeGates']))]
    gate_bypass += [k for k in merged_at if any(g not in granted for g in T[k]['mergeGates'])]
    lock_violation = []
    for L in [x for x in log if x[1] == "lock"]:
        u = L[2]; t0 = L[0]
        t1 = min([x[0] for x in log if x[0] >= t0 and ((x[1] == "merge" and x[2] == u) or (x[1] == "lock_abort" and x[2] == u))] or [now])
        lock_violation += [x[2] for x in log if x[1] == "merge" and x[2] != u and t0 < x[0] < t1]
    freeze_violation = []
    for u, v in BUNDLES.items():
        fz = v.get('headFreezeAfter')
        if fz and fz in dones:
            freeze_violation += [m for m in v['members'] if starts.get(m, -1) >= dones[fz] or dones.get(m, -1) > dones[fz]]
    def fin(k): return state[k] == "MERGED" if is_code(k) else sat(state[k], T[k]['completesAt'])
    incomplete = [k for k in tasks if not fin(k)]
    def reason(k, seen):
        if k in seen: return ("CYCLE", k)
        seen = seen | {k}; t = T[k]
        miss = [g for g in t['startGates'] + t['mergeGates'] if g not in granted]
        if miss: return ("DECISION", ",".join(sorted(miss)))
        if ext(t) and env(t) and not founder_env: return ("FOUNDER_ENV", "Kabul ortamı (UAT / hosted runner)")
        if ext(t) and founder_gone[0]: return ("FOUNDER_UNAVAILABLE", "Founder ulaşılamaz (S9)")
        for d, s in t['deps']:
            if not sat(state[d], s): return reason(d, seen)
        if k in bundle_of and bundle_of[k] in escalated: return ("DECISION", "ESC-" + bundle_of[k] + " (yeni karar örneği; " + BUNDLES[bundle_of[k]].get('escalationDecision', 'D-07') + " kapsamında: yeniden dene / yeniden tasarla / ertele)")
        if state[k] == "PLANNED" and k in bundle_of and BUNDLES[bundle_of[k]].get('lockStartsWith') == k:
            miss = sorted({g for m in BUNDLES[bundle_of[k]]['members'] for g in T[m]['mergeGates'] if g not in granted})
            if miss: return ("DECISION", ",".join(miss))
        if state[k] == "REVIEWED" and lock[0] and lock[0] != unit(k): return ("MERGE_LOCK", lock[0])
        if state[k] == "PLANNED":
            for o, fs in held.items():
                if unit(o) != unit(k) and any(overlap(a, b) for a in T[k]['targetFiles'] for b in fs):
                    r = reason(o, seen)
                    return (r[0] if r[0] != "DEADLOCK" else "DEADLOCK", r[1] if r[0] != "DEADLOCK" else f"{k}<-claim:{o}")
        if k in bundle_of:
            u = bundle_of[k]
            for p in BUNDLES[u]['preconditions'] + BUNDLES[u]['members']:
                if p != k and not fin(p) and not (p in BUNDLES[u]['members'] and state[p] == "REVIEWED"): return reason(p, seen)
        return ("DEADLOCK", k)
    reasons = {k: reason(k, frozenset()) for k in incomplete}
    dead = sorted(k for k, r in reasons.items() if r[0] in ("DEADLOCK", "CYCLE"))
    by = {}
    for k, r in reasons.items(): by.setdefault(r[0], {}).setdefault(r[1], 0); by[r[0]][r[1]] += 1
    return dict(name=name, granted=sorted(granted), founderEnv=founder_env, slots=slots_max, simHours=round(now, 1), completed=len(tasks) - len(incomplete), total=len(tasks),
                incomplete=len(incomplete), deadlocks=dead, writeConflicts=conflicts, maxSlotsUsed=maxslots, blockedBy=by, startedFirst=started_first,
                independentAuditConflicts=audit, lockAborts=aborts, escalated=sorted(escalated), kitFailures=reopened, lockHeldAtEnd=lock[0], gateBypass=sorted(set(gate_bypass)), lockViolations=lock_violation, headFreezeViolations=freeze_violation,
                merges=[x[2] for x in log if x[1] == "merge"], conflictPairs=sorted({(x[2], x[3]) for x in log if x[1] == 'CONFLICT'})), log
def run_all(T, BUNDLES, bundle_of, r1, D, errs):
    all_ids = {d[0] for d in D}
    g1 = {"D-01", "D-23", "D-31", "D-03", "D-07", "D-12", "D-26", "D-18", "D-08"}
    sc = {
     "S0_NO_DECISION": (set(), False, 0),
     "S1_D01_ONLY": ({"D-01"}, False, 1),
     "S2_D01_GROUP1_NO_FOUNDER_ENV": (g1, False, 3),
     "S3_ALL_DECISIONS_FOUNDER_ENV": (all_ids, True, 3),
     "S4_ALL_DECISIONS_NO_FOUNDER_ENV": (all_ids, False, 3),
     "S5_KIT_EXCEEDS_LOCK_TIMEOUT": (all_ids, True, 3),
     "S6_KIT_FAILS_ONCE_THEN_PASSES": (all_ids, True, 3),
     "S7_KIT_FAILS_TWICE": (all_ids, True, 3),
     "S8_FOUNDER_TASKS_LONG": (all_ids, True, 3),
     "S9_FOUNDER_GONE_AFTER_LOCK": (all_ids, True, 3),
    }
    out = {}
    for n, (gr, env, slots) in sc.items():
        if not gr: out[n] = dict(summary=dict(name=n, note="D-01 yok: hiçbir Task başlatılmaz (repo yazma yok)", completed=0, deadlocks=[], writeConflicts=0, startedFirst=[])); continue
        ov = {"UASCO-T0031.c": 30.0} if n.startswith("S5") else ({k: 40.0 for k, t in T.items() if t.get('lane') == "F_FOUNDER" and k != "UASCO-T0031.c"} if n.startswith("S8") else None)
        s, log = run(T, BUNDLES, bundle_of, r1, gr, env, slots, n, dur_override=ov,
                     kit_fail_first=(1 if n.startswith("S6") else 2 if n.startswith("S7") else 0), founder_off_after_lock=n.startswith("S9"))
        out[n] = dict(summary=s, log=log[:400])
        if s['deadlocks']: errs.append(f"SIM {n} deadlock {s['deadlocks'][:5]}")
        if s['writeConflicts']: errs.append(f"SIM {n} write conflicts {s['writeConflicts']}")
        if s['maxSlotsUsed'] > slots: errs.append(f"SIM {n} slot overflow")
        if s['lockHeldAtEnd']: errs.append(f"SIM {n} lock held at end {s['lockHeldAtEnd']}")
        for key in ("independentAuditConflicts", "gateBypass", "lockViolations", "headFreezeViolations"):
            if s[key]: errs.append(f"SIM {n} {key} {s[key][:6]}")
    # negatif (mutasyon) testleri: denetim gerçekten ihlal yakalıyor mu?
    neg = {}
    for nm, kw in (("NEG_CLAIMS_DISABLED", dict(disable_claims=True)), ("NEG_LOCK_DISABLED", dict(disable_lock=True))):
        sN, _ = run(T, BUNDLES, bundle_of, r1, all_ids, True, 3, nm, **kw)
        neg[nm] = dict(independentAuditConflicts=len(sN['independentAuditConflicts']), lockViolations=len(sN['lockViolations']))
    if neg["NEG_CLAIMS_DISABLED"]["independentAuditConflicts"] == 0: errs.append("NEG: audit did not detect conflicts with claims disabled (vacuous)")
    if neg["NEG_LOCK_DISABLED"]["lockViolations"] == 0: errs.append("NEG: lock audit did not detect merges with lock disabled (vacuous)")
    out["NEGATIVE_TESTS"] = dict(summary=dict(name="NEGATIVE_TESTS", **neg))
    s6 = out["S6_KIT_FAILS_ONCE_THEN_PASSES"]['summary']; s7 = out["S7_KIT_FAILS_TWICE"]['summary']
    if not (s6['kitFailures'] and s6['incomplete'] == 0): errs.append("SIM S6 kit failure repair path did not complete")
    if not (s7['kitFailures'] and "PR-231" in s7['escalated'] and not s7['lockHeldAtEnd']): errs.append("SIM S7 escalation path not as expected")
    s9 = out["S9_FOUNDER_GONE_AFTER_LOCK"]['summary']
    if not (s9['lockAborts'] and not s9['lockHeldAtEnd'] and "PR-231" in s9['escalated']): errs.append("SIM S9 pre-kit timeout path not as expected")
    s8 = out["S8_FOUNDER_TASKS_LONG"]['summary']
    if s8['lockAborts'] or s8['incomplete']: errs.append(f"SIM S8 founder-busy aborts {s8['lockAborts'][:3]} incomplete {s8['incomplete']}")
    s5 = out["S5_KIT_EXCEEDS_LOCK_TIMEOUT"]['summary']
    if not (s5['lockAborts'] and "PR-231" in s5['escalated'] and not s5['lockHeldAtEnd']): errs.append("SIM S5 abort/escalation path not exercised as expected")
    if out["S3_ALL_DECISIONS_FOUNDER_ENV"]['summary']['incomplete']: errs.append("SIM S3 incomplete " + str(out["S3_ALL_DECISIONS_FOUNDER_ENV"]['summary']['blockedBy']))
    return dict(scenarios=out, rules="tipli bağımlılık; PR paketi merge = üyeler REVIEWED + ön koşullar + mergeGates; tek merger (1 h/merge, seri); claim Task başında alınır, MERGED'e kadar tutulur; önek/dizin çakışması; D-12 yoksa 1 slot")
