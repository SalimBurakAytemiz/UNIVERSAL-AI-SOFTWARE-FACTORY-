# 09 — UASCO V4.1 EXECUTION START DIRECTIVE (patch EX-05/06/07 + CLOUD-ONLY)

> **CLOUD-ONLY (2026-11-02, Founder yönergesi; birleştirme kuralları CO-1..CO-10: 17_CLOUD_ONLY_MERGE_REPORT.md).** Bütün geliştirme, model, test, güvenlik, sandbox, CI ve teslim bulutta yürür. Founder-PC yalnız imzalı/hash doğrulanmış `.exe`'nin kur/aç/kullan son kullanıcı kabulü (UASCO-T0002, T0002.a) içindir; BIOS/WSL/VM/Node/Claude CLI/yerel worker şartı yoktur. #231 (WSL2) AS-IS merge edilmez (D-07). Bulut sandbox/worker sağlayıcısı (D-03) verilmedikçe çalışma zamanı UNKNOWN: paket en fazla READY_FOR_CODING'dir, PRODUCT_READY değildir. UAT'tan önce cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS zorunludur.

> **Tek başlangıç koşulu: Founder'ın D-01 kararı** (V4.1 onayı + yazılı başlatma talimatı).
>
> - D-01 yoksa Execution oturumu repo'ya yazmaz. Yalnız §1'i çalıştırır ve "D-01 bekleniyor" raporlar.
> - D-01 varsa, karar beklemeyen Task'lar kendi `startGates`'leriyle başlar.
> - Diğer kararlar yalnız kendi alanlarını kapılar: merge, paralellik, Windows kabulü.
>
> Bu talimat yetki kapılarını değiştirmez; yeni roadmap yazılmaz.

## 0. Yetkilendirme durumları

| Durum | Anlamı | Gereken |
| --- | --- | --- |
| DESIGN_FINAL_CANDIDATE | Şu an. Repo'ya yazma yok. | — |
| FOUNDER_AUTHORIZED | D-01 verildi. Execution oturumu açılabilir; deterministik doğrulama ve register işleri başlar. | D-01 |
| CODE_ALLOWED | Task kendi startGates'i karara bağlıysa kodlanabilir, PR açılabilir. Slot sayısı: D-12 verilmeden 1, verildikten sonra 3. | D-01 + Task startGates (+ D-12 → 3 slot) |
| MERGE_ALLOWED | PR paketi review'dan geçti, mergeGates karara bağlı, T2 için Founder onayı var (D-31 paketi), birleşik SHA'da CI yeşil. | mergeGates (D-31, D-07, D-18, D-03, D-06, D-04, D-08, D-30) |
| WINDOWS_ACCEPTANCE_ALLOWED | Founder `.exe` UAT Task'ları (UASCO-T0002, T0002.a) başlayabilir; Founder-PC'de yalnız kur/aç/kullan. | D-23 + D-26 + cloud e2e CI PASS (CLOUD-T0011) + hosted Windows installer PASS (CLOUD-T0006) |

## 1. Doğrulama (deterministik, model yok; D-01'den önce de yapılabilir, salt-okur)

1. Paket kökünde:
   - Linux/macOS: `cd <paket-kökü> && python3 v41/verify.py`
   - Windows: `cd <paket-kökü>; py -3 v41\verify.py   # ya da: python v41\verify.py`
   - `verify.py` şunları yapar: (a) `SHA256_MANIFEST.txt` kontrolü; (b) `V41_PACKAGE_ROOT=<paket>` ile üreticiyi geçici dizine yeniden çalıştırır ve çıktıları paketle bayt bayt karşılaştırır; (c) 175 / 57 / 102 / 31 sayımı, hata listesinin boş olması, 3 simülasyon senaryosunda kilitlenme = 0 ve yazma çakışması = 0.
   - Çıkış kodu 0 değilse dur.
2. `git ls-remote origin refs/heads/v7/integration refs/heads/uasco/production-reports refs/heads/uasco/production-queue`. Paketteki SHA'lardan farklıysa fark raporu yaz; matrisi elle değiştirme.
3. Açık PR'ların changed-files listelerini `git diff --name-only <merge-base> <head>` ile yeniden çıkar ve `sources/repo/pr*.txt` ile karşılaştır. Fark varsa ilgili paketin Task'larını **BLOCKED_SOURCE_CHANGED** yap; diğer işler sürer.
4. `list_triggers` ile rutinlerin kapalı olduğunu doğrula. **Hiçbir rutini açma.**

## 2. Dispatch kuralları (simülasyonla aynı; 13_*)

- **Slot:** en fazla 3; **D-12 verilmeden 1.** Deterministik ve Founder Task'ları slot kullanmaz.
- **Seçim:** `state=PLANNED` · bütün `deps` (Task:DURUM) sağlanmış · `startGates` hepsi verilmiş · claim alınabilir · öncelik: R1 → en uzun kalan zincir → dalga → kimlik.
- **Claim:** tek supervisor tutar (tek yazar, atomik). Task başında `targetFiles` için alınır, PR paketi MERGED olana kadar tutulur. Önek/dizin çakışması çakışmadır. Aynı lane'deki Task'lar da aynı dosyayı aynı anda tutamaz. Tek istisna aynı PR paketinin üyeleri; bunlar sıralı devirle çalışır.
- **Durumlar:** kod Task'ı bitince REVIEWED. Tekil Task merge'de MERGED olur. Paket üyeleri paket merge'ünde birlikte MERGED olur. Founder kabul Task'ları ACCEPTED, kararlar ve kayıtlar DONE.
- **Merge (tek merger, seri; M0 geçici modu):** update-branch → birleşik SHA'da tam CI → ledger NO_BLOCKERS (aynı SHA/patch-id) → `mergeGates` verilmiş → T2 için Founder onayı → merge → post-merge push CI + installer. "Re-run failed jobs" yok.
- **PR-231 özel kuralı:** merge öncesi `T0031.c.kit.sha == PR head SHA`. Değilse kit yeniden. Merge sonrası parent2 = kabul edilen head.
- **Reseal penceresi kilidi:**
  - Manifest'e dokunan bir paketin reseal üyesi başladığında merger başka hiçbir merge yapmaz.
  - Reseal ancak şu koşullarla başlar: paketin bütün merge kapıları karara bağlı ve ön koşul Task'ları (ör. kabul kiti) başlatılabilir durumda (kapıları verilmiş, hosted Windows runner hazır).
  - Kilit başında merger paket dalını güncel base'e alır (update-branch), sonra reseal hesaplanır. Base kilitle sabittir; merge anında update-branch gerekmez.
  - **Zaman aşımı 24 h:** kilit bu sürede merge edilmezse ya da kit NOT_ACCEPTED dönerse kilit iptal edilir. Reseal commit'i geçersiz sayılır ve Task PLANNED'e döner; süren kit sonucu eski head için olduğundan geçersizdir. Merge'ler devam eder.
  - **Founder rezervasyonu:** kilit yalnız Founder boşken alınır ve kilit süresince Founder yalnız o paketin kitini yapar. Zaman aşımı, kit fiilen başladığı andan sayılır. Ön koşulsuz paketlerde zaman aşımı yoktur; reseal son üyedir ve hemen merge edilir.
  - **Kit öncesi zaman aşımı (8 h):** kilit alındıktan sonra kit 8 h içinde başlamazsa (ör. Founder ulaşılamaz) kilit iptal edilir.
  - **Eskalasyon kararı ayrı bir karar örneğidir (`ESC-<paket>`):** D-03 ya da D-07 kapsamında yeniden dene, yeniden tasarla ya da ertele. Önceden verilmiş bir D-03 onayı bunu karşılamaz. Devam kararından sonra serbest bırakılan dosyalar için rebase, yeniden review ve yeniden claim zorunludur.
  - **Kit NOT_ACCEPTED:** kilit bırakılır. Düzeltme aynı PR paketinde yapılır: üyeler yeniden açılır, claim'ler pakette kalır, dışarıdan PR gerekmez. Ardından kit yeniden koşulur.
  - **2 iptal ya da başarısızlıktan sonra** paket Founder'a eskalasyon edilir (PR-231 için D-03; diğerleri D-07). Karar yoksa güvenli varsayılan: paket DEFERRED, claim'ler serbest bırakılır, bağımlı Task'lar BLOCKED_DECISION olur. Diğer işler sürer.
  - Kilit süresince kodlama sürer, yalnız merge durur.
- **Mühürlü dosyalar:** trust-root manifest'indeki bir dosyaya dokunan her Task manifest'i de claim eder; reseal aynı PR'da D lane alt Task'ıyla yapılır (`<id>.D`).
- **Register:** yalnız deterministik araçlar yazar (CI'sız supervisor kaydı). LLM register'a, kanıt kaydına ya da supervisor durumuna doğrudan yazmaz.
- **Güvenlik/yetki kodu T2:** execution-gate, sandbox, runner, executors, claude-profiles, security-tools, secret-scan, test-surface, action-gateway, preload, devrun; ayrıca kabul kiti, docs altındaki çalıştırılabilir dosyalar, rutin prompt'ları, tedarik zinciri, release, model yönlendirmesi, supervisor araçları. Hepsi Founder T2 onayıyla merge edilir (D-31 paketi).
- **#282:** DEFER; merge yok, otomatik koşu yok; D-22.
- **Kanıt:** PASS kanıtı yalnız gerçek artifact/işlem/ortam kaydıyla. EVIDENCE_VERIFIED_PASS_COUNT şu an 0. SKIP ve NOT_RUN PASS değildir. PARTIAL güvenlik VERIFIED değildir.
- **İzleme ölçütleri** (`monitoring` alanı ve STABILITY_MONITORING AC'leri) merge'ü bekletmez; ayrı izlenir.
- **Retry:** aynı fingerprint için 1, ardından BLOCKED_WITH_EVIDENCE.
- **Durma:** USAGE_LIMIT ya da D-08 bütçesi.
- **Founder adına karar verilmez.**

## 3. İlk paralel dalga (S2: D-01 + Grup 1)

- **Slotlar:** V3-T1002, V3-T1001, V3-T1012.a, UASCO-T0016.A, UASCO-T0120, V3-T1003.
- **Slot dışı:** V3-T1006, UASCO-T0115, UASCO-T0103, V4-T0002, UASCO-T0100, V3-T1005, UASCO-T0124, UASCO-T0119.

## 4. Merge sırası

01_* §5 (M0–M7).

## 5. Rapor

V4 §15 biçimi + `EVIDENCE_VERIFIED_PASS_COUNT` + simülasyondan sapma (beklenen ↔ gerçek sıra).

## 6. Çıkış (R1)

05_* §4.
