# 11 — Founder-PC Salt-Okur Ortam Teşhisi (EX-08; D-23, D-03, D-12, D-26 için)

> Bu komutlar **hiçbir ayarı değiştirmez**. Sonucu (metin) Execution oturumuna ya da kararlarınıza girdi olarak verin. Bu oturum komutları çalıştırmadı (NOT_RUN_ENV_UNAVAILABLE).

```powershell
# 1. İşletim sistemi (D-26)
Get-ComputerInfo -Property OsName, OsVersion, OsBuildNumber, WindowsVersion
# 2. Sanallaştırma (D-03)
(Get-CimInstance Win32_Processor).VirtualizationFirmwareEnabled
Get-CimInstance Win32_ComputerSystem | Select-Object HypervisorPresent
# 3. WSL (D-03)
wsl --status
wsl -l -v
# 4. Dağıtım içi araçlar (salt-okur; <ad> = dağıtım)
wsl -d <ad> -- sh -c 'command -v node && node -v; command -v perl; command -v unshare nsenter setpriv; cat /etc/wsl.conf 2>/dev/null'
# 5. Windows host araçları (kabul kiti için Node 24+, git)
node -v; git --version
# 6. Claude Code (native claude.exe; npm .cmd shim desteklenmez)
Get-Command claude -All | Select-Object Source
# 7. Güvenlik araçları (D-19)
Get-Command gitleaks, trivy -ErrorAction SilentlyContinue | Select-Object Source, Version
# 8. Yerel otomasyon (D-12)
Get-ScheduledTask | Where-Object { $_.TaskName -like 'UASCO*' } | Select-Object TaskName, State
Get-CimInstance Win32_Process -Filter "Name='node.exe' OR Name='claude.exe'" | Select-Object ProcessId, CommandLine
# 9. Disk
Get-PSDrive -PSProvider FileSystem | Select-Object Name, Free
```

## Yorumlama

| Bulgu | Etkilediği karar | Not |
| --- | --- | --- |
| OsBuildNumber < 19041 | D-26, D-03 | WSL2 kullanılamaz. Windows 11 yükseltmesi dayatılmaz; D-26 seçenekleri değerlendirilir |
| Sanallaştırma kapalı | D-03 | BIOS/UEFI ayarı Founder kararıdır |
| `wsl -l -v` boş ya da sürüm 1 | D-03 | Ayrı UASCO dağıtımı önerisi (interop=false, appendWindowsPath=false; diğer WSL kullanımını etkilemez) |
| Dağıtımda node < 24 ya da perl yok | D-03 | Kurulum Founder tarafından |
| `claude` yalnız `.cmd` | D-29 / T0003 | Native kurulum gerekir |
| UASCO* görevi Ready/Running | D-12 | Durdurulana kadar Execution 1 slot |
| Kit ön koşulu: Node 24+, `npm ci` yapılmış repo | D-23 | Founder kurulumu |

Windows 10 + WSL2 kabul matrisi doğrulanmadı (UNVERIFIED). Kabul kiti Windows 11 ile tasarlandı; Windows 10'da çalışıp çalışmadığı bilinmiyor.
