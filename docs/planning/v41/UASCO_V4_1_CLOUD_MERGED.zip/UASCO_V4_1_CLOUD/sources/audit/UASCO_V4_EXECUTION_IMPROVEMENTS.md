# UASCO V4 — İcra İyileştirmeleri ve Task Düzeyinde Delta Önerileri

> Bu belge yeni bir roadmap değildir. V4'ün dalga, lane ve model yapısı korunur; önerilen değişiklikler yalnız aşağıdaki delta'lardır.
>
> Hiçbiri uygulanmadı. İcra oturumuna yalnız Founder onayıyla ya da mevcut yetki kurallarıyla aktarılabilir. Hiçbir öneri diğer oturumun durdurulmasını gerektirmez.
>
> Etkiler ESTIMATE'tir. Ölçülmüş tasarruf yok. "Token etkisi" göreli bir tahmindir (↓ azalır / ↑ artar).

---

## 1. Task düzeyinde delta önerileri

Format: CURRENT TASK / CURRENT DEPENDENCY / PROBLEM / PROPOSED CHANGE / REASON / VALIDATION.

### X-01 — Dalga atamasını Task'a taşı (G-07)
- **CURRENT TASK:** UASCO-T0115 (V3-F047 → W4); UASCO-T0119, UASCO-T0120, V3-T1005, V3-T1006 (V3-F048 → W2); V3-T1018 (V3-F022 → W2)
- **CURRENT DEPENDENCY:** Dalga, Feature'ın `delivery_wave` alanından miras alınıyor.
- **PROBLEM:** Bu 6 Task R1 kapanış kümesinde, ama W1'den sonraya düşüyor. Ayrıca 4 Feature bağımlılığı tersine kayıyor.
- **PROPOSED CHANGE:**
  - Manifeste `tasks[].wave` alanı eklenir.
  - T0115, T0119, T0120, V3-T1005, V3-T1006 → W0; V3-T1018 → W1.
  - Feature'ın dalgası = en erken AC'sinin dalgası.
  - Feature bağımlılıkları AC düzeyine indirilir: F030-AC1, F011-AC1, F043 ve F045 W1'de kalır.
- **REASON:** Teslim zamanını Task belirler. Feature'ın sonraki AC'leri ileri dalgalarda kalabilir.
- **VALIDATION:** Deterministik script: dalga tersliği 0; R1 kapanış kümesinin 29'u da ≤ W1.

### X-02 — Export düzeltmesinin bağımlılığını düzelt (G-03)
- **CURRENT TASK:** UASCO-T0016
- **CURRENT DEPENDENCY:** UASCO-T0069 (RW-006 korunan yol genişlemesi)
- **PROBLEM:** `main.mjs` zaten korumalı. Düzeltme RW-006'yı değil, yalnız T2 onayını bekliyor. Kök neden belli (`main.mjs:273`).
- **PROPOSED CHANGE:**
  - dependsOn = [D-31].
  - İş tanımı: "Export başarılı yanıtında dosya yolunu sunucudan alma; ana süreçte `runId`'den türet (zaten hesaplanan `expected`). Token sızıntısı koruması aynı kalır."
- **REASON:** Kritik yoldan RW-006 bağımlılığı (4–10 h + reseal) düşer.
- **VALIDATION:** Yeni birim vakası: başarılı export yolu doğrulanır. Installer CI'da kurulu uygulamadan export → sha256 eşleşmesi.

### X-03 — RW-006'yı ikiye böl (G-03, G-04)
- **CURRENT TASK:** UASCO-T0069
- **CURRENT DEPENDENCY:** yok. Kendisi T0016 ve T0031'in öncülü.
- **PROBLEM:** Korunan yolların W1'den önce genişletilmesi, W1'de en çok değişecek dosyaları (`runner.ts`, `execution-gate.ts`, `security-tools.ts`, sandbox sağlayıcıları, `claude-profiles.ts`) T2'ye bağlar. Her W1 PR'ı Founder onayı bekler.
- **PROPOSED CHANGE:**
  - **UASCO-T0069.a** (W1): reseal batch 1 (#251 + #247) + yalnız W1'de değişmeyecek güven sınırı dosyalarının korunması.
  - **UASCO-T0069.b** (W1 sonu): W1 kodu merge edildikten sonra kalan dosyaları korumaya al + reseal.
  - Ana kimlik UASCO-T0069 korunur.
- **REASON:** Güvenlik kapsamı daralmaz, yalnız zamanlaması değişir. W1'de onay darboğazı oluşmaz.
- **VALIDATION:** T0069.b sonrası `protected-paths.json` RW-006 listesinin tamamını kapsar; korumalı dosyaya dokunan negatif test PR'ı reddedilir.

### X-04 — #231 için tek owner ve bağımlılık düzeltmesi (G-04, G-05)
- **CURRENT TASK:** UASCO-T0031 (V4 PK-01: C_ENGINE + D_CI_RELEASE)
- **CURRENT DEPENDENCY:** UASCO-T0069
- **PROBLEM:** `server.ts` B_API'nin alanında. Manifest çakışması üç PR'da var. Bağımlılık, RW-006 genişlemesine değil reseal batch'ine olmalı.
- **PROPOSED CHANGE:**
  - Owner yalnız C_ENGINE. `server.ts` için geçici file-claim; bu süre boyunca B_API `server.ts`'e dokunmaz.
  - dependsOn = [D-03, D-31]. Reseal batch 2 (D-07) merge'den hemen önceki son adımdır.
  - Alt Task **UASCO-T0031.a**: WSL2 hazırlık runbook'u + setup-check'te sandbox self-test reason kodlarının gösterilmesi (G-02).
- **REASON:** Rebase tek elden yapılır; manifest çakışması tek seferde çözülür.
- **VALIDATION:** Linux CI'da sandbox + SBX-GATE negatif testleri yeşil; Founder-PC'de `docs/acceptance/windows/founder-acceptance.mjs` PASS.

### X-05 — W0'ı deterministik ve Founder adımlarına ayır (G-01, G-12)
- **CURRENT TASK:** V4 PK-00 (D_CI_RELEASE + A_UI; Sonnet/Haiku)
- **CURRENT DEPENDENCY:** "Windows ortamı"
- **PROBLEM:** Bulut ajanı Windows'a kurulum yapamaz. Bu işe LLM gerekmez.
- **PROPOSED CHANGE:**
  - **W0-a:** Deterministik script: artifact 13135209964'ü indir → aç → `.exe` adı, boyutu ve sha256 → register'a EV kaydı. Model yok.
  - **W0-b:** Installer workflow'undaki CI smoke sonucu INSTALLER_OK olarak kaydedilir. Job log'undan deterministik okunur.
  - **W0-c:** Founder runbook'u (D-23-A) INSTALLED_ON_WINDOWS kanıtını üretir: açılış, `/v1/health`, ilk ekran, setup-check çıktısı.
  - **W0-d:** Haiku yalnız sonuç özetini yazar.
- **REASON:** W0'ın model maliyeti neredeyse sıfıra iner; kanıt sınıfları birbirine karışmaz.
- **VALIDATION:** Register'da üç ayrı EV kaydı (BUILD_OK, INSTALLER_OK, INSTALLED_ON_WINDOWS); son kayıt yoksa `NOT_RUN_ENV_UNAVAILABLE`.

### X-06 — Bağımsız yeniden üretim ölçütünü düzelt (G-08)
- **CURRENT TASK:** V3-T1012 (+ V3-AC-F057-2, R1-AC6)
- **CURRENT DEPENDENCY:** yok
- **PROBLEM:** Şablonlarda `package-lock.json` yok; `npm ci` başarısız olur.
- **PROPOSED CHANGE:**
  - Yeni alt Task **V3-T1012.a**: şablonlara boş-bağımlılıklı `package-lock.json` ekle (`core/workos/project-templates.ts`) ve teslim kuralını "kilit dosyası zorunlu" yap.
  - Script, kullandığı yöntemi kanıta yazar.
- **REASON:** Araç hatası yüzünden yanlış FAIL alınması önlenir; tedarik zinciri açısından deterministik.
- **VALIDATION:** Linux ve Windows CI'da şablon ZIP'i temiz dizinde `npm ci && npm test` ile PASS.

### X-07 — Lane sahiplik tablosu (G-05, G-06)
- **CURRENT TASK:** V4 §3 lane tablosu; PK-03, PK-04, PK-06, PK-10
- **CURRENT DEPENDENCY:** —
- **PROBLEM:** `store.ts` 3 lane'de, `plan.ts` ve `zip.ts` C'nin alanında ama başka lane'lere verilmiş. W1'de 5 lane aktif.
- **PROPOSED CHANGE:**
  - Manifeste `ownerByPath` eklenir: `core/workos/{store,plan,zip,runner,task-selector}.ts` → C_ENGINE; `apps/control-api/src/**` (server.ts dahil) → B_API, #231 için geçici devirle.
  - D yalnız `.github/**`, `scripts/validate-*`, `installer/**` ve `tests/**` (CI testleri). E builder değildir.
  - W1'de builder'lar A, B, C; D bunlarla sıralı bir kuyrukta zaman paylaşır.
- **REASON:** Rebase, sync-merge ve onarım döngülerini azaltır. Geçmişte 221 + 88 sync merge vardı, PR'ların %46,8'i onarım istedi.
- **VALIDATION:** PR başına "dosya sahibi = PR lane'i" kontrolü 0 ihlal; aktif builder ≤ 3.

### X-08 — Store-lock düzeltmesinde Opus'u atla (PK-10)
- **CURRENT TASK:** V3-T1001 (PK-10: "Opus kök neden, Sonnet kod")
- **CURRENT DEPENDENCY:** —
- **PROBLEM:** Kök neden zaten biliniyor: sıfır baytlık kilit dosyası (TD-V2-06, rapor N ve P) ve #282'nin teşhis kanıtı.
- **PROPOSED CHANGE:** Model Sonnet. Opus yalnız iki Sonnet denemesi başarısız olursa (V4'ün kendi kuralı). Context pack: `store.ts` `withLock` + #282 diff'i + 4 başarısız testin 30 satırlık özeti. Owner C_ENGINE (X-07).
- **REASON:** Gereksiz Opus çağrısı önlenir.
- **VALIDATION:** Deterministik Windows testi + 20 ardışık base push'ta relfx-1:459 ailesinden kırmızı 0.

### X-09 — Claude launcher değişimi senaryosu (G-09)
- **CURRENT TASK:** UASCO-T0061
- **CURRENT DEPENDENCY:** UASCO-T0003
- **PROBLEM:** Otomatik güncelleme sonrası executor NOT_READY olabilir; davranış doğrulanmadı.
- **PROPOSED CHANGE:** Alt Task **UASCO-T0061.a**: launcher hash'inin değiştiği birim testi + Desktop'ta tek tıkla yeniden doğrulama akışı + yarıda kalan run için BLOCKED_RESUMABLE (V3-T1016'ya bağlı). Pin politikası D-29.
- **REASON:** W1'in "3 ardışık run" kabulü korunur.
- **VALIDATION:** Birim testi; Founder-PC'de bir güncelleme sonrası kayıt.

### X-10 — Kota korumasını W0'a çek (G-10)
- **CURRENT TASK:** UASCO-T0110 (V3-F046 → W1)
- **CURRENT DEPENDENCY:** UASCO-T0115
- **PROBLEM:** V4'ün %80/%95 eşiklerini ölçecek bir bileşen yok.
- **PROPOSED CHANGE:**
  - W0'a alınır; yüzde yerine D-08 bütçesi + gözlenen `rate_limit` / USAGE_LIMIT olayları kullanılır.
  - T0115 bağımlılığı yumuşatılır: gözlem sonucu girdi olarak kullanılır, ama koruma işini beklemez.
- **REASON:** Geçmişte kota, takvimin %55'ini kaybettirdi.
- **VALIDATION:** USAGE_LIMIT simülasyonunda pause kaydı oluşur, yeni builder başlamaz.

### X-11 — RunAsNode fuse AC'sini düzelt (G-11; V3.1'in kendi hatası)
- **CURRENT TASK:** UASCO-T0023 (V3-AC-F009-2)
- **CURRENT DEPENDENCY:** —
- **PROBLEM:** Paketli backend `ELECTRON_RUN_AS_NODE` ile çalışıyor. Fuse kapatılırsa uygulama açılmaz.
- **PROPOSED CHANGE:** Ön alt Task **UASCO-T0023.a**: backend'i `utilityProcess`'e taşıma tasarımı ve uygulaması (D-27). Gerçekleşmezse AC "RunAsNode açık, NodeOptions kapalı, asar integrity açık" olarak düzeltilir. W4'te kalır.
- **REASON:** W4'teki kırılmanın önceden fark edilmesi.
- **VALIDATION:** Fuse'lar uygulanmış installer'da backend HEALTHY.

### X-12 — Reconcile adımını deterministik yap (G-15)
- **CURRENT TASK:** V4 §10-A RECONCILE; PK-14
- **CURRENT DEPENDENCY:** Kaynak JSON'lar
- **PROBLEM:** V4, 164 Task / 102 AC doğrulamasını ilk adımda yeniden yapıyor ve Haiku/Sonnet kullanabiliyor.
- **PROPOSED CHANGE:** D-24-A sonrası yalnız deterministik script: hash kontrolü + 57/164/102 sayımı + döngü/orphan kontrolü. Bu denetimin sonucu girdi olarak verilir: 57/57, 29/29 seed eşleşmesi, döngü 0.
- **REASON:** Aynı doğrulamanın LLM ile tekrarlanması önlenir.
- **VALIDATION:** Script çıktısı register'da; LLM çağrısı 0.

### X-13 — Tek review yolu (G-14)
- **CURRENT TASK:** V4 §4 "Bağımsız review: taze Sonnet/Opus"; V3-T1034
- **CURRENT DEPENDENCY:** IR workflow
- **PROBLEM:** IR check her PR'da FAIL üretiyor; alt ajan review'u ayrıca yapılıyor.
- **PROPOSED CHANGE:**
  - Model, risk tier'ına göre seçilir: T0 docs → deterministik kontrol + Haiku özeti; T1 → taze Sonnet; T2/güvenlik/sandbox/lease → taze Opus.
  - Review sonucu patch-id ile cache'lenir; base-merge sonrası diff aynıysa yeniden review yapılmaz (ledger'daki BASE_MERGE_ONLY mantığı).
  - IR yeniden koşturulmaz (D-21).
- **REASON:** Çift maliyet ve sahte kırmızı check ortadan kalkar.
- **VALIDATION:** PR başına 1 review kaydı; aynı patch-id için ikinci review 0.

### X-14 — Dalga başına `.exe`'yi ajanlar üretmesin
- **CURRENT TASK:** V4 §10-G PACKAGE; directive "güncel .exe üret"
- **CURRENT DEPENDENCY:** —
- **PROBLEM:** Installer workflow'u her base push'ta `.exe`'yi zaten üretiyor. Ajanın bunu yeniden üretmesi ya da yeniden doğrulaması tekrar olur.
- **PROPOSED CHANGE:** PACKAGE adımı yalnız deterministik toplama yapar: son yeşil installer run'ının artifact'ı + SHA (X-05). Ajan ancak workflow kırmızıysa devreye girer.
- **REASON:** Token ve runner dakikası tasarrufu.
- **VALIDATION:** Dalga raporunda installer run kimliği ve SHA var; ajan çağrısı 0.

### X-15 — #247'yi kritik yoldan çıkar (G-17)
- **CURRENT TASK:** V4 §6 "#247 16,8 GB geçici dosya sızıntısı öncelik"
- **CURRENT DEPENDENCY:** reseal
- **PROBLEM:** #247 yalnız selftest scripti ve testini değiştiriyor; `.exe` ürününü etkilemiyor.
- **PROPOSED CHANGE:** D-07 batch 1'de kalır, ama W0/W1 kabulünü beklemez ve beklenmez.
- **REASON:** Önceliği gerçek etkisine göre ayarlamak.
- **VALIDATION:** —

### X-16 — Pre-dev ve Epic/Feature/Task şemasında tek seferlik Opus
- **CURRENT TASK:** V4 PK-06 (Sonnet); V3-T1022
- **CURRENT DEPENDENCY:** UASCO-T0026
- **PROBLEM:** Epic → Feature → Task → AC şeması, W3'teki görev DAG'ının temeli. Şema hatası W3'te pahalı bir yeniden yazıma yol açar.
- **PROPOSED CHANGE:** Şema ve idempotency anahtarı için tek seferlik Opus tasarımı (≤ 1 sayfa); uygulamayı Sonnet yapar.
- **REASON:** V4'ün "Opus yalnız zor mimari için" kuralıyla uyumlu.
- **VALIDATION:** Şema testleri; W3 DAG yürütücüsü şemayı değiştirmeden kullanır.

## 2. Model ve lane ataması değişiklikleri

Her satırda üç etki tahmin edilmiştir: hız, token/maliyet ve kalite/güvenlik.

| Konu | V4'te | Öneri | Hız etkisi | Token/maliyet etkisi | Kalite/güvenlik etkisi |
| --- | --- | --- | --- | --- | --- |
| PK-00 W0 | Sonnet/Haiku | Deterministik + Founder; özette Haiku (X-05) | ↑ (bekleme yok) | ↓ (neredeyse sıfır) | ↑ kanıt sınıfları ayrı kalır |
| PK-10 store-lock | Opus kök neden + Sonnet | Önce Sonnet; Opus yalnız iki başarısız denemeden sonra (X-08) | ↑ | ↓ (bir Opus turu atlanır) | = (kök neden zaten kanıtlı) |
| PK-04 export düzeltmesi | Sonnet | Sonnet kalır; Haiku'ya **verilmemeli**. Review Opus, çünkü T2 ve token-scrub güvenliği söz konusu | = | = / küçük ↑ (Opus review) | ↑ |
| PK-05 tasarım sistemi | Sonnet; mekanik stil Haiku | Karar D-25'ten sonra; yalnız token katmanında Sonnet, snapshot güncellemesinde Haiku | ↑ (kapsam küçülür) | ↓ | = |
| PK-06 şema | Sonnet | Tek seferlik Opus tasarımı + Sonnet (X-16) | = | küçük ↑ | ↑ (W3'te yeniden yazım riski düşer) |
| PK-14 / reconcile | Deterministik + Haiku + Sonnet | Yalnız deterministik (X-12) | ↑ | ↓ | ↑ (tekrar üretim yok) |
| Review | Taze Sonnet/Opus | Tier'a göre: T0 Haiku, T1 Sonnet, T2/güvenlik Opus; patch-id cache (X-13) | ↑ | ↓ | = / ↑ |
| W1 lane sayısı | A, B, C, D (+E) | 3 builder (A, B, C); D sıralı kuyruk; E deterministik (X-07) | ↑ (daha az çakışma) | ↓ | ↑ |
| Haiku işleri | Kaynak keşfi, changelog, test kırpma, küçük mekanik edit, kolay unit test | Uygun. **İstisna:** korumalı ya da güvenlik dosyalarında (`main.mjs`, `preload.mjs`, `execution-gate.ts`, `security-tools.ts`, sandbox) mekanik bile olsa Haiku kullanılmaz | = | = | ↑ |
| Opus işleri | #231/WSL2, lease, trust root, CI kök nedeni | Uygun; #231'de Opus yalnız analiz + review, rebase Sonnet'te (G-04) | ↑ | ↓ | = |

Model erişimi notu: Bu denetim oturumunun Agent aracı haiku/sonnet/opus seçimine izin veriyor (VERIFIED). İcra oturumu kendi hesabında `/model` ile doğrulamalı (V4 kuralı doğru). Kullanıcı tercihlerinde geçen `cheap-explorer`, `routine-engineer` ve `senior-architect` ajan tipleri bu ortamda tanımlı değil. V4 bunlara bağımlı değil; bunlara dayanan bir yönlendirme kurulmamalı.

## 3. Karar beklemeden hemen kodlanabilecek bağımsız işler

**(a) Kodlanabilir ve T2 gerektirmeden merge edilebilir** (korumasız dosyalar, VERIFIED):

| Task | İş | Owner | Model | Dosya |
| --- | --- | --- | --- | --- |
| V3-T1001 | Sıfır baytlık store-lock kurtarma | C_ENGINE | Sonnet | `core/workos/store.ts` |
| V3-T1012 + V3-T1012.a | Yeniden üretim script'i + şablon kilit dosyası | B_API / C_ENGINE | Haiku | `core/workos/project-templates.ts`, yeni script |
| V3-T1011 | Üç bağımsız kabulden teslim etiketi | B_API | Sonnet | delivery modülü (`core/workos`, korumasız) |
| V3-T1014 / V3-T1015 / V3-T1016 | ProviderPort, kullanım yakalama, kota olay modeli | C_ENGINE | Sonnet | `executors.ts` ve ilgili dosyalar |
| V3-T1017 | Golden eval v0 harness (kod; gerçek koşu Founder-PC'de) | C_ENGINE | Sonnet | `tests/eval/**` |
| UASCO-T0006 | 10 fake-bridge route için gerçek sunucu testleri | A_UI | Sonnet | `tests/**` |
| UASCO-T0003 / T0061.a | Claude CLI keşfi ve launcher değişimi senaryosu | C_ENGINE | Sonnet | `core/workos/claude-profiles.ts` |
| UASCO-T0110 | Minimal kota koruması | E_CONTROL | Sonnet | `automation/**` dışında bir supervisor dosyası. **Not:** `automation/lib/` korumalı; dosya yeri seçilirken buna dikkat edilmeli |
| V3-T1005 / V3-T1006 / UASCO-T0124 | Register + LEGACY_BASELINE + kanıt digest'i | E_CONTROL | deterministik | register dalı (CI'sız) |
| UASCO-T0031.a (UI kısmı) | Setup-check'te sandbox self-test reason kodları | A_UI | Sonnet | `apps/desktop/renderer/views/setup-check.js` |

**(b) Kod ve PR hazırlanabilir; merge T2 onayı (D-31) bekler:**

| Task | Korumalı dosya |
| --- | --- |
| UASCO-T0016 (export düzeltmesi) | `main.mjs` |
| UASCO-T0031 (#231 rebase) | `server.ts`, manifest |
| V3-T1002 / V3-T1003 / V3-T1036 | `scripts/validate-shards.mjs`, `ci.yml` |
| UASCO-T0069.a | `config/*` |

**(c) Founder ortamı ya da kararı olmadan tamamlanamaz:** W0-c, FA-5, R1 demo koşuları (D-23), SEC-PROFILE-R1 araç kurulumu (D-19).

## 4. Ek token harcamasını azaltacak en değerli beş iyileştirme

| # | İyileştirme | Hız | Token/maliyet (ESTIMATE, ölçülmedi) | Kalite/güvenlik |
| --- | --- | --- | --- | --- |
| 1 | **V3.1 kayıtlarını icraya ver ve reconcile'ı deterministik yap** (D-24, X-12) | ↑ İlk tur hemen Task seçimine geçer | ↓ 164 Task'ın LLM ile yeniden üretilmesi ya da doğrulanması önlenir | ↑ Uydurma Task riski düşer |
| 2 | **Dosya sahipliği tablosu + en fazla 3 builder** (X-07) | ↑ Çakışma beklemesi azalır | ↓ Sync-merge, onarım ve yeniden review turları azalır (geçmişte %46,8 onarım, 309 sync merge) | ↑ |
| 3 | **Tek review yolu + patch-id cache** (X-13) | ↑ | ↓ Çift review ve IR yeniden koşuları kalkar; base-merge'lerde review tekrarlanmaz | = |
| 4 | **W0 ve PACKAGE adımlarını deterministik yap** (X-05, X-14) | ↑ | ↓ Her dalga sonunda ajanla yapılan paketleme/doğrulama turu kalkar | ↑ Kanıt sınıfları ayrışır |
| 5 | **CI tasarrufu:** draft PR'da yalnız L0; Windows shard'ları yalnız Windows'a duyarlı yollarda; post-merge push CI yalnız ağaç farklıysa (V3.1 §7.1, RW-061) | ↑ PR geri bildirimi hızlanır | ↓ Runner-dk (geçmişte %28 başarısız/iptal, %19,7 post-merge) ve CI log'u okuma token'ı | = (kapsam L2 ve L3'te korunur) |

Ayrıca: Bilinen kök nedenlerde Opus atlanmalı (X-08). Ajan sonuçları V4'ün kısa çıktı şemasıyla dönmeli: `{changedFiles, tests, evidence, remainingBlocker, tokensUsed}`. V4'teki bu kural doğru; uygulanması denetlenmeli.

## 5. Önerilen yürütme sırası (V4 dalgaları korunarak)

1. **Hemen (karar beklemeden):** §3(a) işleri + X-05 W0-a/W0-b + X-12.
2. **D-23, D-31, D-03, D-07, D-12, D-24 alındıktan sonra:** W0-c (Founder), reseal batch 1, #231 rebase'in tamamlanması, export merge'ü.
3. **W1:** A (export, setup-check), B (pre-dev gerçek model, etiketler, yeniden üretim), C (#231, runner, provider/kota). D, CI provenance için sıralı kuyrukta.
4. **W1 kabulü:** Founder-PC'de 3 ardışık run (D-29-B: güncelleme kapalı), SEC-PROFILE-R1 (D-19).
5. **W1 sonu:** UASCO-T0069.b (korumanın genişletilmesi + reseal).
6. W2–W5 V4'teki gibi; X-11, X-16 ve D-25..D-28 kendi dalgalarında.
