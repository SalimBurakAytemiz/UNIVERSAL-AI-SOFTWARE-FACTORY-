# UASCO V4 — Eksiklik ve Risk Kaydı

Durum: AUDIT, öneri niteliğinde. Hiçbir düzeltme uygulanmadı.

Kimlikler: `G-##`. Task kimlikleri V3.1'dekiyle aynı (`UASCO-T####`, `V3-T1###`). Bölünecek Task'larda ana kimlik korunur ve alt kimlik `.a/.b` biçiminde türetilir.

Kanıt etiketleri: VERIFIED · CLAIMED · UNKNOWN.

**Özet:** CRITICAL 1 · HIGH 9 · MEDIUM 9 · LOW 2 = 21 bulgu.

Ürün teslimini bloke edenler (CRITICAL + HIGH): G-01 … G-10.

---

## CRITICAL

### G-01 — Gerçek Windows kurulum ve E2E kabulünün yürütücüsü tanımsız
- **Önem:** CRITICAL
- **İlgili kayıtlar:** V3-E1, V3-E3, V3-E4 · V3-F001, F004, F012, F013, F015, F057 · UASCO-T0002, T0014, T0029, T0031 (FA-5), T0035, T0044, V3-T1018, V3-T1019 · V4 PK-00, W0, W1
- **Etkilenen:** W0/W1 kabul kanıtları; INSTALLED_ON_WINDOWS ve sonraki bütün aşamalar
- **Kanıt:** V4 PK-00 "kur, kaldır, ilk açılış… test et" işini D_CI_RELEASE ve A_UI lane'lerine (Sonnet/Haiku) veriyor. İcra oturumu bulut container'ında çalışıyor (Linux) ve Windows'a kurulum yapamaz. V4 §11 yalnız Windows sürümünü ve WSL2'yi soruyor, testi kimin yapacağını sormuyor. Windows Installer workflow'u CI runner'da sessiz kurulum yapıyor; bu INSTALLER_OK'tur, INSTALLED_ON_WINDOWS değildir (VERIFIED: run 41434581581).
- **Ortaya çıkma koşulu:** W0 başlar başlamaz.
- **Etki:** Bütün ürün kabul aşamaları NOT_RUN kalır. Lane'ler ya bekler ya da CI smoke'unu yanlışlıkla kurulum kabulü sayar.
- **Çözüm:** D-23 ile yürütücü seçilir. Seçenekler: (a) Founder runbook'u (#231'deki `docs/acceptance/windows/founder-acceptance.mjs` ve V3-T1019 kontrol listesi) ve sonuç dosyasının register'a yüklenmesi; (b) Founder-PC'deki klasörü Remote Control ile oturuma bağlamak; (c) ara çözüm olarak `windows-latest` runner'da ek E2E (yalnız INSTALLER_OK ile UI_API kanıtı üretir, Founder kabulünün yerine geçmez).
- **Model:** deterministik script + Haiku (sonuç özeti)
- **Owner:** Founder + D_CI_RELEASE
- **Bağımlılık:** D-23
- **Founder kararı:** EVET (D-23)
- **Diğer kodlama devam eder mi:** EVET; yalnız kabul kanıtı bekler.
- **Doğrulama testi:** Founder-PC'den gelen imzalı/hash'li kabul JSON'u (installer SHA, OS sürümü, açılış, `/v1/health`, ilk ekran) register'da V3-EV-F001-1 olarak kayıtlı.
- **Lane güvenlik uyarısı (D_CI_RELEASE, A_UI):** CI runner smoke'unu INSTALLED_ON_WINDOWS ya da FOUNDER_ACCEPTED olarak raporlamayın. Ortam yoksa `NOT_RUN_ENV_UNAVAILABLE` yazın.

## HIGH

### G-02 — WSL2 sandbox'ın kullanıcı tarafı ön koşulları için Task yok
- **Önem:** HIGH
- **İlgili kayıtlar:** V3-F013, V3-F001 · UASCO-T0031, V3-T1019 · PK-01
- **Etkilenen:** #231 `core/sandbox/wsl-unshare-sandbox.ts`; Desktop setup-check görünümü (`renderer/views/setup-check.js`)
- **Kanıt:** Sağlayıcı şunları istiyor: WSL2 dağıtımı (`UASCO_WSL_DISTRO` ya da `wsl -l -v` ile keşif), dağıtım içinde `node` ve `perl`, ayrıca `unshare`/`nsenter`/`setpriv`. Eksik olanlar `WSL_DISTRO_NOT_CONFIGURED`, `WSL_VERSION_NOT_2` ve `PROBE_*` reason kodlarıyla bildiriliyor (VERIFIED, kod). V4 ve V3.1'de bu hazırlığı yapan ya da tanılayan bir Task yok; V3.1 yalnız CAND-05'i R2 adayı olarak not etmişti.
- **Koşul:** Founder-PC'de dağıtım ya da dağıtım içindeki node eksikse.
- **Etki:** W1'deki sandbox çalıştırması `SANDBOX_UNAVAILABLE` ile durur; ikinci kullanıcı (W2/W4) kurulumu tamamlayamaz.
- **Çözüm:** UASCO-T0031'e alt Task: **UASCO-T0031.a** "WSL2 hazırlık runbook'u + Desktop setup-check'te sandbox self-test sonucunu göster". Kod değişikliği, mevcut self-test reason kodlarını göstermekle sınırlı. Otomatik dağıtım kurulumu W4'e (V3-F001, CAND-05) bırakılır.
- **Model:** Sonnet (UI bağlama); runbook için Haiku
- **Owner:** A_UI (setup-check), C_ENGINE (reason kodları)
- **Bağımlılık:** UASCO-T0031
- **Founder kararı:** HAYIR (D-03 doğrulaması bunu kullanır)
- **Devam:** EVET
- **Doğrulama:** Dağıtımsız ortamda setup-check `WSL_DISTRO_NOT_CONFIGURED` gösterir (renderer→real-server testi); Founder-PC'de self-test PASS.

### G-03 — Export düzeltmesinin bağımlılığı yanlış tanımlanmış; kök neden belli
- **Önem:** HIGH
- **İlgili kayıtlar:** V3-F005 · UASCO-T0016 (dependsOn: UASCO-T0069) · PK-04
- **Etkilenen:** `apps/desktop/main.mjs:266-273, 240-249, 310-312` (korumalı)
- **Kanıt:** `sanitizePostBody()` başarılı yanıttaki bütün string'lere `scrubText` uyguluyor; mutlak yol `[path]` olur ve `deliveryExportCheck()` → `realpathSync(body.path)` başarısız olur (VERIFIED, statik okuma). `main.mjs` zaten korumalı (exactPaths). Yani düzeltmenin önündeki engel RW-006'nın kapsam genişlemesi değil, mevcut T2 onayı.
- **Koşul:** Desktop'ta "Export delivery package" düğmesine her basıldığında.
- **Etki:** DELIVERY_ACCEPTED imkânsız. Kritik yol, RW-006'ya bağlı olduğu için gereksiz yere uzuyor.
- **Çözüm:** UASCO-T0016'nın bağımlılığı `UASCO-T0069` yerine `D-31` (T2 onay batch'i) yapılır. Kod tarafında export yanıtındaki `path` alanı scrub'dan muaf tutulur, ya da daha güvenlisi path sunucudan hiç alınmaz ve ana süreçte `runId`'den türetilir (fonksiyon `expected` yolunu zaten hesaplıyor). Token sızıntısı koruması değişmez.
- **Model:** Sonnet (güvenlik açısından hassas, Haiku değil); review Opus (T2)
- **Owner:** A_UI
- **Bağımlılık:** D-31
- **Founder kararı:** EVET (T2 merge onayı)
- **Devam:** EVET; kod ve PR hazırlanabilir, yalnız merge T2'yi bekler.
- **Doğrulama:** Mevcut `delivery` testine "başarılı export yolu doğrulanır" vakası; installer CI'da kurulu uygulamadan export → sha256 eşleşmesi (RW-009 ölçütü).

### G-04 — #231 entegrasyon riski: 173 commit geride, korumalı dosyaya dokunuyor, owner çakışıyor
- **Önem:** HIGH
- **İlgili kayıtlar:** V3-F013 · UASCO-T0031 · PK-01
- **Etkilenen:** #231'in 42 dosyası; içlerinde `apps/control-api/src/server.ts` (korumalı), `config/trust-root-manifest.json` (korumalı), 20'yi aşkın test dosyası
- **Kanıt:** merge-base'den 16d3a925'e 173 commit var (VERIFIED). `server.ts` V4'te B_API lane'ine ait, PK-01 ise C_ENGINE + D'ye verilmiş. #231, #251 ve #247 aynı manifest dosyasında çakışıyor (rapor M.5).
- **Koşul:** Rebase ve reseal sırasında.
- **Etki:** Kritik yolun en uzun halkası (40–120 h, ESTIMATE). Yanlış çözülen bir çakışma sandbox güvenliğini zayıflatabilir.
- **Çözüm:** Rebase'i tek owner (C_ENGINE) yapar. `server.ts`'teki 3 satırlık seçici değişikliği C_ENGINE'e geçici file-claim ile verilir; B_API bu süre boyunca `server.ts`'e dokunmaz. Reseal ayrı ve son adımdır (D-07 batch 2). Opus yalnız tek seferlik çakışma/tehdit analizi ve review için kullanılır; rebase'i Sonnet uygular.
- **Model:** Opus (analiz + review) / Sonnet (rebase)
- **Owner:** C_ENGINE
- **Bağımlılık:** D-03, D-07, D-31
- **Founder kararı:** EVET (T2)
- **Devam:** EVET
- **Doğrulama:** Linux CI'da sandbox testleri yeşil; `v7-int-r3-sbx-gate` negatif testleri; Founder-PC'de `founder-acceptance.mjs` PASS.

### G-05 — Lane dosya sahipliği çakışıyor
- **Önem:** HIGH
- **İlgili kayıtlar:** PK-03, PK-04, PK-06, PK-10; V4 §3 lane tablosu
- **Etkilenen:**
  - `core/workos/store.ts`: C_ENGINE (lane sınırı), D_CI_RELEASE (PK-10) ve B_API (PK-06) talip.
  - `core/workos/plan.ts`: C'nin alanında, PK-06'da B'ye verilmiş.
  - `core/workos/zip.ts`: C'nin alanında, PK-04'te A'ya verilmiş.
  - `apps/control-api/src/server.ts`: B'ye ait, ama PK-01'de (#231) değişiyor.
- **Kanıt:** V4 §3 ile §7 karşılaştırması (VERIFIED, belge).
- **Koşul:** W1 ve W2 aynı anda yürüdüğünde.
- **Etki:** Rebase çatışmaları ve tekrar review'lar. Geçmişte PR'ların %46,8'i en az bir onarım turu istedi (rapor J.2).
- **Çözüm:**
  - `store.ts`, `plan.ts`, `zip.ts` → tek owner C_ENGINE. D yalnız `tests/**` altında test yazar; B ve A ihtiyaçlarını C'ye API sözleşmesi olarak iletir.
  - `server.ts` → tek owner B_API; #231 için kısa süreli devir.
  - Manifest'e yol bazında `ownerByPath` tablosu eklenir.
- **Model:** deterministik (sahiplik tablosu)
- **Owner:** E_CONTROL
- **Bağımlılık:** yok
- **Founder kararı:** HAYIR
- **Devam:** EVET
- **Doğrulama:** Her PR'da "dosya sahibi ≠ PR lane'i" kontrolü 0 ihlal.

### G-06 — W1'de 5 lane aktif; V4'ün kendi 3-builder kuralıyla çelişiyor
- **Önem:** HIGH
- **İlgili kayıtlar:** V4 §3, §5, manifest `concurrency.max_parallel_builders=3`
- **Etkilenen:** W1'de 20 Feature: A 2, B 4, C 4, D 7, E 3 (VERIFIED, manifest sayımı)
- **Kanıt:** Directive "3 file-disjoint builder" diyor; W1 sırası ise A, B, C ve D'yi birlikte sayıyor; E'nin W1'de 3 Feature'ı var.
- **Koşul:** W1 başladığında.
- **Etki:** Kota hızla tükenir, çakışma artar, D'nin 7 Feature'ı darboğaz olur.
- **Çözüm:** W1'de builder'lar A, B, C. D yalnız sıralı bir kuyrukla çalışır (V3-T1001 → V3-T1002 → V3-T1003 → V3-T1036; ardından CI olaylarına göre) ve B ile zaman paylaşır. B'nin gerçek-model işleri (PK-02) Founder-PC'ye bağlı olduğu için W0 sırasında D önce çalışabilir. E builder değildir: deterministik script ve olay tetikli çalışır.
- **Model:** —
- **Owner:** Supervisor
- **Bağımlılık:** G-05
- **Founder kararı:** HAYIR
- **Devam:** EVET
- **Doğrulama:** Aktif builder sayısı ≤ 3 (session listesinden günlük ölçüm).

### G-07 — Dalgalar Feature bazında atanmış; R1-kritik Task'lar geç dalgalara düşüyor
- **Önem:** HIGH
- **İlgili kayıtlar:**
  - UASCO-T0115 (V3-F047 → W4)
  - UASCO-T0119, UASCO-T0120, V3-T1005, V3-T1006 (V3-F048 → W2)
  - V3-T1018 (V3-F022 → W2)
  - Feature bağımlılık terslikleri: V3-F030(W1) ← V3-F056(W2); V3-F043(W1) ← V3-F048(W2); V3-F045(W1) ← V3-F048(W2); V3-F011(W1) ← V3-F055(W2)
- **Kanıt:** V4 manifesti ile V3.1 Task matrisinin script karşılaştırması (VERIFIED).
- **Koşul:** İcra motoru dalga sırasını Feature üzerinden uyguladığında.
- **Etki:** Kayıt doğrulaması (ileriye dönük izlenebilirlik), rutin gözlemi ve negatif STOP/kota testleri W1 kabulünden önce yapılmaz. W1 ya eksik kanıtla geçer ya da gecikir.
- **Çözüm:** Dalga Task'a atanır ve Feature'ın dalgası "en erken AC'sinin dalgası" olur. Bu 6 Task W0/W1'e alınır. Feature bağımlılıkları AC düzeyine indirilir: F030-AC1 F056'yı beklemez; F011-AC1 F055'i beklemez.
- **Model:** deterministik (yeniden sıralama scripti)
- **Owner:** E_CONTROL
- **Bağımlılık:** yok
- **Founder kararı:** HAYIR
- **Devam:** EVET
- **Doğrulama:** Script: `dalga(Task) ≥ dalga(öncül)` ihlali 0; R1 kapanış kümesinin 29'u da ≤ W1.

### G-08 — Bağımsız yeniden üretim ölçütü (`npm ci`) şablonlarda başarısız olur
- **Önem:** HIGH
- **İlgili kayıtlar:** V3-F057 · V3-T1012, V3-AC-F057-2, R1-AC6 · PK-04
- **Etkilenen:** `core/workos/project-templates.ts`; teslim ZIP'i
- **Kanıt:** Şablonlarda `package.json` var ama `package-lock.json` yok (VERIFIED). `npm ci` kilit dosyası olmadan çalışmaz. Bu davranış npm'in genel bilgisine dayanır; bu denetimde çalıştırılmadı.
- **Koşul:** İmplementer kilit dosyası üretmediğinde (ağ izolasyonlu sandbox'ta bu olası).
- **Etki:** Ürün doğru çalışsa bile R1 kabulü araç hatası yüzünden FAIL olur. Bu V3.1'in kendi hatası.
- **Çözüm:** İki seçenek: (a) şablonlara boş-bağımlılıklı `package-lock.json` eklemek ve teslim kuralını "kilit dosyası zorunlu" yapmak; (b) yeniden üretim script'inde kilit dosyası varsa `npm ci`, yoksa `npm install --ignore-scripts --no-audit`, sonra `npm test`, ve kullanılan yöntemi kanıta yazmak. Öneri: (a). Deterministik ve tedarik zinciri açısından daha güvenli.
- **Model:** Haiku (şablon + test)
- **Owner:** C_ENGINE (şablon), B_API (script)
- **Bağımlılık:** yok
- **Founder kararı:** HAYIR
- **Devam:** EVET
- **Doğrulama:** Temiz dizinde şablon ZIP'i ile `npm ci && npm test` PASS (Linux CI + Windows).

### G-09 — Claude CLI launcher hash pin'i ile otomatik güncelleme çatışabilir (doğrulanmadı)
- **Önem:** HIGH (UNVERIFIED)
- **İlgili kayıtlar:** V3-F025 · UASCO-T0003, UASCO-T0061 · PK-02, PK-03
- **Etkilenen:** `core/workos/claude-profiles.ts:214-245` (`claudeLauncherCheck`)
- **Kanıt:** Launcher sha256 değeri provenance dosyasına pinleniyor; içerik değişirse `CLAUDE_LAUNCHER_PROVENANCE_CHANGED`, dosya yoksa `CLAUDE_CLI_NOT_FOUND` dönüyor (VERIFIED, kod). Native Claude Code'un kendini güncelleyip güncellemediği ve launcher dosyasının değişip değişmediği UNKNOWN.
- **Koşul:** Founder-PC'de Claude Code güncellendiğinde (3 ardışık run sırasında ya da uzun çalışmada).
- **Etki:** Executor NOT_READY olur, run'lar BLOCKED kalır, W1'deki "3 ardışık run" kesilir.
- **Çözüm:** **UASCO-T0061.a** "launcher değişimi senaryosu": testte launcher içeriğini değiştir → net Founder aksiyonu (tek tık yeniden doğrulama) ve yarıda kalan run için BLOCKED_RESUMABLE (V3-T1016). Founder-PC'de bir güncelleme döngüsü gözlenir. Pin politikası D-29 ile belirlenir.
- **Model:** Sonnet
- **Owner:** C_ENGINE
- **Bağımlılık:** V3-T1016
- **Founder kararı:** EVET (D-29: güvenlik politikası)
- **Devam:** EVET
- **Doğrulama:** Birim testi + Founder-PC'de 1 güncelleme sonrası yeniden doğrulama kaydı.

### G-10 — Kota/kullanım ölçümü yok; V4'ün %80/%95 eşikleri uygulanamaz
- **Önem:** HIGH
- **İlgili kayıtlar:** V3-F046 · UASCO-T0110, UASCO-T0111 · V4 §4 "maliyet sınırı"
- **Etkilenen:** İcra oturumu ve lane oturumları
- **Kanıt:** V4 "%80'de uyarı, %95'te yeni iş açma" diyor, ama ölçen bir bileşen yok (V3-F046 MISSING). Geçmişte takvimin %55,2'si kota yüzünden sıfır commit ile geçti (rapor A.5, VERIFIED-rapor). Bulut oturumunda kalan kotanın programatik olarak okunabildiği UNKNOWN.
- **Koşul:** Haftalık limite yaklaşıldığında.
- **Etki:** W1'in ardışık run'ları ve paralel lane'ler aynı anda durur; yeniden başlarken tick'ler birikir.
- **Çözüm:** UASCO-T0110 W0'a alınır (USAGE_LIMIT algılama → global pause kaydı, rutin başına ≤1 bekleyen tick). Yüzde eşikleri yerine Founder'ın verdiği haftalık oturum/saat bütçesi (D-08) ve gözlenen `rate_limit` olayları kullanılır.
- **Model:** Sonnet (algılama), deterministik (kayıt)
- **Owner:** E_CONTROL
- **Bağımlılık:** D-08
- **Founder kararı:** EVET (D-08)
- **Devam:** EVET
- **Doğrulama:** USAGE_LIMIT simülasyonunda pause kaydı oluşur ve yeni builder başlatılmaz.

## MEDIUM

| ID | Başlık | İlgili kayıtlar | Kanıt | Koşul / etki | Çözüm | Model | Owner | Bağımlılık | Founder? | Devam? | Doğrulama |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G-11 | V3-AC-F009-2 "RunAsNode fuse off" paketli backend'i bozar (V3.1 hatası) | V3-F009, UASCO-T0023, PK-11 | `main.mjs:29` `ELECTRON_RUN_AS_NODE:"1"`; `docs/installer/README.md:136` "RunAsNode fuse stays enabled (required)" (VERIFIED) | W4 sertleştirmesinde fuse kapatılırsa backend açılmaz | UASCO-T0023'e ön Task **UASCO-T0023.a**: backend'i Electron `utilityProcess`'e taşı (ya da ayrı imzalı Node binary), sonra fuse'u kapat. Aksi hâlde AC "RunAsNode açık + NodeOptions kapalı + asar integrity" olarak düzeltilir | Opus (tasarım) + Sonnet | A_UI + D | — | EVET (D-27) | EVET | Fuse'lar uygulanmış installer'da backend HEALTHY |
| G-12 | Installer artifact'ı 30 gün sonra siliniyor; `.exe` SHA'sı bilinmiyor | V3-F039, V3-F049, PK-00 | Artifact `expires_at 2026-12-02T11:14:14Z`; digest ZIP'e ait (VERIFIED) | Süre dolduğunda "latest-known-good" kaybolur | W0-a: deterministik indir → aç → `.exe` adı ve SHA → register'a EV kaydı; binary'yi Founder kendi deposunda saklar. GitHub Release/draft T3 kapsamında (D-13/D-23) | deterministik | D | — | Kısmen (saklama yeri) | EVET | Register'da `.exe` SHA + boyut |
| G-13 | "Siyah/kırmızı/beyaz tasarım sistemi" kapsama eklenmiş ama kaynağı yok | V3-F002, F008, PK-05, §8 | V3.1'de, repo dokümanlarında ve CSS'te yok; mevcut palet lacivert/camgöbeği (VERIFIED) | 118 renderer dosyasında görsel değişiklik → snapshot/test churn, W2'de gecikme | D-25 ile karar alınana kadar kapsam dışı. Kabul edilirse yalnız CSS token katmanında (`styles.css` `:root`) yapılır, ekran mantığına dokunulmaz | Sonnet (token) / Haiku (snapshot) | A_UI | D-25 | EVET | EVET | Görsel snapshot farkları yalnız token dosyasından |
| G-14 | Review yolu ikiye ayrılmış; IR token'ı reddediliyor | V3-F042, V3-T1034, UASCO-T0098 | #282'de IR check FAIL (REVIEWER_AUTH_REJECTED), alt ajan review'u ayrıca yapılıyor (VERIFIED) | Her PR'da sahte kırmızı check, çift maliyet | D-21 sonuçlanana kadar tek yetkili yol: taze alt ajan reviewer (T0/T1 için Sonnet, T2/güvenlik için Opus) + ledger kaydı. IR check yok sayılır, yeniden koşturulmaz | Sonnet / Opus | Supervisor | D-21 | EVET | EVET | PR başına tam olarak 1 review kaydı |
| G-15 | V3.1 kayıt dosyaları icra oturumuna verilmemiş; V3.1 aynı asistan tarafından üretildi | V4 §0, §14; V4 validation report | V4 "NOT VERIFIED" diyor. Dosyalar Founder'a teslim edildi ama V4 paketinde yok (VERIFIED) | İcra oturumu SOURCE_REQUIRED modunda yürür, Task'ları yeniden üretmeye çalışabilir | Founder V3.1 ZIP'ini (16 dosya) icra oturumuna verir (D-24). İcra tarafı yalnız deterministik hash ve tutarlılık kontrolü yapar, LLM ile uzlaştırma yapmaz | deterministik | Founder / E | D-24 | EVET | EVET | Hash eşleşmesi + 164/102 sayımı |
| G-16 | Ağ izolasyonlu sandbox'ta müşteri bağımlılıklarının kurulumu tasarlanmamış | V3-F016, F013, PK-12, W3/W4 | Sandbox `--net` ile izole (VERIFIED); R1 şablonları bağımlılıksız | Bağımlılıklı her projede (W3/W4 stack'leri) test koşulamaz | D-28: sandbox dışında kilit dosyası + integrity ile ön indirme, ardından ağsız test (önerilen) ya da yalnız registry'ye izinli egress | Opus (tasarım) + Sonnet | C_ENGINE | D-28 | EVET | EVET | Bağımlılıklı örnek projede ağsız test PASS |
| G-18 | Merge kuyruğunun kullanılabilirliği doğrulanmadı; ruleset "up-to-date" istemiyor | V3-F052, V3-T1008, V3-T1020, PK-09 | Rapor M.3 (#291+#288 olayı); ruleset (rapor EV13) | Paralel lane'ler arttıkça birleşik kırılma | W1'den önce V3-T1008 seri kuralı zorunlu; D-04 | deterministik | Supervisor | D-04 | EVET | EVET | 14 günde M.3 sınıfı olay 0 |
| G-19 | Uzun çalışma: journal büyümesi ve run başına pause eksik | V3-F022, F019, UASCO-T0049 | Run başına pause P2'de (RW-057). Journal büyümesi ölçülmedi (UNKNOWN) | Günlerce süren W3 run'larında kurtarma ve disk sorunları | UASCO-T0049'u W2 başına al; journal boyutu ve run süresi V3-EV kayıtlarına eklenir (ölçüm, yeni Feature değil) | Sonnet | C_ENGINE | — | HAYIR | EVET | 24 saatlik soak run'ı ve journal boyutu raporu |
| G-20 | Yerel V6 supervisor / Task Scheduler UNKNOWN; ikinci kontrol düzlemi riski | V3-F045, F023, D-12 | Rapor M.7 (UNKNOWN) | Founder-PC'de eski otomasyon aynı repoda iş başlatabilir | W1'den önce FA-7 kontrolü (PowerShell adımları rapor M.7'de) | — | Founder | D-12 | EVET | EVET | Kontrol çıktısında UASCO görevleri Disabled ya da yok |

## LOW

| ID | Başlık | Kanıt | Çözüm | Founder? |
| --- | --- | --- | --- | --- |
| G-17 | #247 "ürün-kritik 16,8 GB sızıntı" diye önceliklendirilmiş, ama yalnız selftest ve testi değiştiriyor | #247 dosyaları: `scripts/autonomy-hardening-selftest.mjs`, `tests/pkg-aut2-autonomy-hardening.test.ts`, manifest (VERIFIED) | D-07 batch 1'de kalabilir ama W0/W1 kritik yolundan çıkarılır; etkisi Founder-PC'de test çalıştırırken oluşan disk tüketimiyle sınırlı | Hayır (D-07 içinde) |
| G-21 | V4 gösterge sayacı `workingScreens/totalScreens` tanımsız | 252 ekran anahtarı ↔ 23 route ↔ 118 renderer dosyası | Payda olarak W1/W2 demo senaryolarında kullanılan route'lar alınır (`DS-*`); 252 anahtar UASCO-T0122 sınıflamasından sonra | Hayır |

## Yeni Feature gerekiyor mu?

Hayır. Bütün bulgular mevcut 57 Feature içinde karşılanıyor:

- G-02 → V3-F013 / V3-F001
- G-08 → V3-F057
- G-09 → V3-F025
- G-10 → V3-F046
- G-11 → V3-F009
- G-16 → V3-F016 / V3-F013
- G-19 → V3-F022

Yeni alt Task'lar ana kimlikleri koruyor: UASCO-T0031.a, UASCO-T0061.a, UASCO-T0023.a, UASCO-T0069.a/.b (EXECUTION_IMPROVEMENTS).
