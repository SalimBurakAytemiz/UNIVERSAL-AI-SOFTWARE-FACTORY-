# UASCO V4 — Bağımsız Mimari, İcra Hazırlığı ve Kabul Denetimi

| Alan | Değer |
| --- | --- |
| Durum | **AUDIT REPORT — öneri niteliğinde.** V4 yürürlüğe alınmadı. Founder kararı verilmedi. Repository, branch, PR ve rutinlerde değişiklik yapılmadı. |
| Denetim tarihi | 2026-11-02 (öğleden sonra), salt-okur oturum |
| Denetlenen paket | `UASCO_MASTER_EXECUTION_ROADMAP_V4_PACKAGE.zip` (5 dosya) |
| Karşılaştırma | V3.1 paketi (16 dosya), `UASCO_REMAINING_WORK` @ `uasco/production-reports` 770c551, `v7/integration` @ 16d3a925, GitHub API (PR'lar, Actions run'ları, artifact) |
| Etiketler | **VERIFIED** = bu denetimde birincil kaynakta kontrol edildi · **CLAIMED** = kaynak söylüyor, yeniden doğrulanmadı · **UNKNOWN** · **NOT_RUN_ENV_UNAVAILABLE** · **ESTIMATE** |

> **Bağımsızlık uyarısı:** V3.1 paketini bu denetimi yapan oturum üretti. V4 de V3.1'e dayanıyor. Bu yüzden bu denetim, V3.1 kaynaklı iddialar için **bağımsız değildir**. V3.1'e ait iki kendi hatası aşağıda açıkça yazıldı (G-08, G-11). Bu iddiaların üçüncü bir taze reviewer tarafından kontrol edilmesi önerilir. V4'e ve repository koduna ait bulgular kodla ve API'yle doğrulandı.

---

## 1. Paket bütünlüğü

| Kontrol | Sonuç | Etiket |
| --- | --- | --- |
| ZIP içeriği | 5 dosya. Yol geçişi (`..`, mutlak yol) yok | VERIFIED |
| `SHA256_MANIFEST.txt` | 4 dosyanın 4'ü manifestle birebir eşleşiyor. Manifest kendini kapsamıyor (normal); kendi SHA-256'sı `bef2f2db…4d35` | VERIFIED |
| Roadmap / Manifest / Directive / Validation | 34.270 / 42.332 / 3.938 / 748 bayt; hepsi tamamen okundu | VERIFIED |
| V4 manifest ↔ V3.1 `V3_FEATURE_CROSSWALK.json` | 57/57 Feature eşleşiyor. Epic, ad, kabul fazı, Task sayısı ve AC kimliklerinde fark yok | VERIFIED (script) |
| V4 R1 seed'leri ↔ V3.1 R1 kapanış kümesi | 29/29 Task eşleşiyor. Feature, faz ve `dependsOn` alanlarında fark yok | VERIFIED (script) |
| V4'ün "164 Task / 102 AC NOT VERIFIED" ifadesi | V4 doğru söylüyor: bu dosyalar V4 paketinde yok. Bu denetimde ise mevcutlar ve tutarlılar: 164 Task, 102 AC, döngü 0, eksik referans 0 (V3.1 doğrulama betiği). Kalan açık şu: dosyalar icra oturumuna verilmedi (G-15) | VERIFIED (bu oturum) |
| V4'ün başlangıç iddiaları | 16d3a925, CI 41434581692 = success, Windows Installer 41434581581 = success, artifact 13135209964 (111.397.611 bayt, son tarih 2026-12-02T11:14:14Z), `package.json` 0.7.0-dev.3 / Node ≥24 / npm script'leri | **VERIFIED** (GitHub API + git) |
| V4'ün başvurduğu 30 kod yolu | 30/30 yol 16d3a925'te mevcut | VERIFIED |
| 16d3a925'ten sonraki repo hareketi | Yeni CI run'ı, yeni branch ya da commit yok (son run 11:38Z). İcra oturumunun GitHub'a görünen bir çıktısı yok | VERIFIED |

## 2. Genel teknik değerlendirme

**V4'ün doğru yaptıkları:**

- V3.1 kapsamını kayıpsız taşıyor.
- Doğru ilkeleri benimsiyor: sahte PASS yok; CI kırmızıyken yalnız merge duruyor; en fazla 3 builder; T2/T3 yetkisi Founder'da; deterministik iş için model yok.
- Teslim dalgalarında (W0–W5) her dalga gerçek bir `.exe` üretiyor.
- Kod yollarına yaptığı referanslar doğru.

**V4'ün zayıf noktaları üç başlıkta toplanıyor:**

1. **Planlama birimi yanlış.** Dalgalar Task'a değil Feature'a atanmış. Bu yüzden R1'in kritik Task'larının 6'sı W2 ve W4'e düşüyor, Feature bağımlılıklarında 4 tersine kayma var (G-07).
2. **Gerçek Windows ortamının sahibi yok.** W0 ve W1'in kabulü, kurulu Windows'ta kullanıcı aksiyonu gerektiriyor. Bulutta çalışan icra oturumu bunu yapamaz ve V4 bu boşluğu bir owner'a ya da karara bağlamıyor (G-01).
3. **Lane modeli kendisiyle çelişiyor.** Dosya sahipliği çakışıyor: `core/workos/store.ts` için 3 lane, `server.ts` için 2 lane talip (G-05). W1'de 5 lane aynı anda aktif; bu, V4'ün kendi "3 builder" kuralıyla çelişiyor (G-06).

**Hazırlık hükmü:** V4 **koşullu olarak uygulanabilir.** W0'ın deterministik adımları ve kararsız bağımsız işler (§6) bugün başlayabilir. W1'in paralel lane'leri ise 4 düzeltme yapılmadan açılmamalı: dalgalar Task bazında atanmalı, dosya sahipliği netleşmeli, Windows yürütücüsü belirlenmeli (D-23) ve T2 onayları topluca planlanmalı (D-31). Bu düzeltmeler yeni bir roadmap gerektirmiyor; V4 içinde delta olarak yapılabilir (EXECUTION_IMPROVEMENTS).

## 3. Mimari zincirin kod üzerinden doğrulanması (16d3a925)

| Bağlantı | Bulgu | Kanıt | Durum |
| --- | --- | --- | --- |
| Renderer ↔ preload ↔ main IPC | Preload'un açtığı 9 kanalın 9'u da `ipcMain.handle` ile karşılanıyor (api-get, api-post, export-delivery, open-preview, pick-import-path, resume, retry-blocked, show-export, stop) | `preload.mjs`, `main.mjs` | VERIFIED (statik) |
| Main → paketli backend | Backend `ELECTRON_RUN_AS_NODE=1` ile başlatılıyor | `main.mjs:29` | VERIFIED |
| Backend → MissionRunner | Paketli modda runner etkin (`runner:{enabled:true}`) | `packaged-entry.ts` | VERIFIED |
| Backend → sandbox | Base'de Windows sağlayıcısı yok. #231, `server.ts` içinde `defaultSandboxProviderFor()` ile win32'de WSL2'yi seçiyor; `packaged-entry.ts`'te değişiklik gerekmiyor | `packaged-entry.ts` yorumu; #231 `core/sandbox/select-provider.ts` | VERIFIED (PR head) |
| WSL2 sağlayıcısının ön koşulları | Kullanıcı makinesinde şunlar gerekiyor: WSL2 dağıtımı (`UASCO_WSL_DISTRO` ya da keşif), dağıtım içinde `node` ve `perl`, `unshare`/`nsenter`/`setpriv`. Eksiklik reason kodlarıyla (`WSL_DISTRO_NOT_CONFIGURED` vb.) bildiriliyor | #231 `wsl-unshare-sandbox.ts` | VERIFIED (kod) / ortamda NOT_RUN |
| Claude CLI keşfi | Yalnız native `claude.exe` kabul ediliyor; npm `.cmd` shim'i `SHIM_UNSUPPORTED`. Launcher sha256 provenance ile pinleniyor; içerik değişirse `CLAUDE_LAUNCHER_PROVENANCE_CHANGED` | `claude-profiles.ts:174-240` | VERIFIED (kod) |
| Güvenlik araçları | gitleaks/trivy/semgrep yalnız PATH'te mutlak `.exe` olarak aranıyor. Installer bunları içermiyor | `security-tools.ts:38-64`; installer içinde grep = 0 | VERIFIED |
| Desktop export | **Kök neden kesinleşti.** `sanitizePostBody()` başarılı yanıttaki bütün string'lere `scrubText` uyguluyor; bu, mutlak yolu `[path]` yapıyor. Ardından `deliveryExportCheck()` `realpathSync(body.path)` çağrısında başarısız oluyor. Sonuç her zaman `exported:false` | `main.mjs:266-273, 240-249, 310-312` | VERIFIED (statik). Düzeltme küçük ama `main.mjs` korumalı (T2) |
| Proje şablonları | `web-node` / `node-lib` bağımlılıksız, `test: node test.js`, **`package-lock.json` yok** | `project-templates.ts:17,95` | VERIFIED |
| Korunan yollar | `main.mjs`, `preload.mjs`, `server.ts`, `ci.yml`, `scripts/validate-*`, `config/*` korumalı. `runner.ts`, `execution-gate.ts`, `security-tools.ts`, sandbox sağlayıcıları, `claude-profiles.ts` ve `store.ts` korumasız (RW-006 hâlâ açık) | `config/protected-paths.json` (138 exact + 13 prefix) | VERIFIED |
| UI tasarımı | Mevcut palet lacivert/camgöbeği (`--bg:#050E1E`, `--accent:#15C5FF`). V4'teki "siyah/kırmızı/beyaz" gereksinimi V3.1'de, repo dokümanlarında ve kodda geçmiyor | `renderer/styles.css` | VERIFIED |

## 4. Denetim sorularına yanıtlar (bölüm 2'deki 10 soru)

1. **Eksik bileşen var mı? Evet:**
   - Kullanıcı tarafında WSL2 hazırlığı ve tanılaması yok (G-02).
   - Windows'ta gerçek kurulum ve E2E'yi kimin yürüteceği tanımlı değil (G-01).
   - Bağımsız yeniden üretim adımı (`npm ci`) şablonlarda kilit dosyası olmadığı için kırık (G-08).
   - Müşteri projesi bağımlılıklarının ağ izolasyonlu sandbox'a nasıl kurulacağı tasarlanmamış (G-16).
   - Kota ölçüm mekanizması yok (G-10).
2. **Zincir bağlanabilir mi?** Statik olarak evet; kopuk yerler biliniyor. Sandbox #231 ile bağlanıyor, export tek satırlık kök nedenle kırık. Gerçek modelle hiç uçtan uca koşulmadı. Kurulu üründe NOT_RUN.
3. **Bağımlılık sırası doğru mu? Kısmen.**
   - Dalga ataması Feature bazında olduğu için R1-kritik Task'lar geç kalıyor (G-07).
   - `UASCO-T0016` (export) ve `UASCO-T0031` (#231), RW-006 kapsam genişlemesine bağlanmış. Gerçekte bu Task'ların ihtiyacı yalnız T2 onayı ve reseal; bağlantı kritik yolu gereksiz uzatıyor (G-03).
4. **Birbirinin üzerine yazan bileşenler var mı?** Var:
   - Aynı dosyalar için birden fazla lane'e sahiplik verilmiş (G-05).
   - Review yolu ikiye ayrılmış: IR workflow her PR'da FAIL üretirken alt ajanla ayrıca review yapılıyor (G-14).
   - Yerel V6 supervisor'ın durumu UNKNOWN; ikinci bir kontrol düzlemi riski var (G-20).
5. **Mevcut kod atlanmış mı? Büyük ölçüde hayır.** V4 mevcut modülleri bağlamayı öneriyor. İki istisna:
   - PK-05'in yeni tasarım sistemi gereksiz yeniden yazım riski taşıyor (G-13).
   - #231'in kendi kabul aracı (`docs/acceptance/windows/founder-acceptance.mjs`) V4'te geçmiyor. W0/W1 kontrol listesi bu araçtan türetilmeli.
6. **57 Feature Task ve AC'ye bağlı mı?** V3.1'de evet (57/57). V4 manifesti yalnız AC kimliklerini taşıyor, Task matrisini taşımıyor (G-15).
7. **164 Task ve 102 AC doğrulanabilir mi?** V3.1 dosyalarıyla doğrulanabiliyor. Ancak bunlar kanonik raporun 129 Task'ından üretilmiş türev kayıtlar; 35 yeni Task bir öneri ve hiçbiri kanonik değil.
8. **Windows engelleri tam mı? Hayır.** V4'ün listesinde G-01, G-02, G-08, G-09 ve G-12 eksik.
9. **UI ↔ API bağlantıları:** IPC eşleşmesi tam. Renderer'ın 73/73 route bağı CLAIMED (rapor G3). 10 route yalnız sahte köprüyle test edilmiş (RW-053). Ekranlar gerçek kurulumda hiç denenmedi. V4'ün "her ekran sözleşmesi" kuralı doğru, ama sayaç tanımı (`workingScreens/totalScreens`) belirsiz: 252 ekran anahtarı mı, 23 route mu (G-21)?
10. **Uzun çalışma riskleri:** Sıfır baytlık kilit dosyası (TD-V2-06) V3-T1001 ile ele alınıyor. Açıkta kalanlar:
    - Claude launcher'ın pinlenmiş hash'i ile otomatik güncelleme çatışması (G-09).
    - Kota yönetimi (G-10).
    - Artifact'ların silinmesi (G-12).
    - Run başına pause/resume P2'ye kadar yok (RW-057).
    - Journal'ın sınırsız büyümesi (UNKNOWN; ölçülmedi).
    - Yanlış merge riski: ara seri kural var, ama native merge queue'nun bu repoda kullanılabilirliği doğrulanmadı (G-18).

## 5. Gerçek ürün kabul aşamaları (bölüm 8)

| Aşama | Durum | Kanıt | Not |
| --- | --- | --- | --- |
| BUILD_OK | **VERIFIED** | CI 41434581692 success @16d3a925 | Bu tek başına ürün kabulü değil |
| INSTALLER_OK | **VERIFIED (yalnız CI runner)** | Windows Installer 41434581581 success; artifact 13135209964 | Workflow içindeki sessiz kurulum smoke'unun bu run'da geçtiği CLAIMED. `.exe`'nin SHA'sı UNKNOWN; artifact digest'i ZIP'e ait (`sha256:c44e21bf…872d`) |
| INSTALLED_ON_WINDOWS | **NOT_RUN_ENV_UNAVAILABLE** | — | Founder-PC ya da gerçek kullanıcı kurulumu yok (G-01) |
| UI_API_INTEGRATED | **INTEGRATED + TESTED(unit)** | IPC 9/9 VERIFIED; 73/73 route CLAIMED | Kurulu üründe NOT_RUN |
| REAL_MODEL_EXECUTED | **NOT_RUN** | Tek kayıt 2026-10-14 oyuncak run (UNVERIFIABLE) | Founder-PC'de Claude login gerekli |
| SANDBOX_VERIFIED | **BLOCKED** (Windows) / Linux CI'da VERIFIED | #231 açık, 173 commit geride | Ortam ön koşulları G-02 |
| TEST_ACCEPTED | **NOT_RUN** | — | Sandbox'a bağlı |
| SECURITY_ACCEPTED | **NOT_RUN** | — | Araçlar kurulu değil (SEC-PROFILE-R1, D-19) |
| DELIVERY_ACCEPTED | **BLOCKED** | Export kök nedeni VERIFIED (main.mjs:273) | Bağımsız yeniden üretim adımı da kırık (G-08) |
| FOUNDER_ACCEPTED | **NOT_RUN** | — | — |

## 6. Gerçek Windows `.exe` teslimini bloke edenler

| Sıra | Engel | Bulgu | Çözüm yolu | Karar |
| --- | --- | --- | --- | --- |
| 1 | Windows'ta kurulumu ve E2E'yi yürütecek kimse tanımlı değil | G-01 | Founder runbook'u ya da Founder-PC'ye Remote Control bağlantısı | **D-23** |
| 2 | Windows sandbox (#231) merge edilmedi; ortam ön koşulları tanımsız | G-02, G-04 | #231 rebase + delta review + reseal batch; WSL2 hazırlık runbook'u | D-03, D-07, D-31 |
| 3 | Export her zaman başarısız | G-03 | `main.mjs`'te başarılı yanıt için scrub istisnası; T2 | D-31 |
| 4 | Bağımsız yeniden üretim (`npm ci`) şablonlarda başarısız olur | G-08 | Kilit dosyası üret ya da yöntemi değiştir | — (teknik) |
| 5 | Claude CLI provenance pin'i otomatik güncellemeyle bozulabilir (UNVERIFIED) | G-09 | Davranışı test et; yeniden doğrulama akışı | D-29 |
| 6 | Güvenlik araçları kurulu değil (R1 profili) | — | V3-T1010 + Founder kurulumu | D-19 |
| 7 | Kota tükenmesi 3 ardışık run'ı kesebilir | G-10 | UASCO-T0110 minimal koruma + bütçe | D-08 |

## 7. Bu denetimin kendi bulguları ile önceki iddiaların ayrımı

| Kaynak | İddia | Bu denetimde |
| --- | --- | --- |
| V4 | CI/installer/artifact değerleri | VERIFIED |
| V4 | "57 Feature taşındı" | VERIFIED |
| V4 | "164/102 NOT VERIFIED" | Paket açısından doğru; V3.1 dosyalarıyla doğrulanabilir |
| V4 | "#247 16,8 GB geçici dosya sızıntısı öncelikli" | #247 yalnız `scripts/autonomy-hardening-selftest.mjs` ve testini değiştiriyor: test/selftest sızıntısı, `.exe` ürününü etkilemiyor (G-17) |
| V3.1 (bu oturumun önceki çıktısı) | V3-AC-F009-2 "RunAsNode fuse off" | **Hatalı:** paketli backend'in çalışması bu fuse'a bağlı (G-11) |
| V3.1 | R1-AC6 / V3-T1012 "`npm ci && npm test`" | **Hatalı:** kilit dosyası olmayan şablonda `npm ci` hata verir (G-08) |
| V3.1 | UASCO-T0016 ve UASCO-T0031'in UASCO-T0069'a bağlı olması | Fazla katı; asıl gereken T2 onayı ve reseal batch'i (G-03) |
| Kanonik rapor | 73/73 route bağlı | CLAIMED (yeniden ölçülmedi) |

## 8. Doğrulanamayanlar

- `.exe`'nin artifact içindeki adı ve SHA'sı: artifact indirilmedi (111 MB, salt-okur denetim kapsamı dışında). → UNKNOWN
- Installer workflow'undaki smoke adımının 41434581581'deki ayrıntılı sonucu: job log'ları okunmadı. → CLAIMED
- Founder-PC ortamı (Windows sürümü, WSL2, sanallaştırma, Claude login, V6 Task Scheduler). → NOT_RUN_ENV_UNAVAILABLE
- Native Claude Code'un otomatik güncelleme sıklığı ve launcher dosyasını değiştirip değiştirmediği. → UNKNOWN (G-09)
- GitHub native merge queue'nun bu kişisel hesap reposunda kullanılabilirliği. → UNKNOWN (G-18)
- İcra oturumunun hesabında hangi modellere erişilebildiği: bu oturumdaki Agent aracı haiku/sonnet/opus seçimine izin veriyor; icra oturumu ayrıca doğrulamalı. → kısmen VERIFIED
- #231'in güncel base'e rebase edildiğinde çakışma boyutu (173 commit, 42 dosya). Rebase denenmedi (salt-okur). → UNKNOWN
- Journal büyümesinin ve uzun süreli çalışmanın kaynak tüketimi. → UNKNOWN
