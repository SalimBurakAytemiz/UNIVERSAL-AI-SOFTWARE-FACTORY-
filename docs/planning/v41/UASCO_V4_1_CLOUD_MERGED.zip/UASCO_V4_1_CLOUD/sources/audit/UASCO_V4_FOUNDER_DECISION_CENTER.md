# UASCO V4 — Founder Karar Merkezi

> Hiçbir karar verilmedi. Öneriler bağlayıcı değildir. Güvenlik, harcama, secret, dış dağıtım ve korunan yol onaylarını yalnız Founder verir.
>
> **Kimlik kuralı:** V3.1'deki D-01..D-22 kimlikleri korundu. V4 denetiminden çıkan yeni kararlar **D-23..D-31** olarak eklendi.
>
> **V4 §11 kararlarının karşılığı:**
>
> | V4 §11 kararı | Karar kimliği |
> | --- | --- |
> | Windows ve WSL2 | D-03 + D-26 |
> | T2 birleşik reseal | D-07 + D-31 |
> | Geliştirme bütçesi | D-08 (+ D-09 ücretli API) |
> | Güvenli PR stratejisi | D-04 |
> | Reviewer kimliği | D-21 (+ D-05) |
> | Yerel otomasyon | D-12 |
>
> **DELTA_HANDOVER_V3 karşılığı:** FD-A → D-20, FD-B → D-07, FD-C → D-11, FD-D → D-21, FD-E → D-04, FD-F → D-06, FD-G → D-12, FD-H → D-01.

**Öncelik:**

| Kod | Anlamı |
| --- | --- |
| NOW | Bugün |
| BEFORE_W1 | W1 paralel lane'leri açılmadan |
| BEFORE_W2 | W2 başlamadan |
| LATER | İleri fazlar |

**Özet:** A grubu 6 karar (hemen) · B grubu 17 karar (kodlama sürerken) · C grubu 8 karar (ileri fazlar) = 31 karar.

---

## A. Hemen verilmesi gereken gerçek blokaj kararları

### D-23 — Windows'ta gerçek kurulum ve E2E'yi kim yürütecek? (YENİ · NOW · G-01)
- **Açıklama:** Bulutta çalışan Claude oturumu Windows'a `.exe` kuramaz ve uygulamayı açıp kullanamaz. W0 ve W1'in kabul kanıtını üretecek ortam ve kişi belirlenmeli.
- **Neden gerekli:** Bu karar olmadan INSTALLED_ON_WINDOWS ve sonraki bütün kabul aşamaları NOT_RUN kalır.
- **Seçenekler:**
  - **A:** Founder kendi PC'sinde runbook'u uygular. Runbook #231'deki `founder-acceptance.mjs` ve V3-T1019 kontrol listesinden üretilir. Founder sonuç JSON'unu ve ekran görüntüsünü yükler.
  - **B:** Founder-PC'deki bir klasör Claude Code Remote Control ile oturuma bağlanır. Claude komutları Founder'ın makinesinde, Founder'ın her bağlantıyı onaylamasıyla çalıştırır.
  - **C:** Ara çözüm olarak yalnız GitHub `windows-latest` runner'da ek E2E. INSTALLER_OK ve UI_API kanıtı üretir, ama INSTALLED_ON_WINDOWS ya da FOUNDER_ACCEPTED yerine geçmez.
- **Öneri:** **A + C.** A bugün mümkün ve kabul kanıtı üretir; C paralelde regresyonu yakalar. B daha hızlıdır, ama Founder makinesine komut erişimi verir; güvenlik değerlendirmesi Founder'a aittir.
- **Avantaj:** Kanıt gerçek ortamdan gelir; Claude'a Founder-PC erişimi gerekmez.
- **Risk:** Founder'ın zamanına bağlı (yaklaşık 30–60 dk/tur, ESTIMATE). Elle girilen sonuçlar hash'lenmezse güvenilirliği düşer.
- **Maliyet:** Token etkisi ihmal edilebilir. C: run başına yaklaşık 20–30 Windows runner-dk (public repo'da ücretsiz).
- **Bloke ettiği:** V3-F001/F004/F012/F013/F015/F057 kabulü; UASCO-T0002, T0014, T0029, T0035, T0044, V3-T1018.
- **Karar alınmazsa:** W0/W1 Task'ları kod ve CI seviyesinde ilerler, bütün kabul aşamaları `NOT_RUN_ENV_UNAVAILABLE` kalır ve hiçbir Feature ACCEPTED olmaz.
- **Öncelik:** NOW

### D-31 — T2 onaylarının toplu takvimi (YENİ · NOW · G-03, G-04)
- **Açıklama:** W1'in iki kritik işi korumalı dosyalara dokunuyor: export düzeltmesi (`apps/desktop/main.mjs`) ve #231 sandbox bağlantısı (`server.ts` + trust-root manifest). Bunlara CI ve shard düzeltmeleri (`ci.yml`, `scripts/validate-shards.mjs`) de eklenecek. Bu PR'ları tek tek mi, dalga başına bir T2 paketi olarak mı onaylayacaksınız?
- **Neden gerekli:** Korumalı dosya merge'ü Founder onayı olmadan yapılamaz. Onaylar dağınık gelirse kritik yol saatlerce, hatta günlerce bekler (geçmişte protected-tier medyanı 11,8 h, p90 87,3 h).
- **Seçenekler:**
  - **A:** Dalga başına tek T2 paketi. Supervisor, korumalı dosyaya dokunan PR'ları ve her birinin değişiklik özetini tek listede sunar; Founder bunları bir oturumda tek tek onaylar ya da reddeder.
  - **B:** PR başına anlık onay.
  - **C:** Belirli korumalı dosyalar için süreli bir genel onay (önerilmez: yetki kuralını zayıflatır).
- **Öneri:** **A.** Her PR ayrı onaylanmaya devam eder; yalnız zamanlama toplu yapılır. Böylece güvenlik kuralı değişmez.
- **Avantaj:** Kritik yol beklemesi azalır. Founder bağlam değiştirmeden, aynı anda karar verir.
- **Risk:** Paket gecikirse birden fazla iş birlikte bekler. Azaltım: paket hazır olunca bildirim; diğer işler sürer.
- **Maliyet:** Yok. Çoklu rebase döngülerini azalttığı için token tasarrufu sağlar.
- **Bloke ettiği:** UASCO-T0016, UASCO-T0031, V3-T1002/1003/1036, UASCO-T0069.a.
- **Karar alınmazsa:** PR'lar hazırlanır ve review edilir, merge olmaz (B gibi davranılır).
- **Öncelik:** NOW

### D-03 — Windows sandbox yaklaşımı: WSL2 (#231) (V3.1 · NOW · doğrulama gerektiriyor)
- **Açıklama:** Kurulu uygulamanın proje testlerini izole çalıştırması için WSL2 sağlayıcısı (#231) kullanılsın mı?
- **Neden gerekli:** W1'in kritik yolu. Sandbox olmadan test sonucu "NOT_EXECUTED" kalır.
- **Seçenekler:**
  - **A:** WSL2 (#231 hazır).
  - **B:** Windows-native izolasyon (yeni geliştirme).
  - **C:** Docker veya VM.
- **Öneri:** **A.** Ama karar ancak doğrulamadan sonra kesinleşir. Founder şunları kontrol eder: Windows 11, BIOS'ta sanallaştırma açık, `wsl --status` çıktısı WSL2, bir dağıtım kurulu, dağıtım içinde `node` ve `perl`. Sandbox'sız "host'ta çalıştır" modu önerilmez.
- **Avantaj:** Kod hazır ve ücretsiz.
- **Risk:** Kullanıcı makinesi ön koşulları (G-02). #231 güncel base'in 173 commit gerisinde (G-04).
- **Maliyet:** Rebase ve review yaklaşık 40–120 h (ESTIMATE, rapor RW-004).
- **Bloke ettiği:** UASCO-T0031 → W1 kritik yolu.
- **Karar alınmazsa:** #231 yalnız rebase ve review hazırlığına kadar ilerler, merge olmaz.
- **Öncelik:** NOW (doğrulama 15 dk, ESTIMATE)

### D-07 — Trust-root reseal: iki batch (V3.1 · NOW · doğrulama gerektiriyor)
- **Açıklama:** #251, #247 ve #231 aynı manifest dosyasında çakışıyor. Mühürleme tek seferde mi, iki aşamada mı yapılsın?
- **Seçenekler:**
  - **A:** Tek reseal (V3 önerisi).
  - **B:** Batch 1 = #251 + #247 (+ RW-006'nın W1'e engel olmayan kısmı); Batch 2 = #231, Windows kabulünden (FA-5) sonra.
  - **C:** Üç ayrı reseal.
- **Öneri:** **B.** #251'deki provenance/aggregator düzeltmesi W1'den önce gerekir; #231'in kabulü ise Founder-PC'ye bağlı.
- **Avantaj:** CI düzeltmesi #231 beklemesinden kurtulur.
- **Risk:** İki ayrı reseal işlemi. #251 ve #247'nin güncel base'e göre yeniden review edilmesi gerekir (199–263 commit geride).
- **Maliyet:** Batch başına yaklaşık 1–2 h Founder + review (ESTIMATE).
- **Bloke ettiği:** UASCO-T0069.a, V3-T1002/1003/1036, UASCO-T0031.
- **Karar alınmazsa:** Hiçbir reseal yapılmaz; CI düzeltmesi ve sandbox merge'ü bekler.
- **Öncelik:** NOW

### D-12 — Yerel V6 / Task Scheduler / worker durumunu doğrulayıp durdurma (V3.1 · NOW)
- **Açıklama:** Founder-PC'de eski bir otomasyon çalışıyorsa, yeni icra oturumuyla aynı repo üzerinde çakışabilir.
- **Seçenekler:**
  - **A:** Durdur ve raporla (rapor M.7'deki PowerShell adımları).
  - **B:** Çalışmaya devam etsin ama aynı claim protokolüne katılsın (geliştirme gerektirir).
  - **C:** Bırak.
- **Öneri:** **A.**
- **Avantaj:** Tek supervisor kuralı gerçekten sağlanır.
- **Risk:** Yok denecek kadar az.
- **Maliyet:** 10 dk (ESTIMATE).
- **Bloke ettiği:** PAUSED_VERIFIED durumu; W1 paralel lane'leri (güvenli eşzamanlılık).
- **Karar alınmazsa:** İcra oturumu yalnız bulut düzleminde çalışır; durum UNKNOWN olarak raporlanır.
- **Öncelik:** NOW

### D-24 — V3.1 kayıtlarını V4 icrasının kaynağı olarak kabul etme (YENİ · NOW · G-15)
- **Açıklama:** V4 paketi 164 Task'lık matrisi içermiyor. V3.1'in 16 dosyalık paketi icra oturumuna verilsin ve kaynak kabul edilsin mi?
- **Neden gerekli:** Paket verilmezse icra oturumu `SOURCE_REQUIRED` modunda çalışır ve Task'ları yeniden üretmeye çalışabilir; bu da token kaybı ve tutarsızlık demektir.
- **Seçenekler:**
  - **A:** V3.1 ZIP'ini olduğu gibi ver; bu denetimdeki delta'lar (EXECUTION_IMPROVEMENTS) "önerilen" olarak eklensin.
  - **B:** Önce V3.1'i üçüncü, taze bir reviewer'a doğrulat, sonra ver.
  - **C:** Verme; icra yalnız 29 seed Task ile yürüsün.
- **Öneri:** **A.** İcra tarafı yalnız deterministik hash ve tutarlılık kontrolü yapsın. Not: V3.1'i bu denetimi yapan oturum üretti; bağımsızlık sınırlı. Bu yüzden 35 yeni Task, ilk kez yürütülmeden önce kendi Task review'undan geçmeli.
- **Avantaj:** Yeniden uzlaştırma maliyeti sıfıra iner.
- **Risk:** V3.1'deki olası hatalar taşınır. Bilinen ikisi bu denetimde düzeltildi (G-08, G-11).
- **Maliyet:** Yok.
- **Bloke ettiği:** W2+ Task seçimi; 29 seed dışındaki bütün Task'lar.
- **Karar alınmazsa:** İcra yalnız 29 seed Task ve 57 Feature ile ilerler.
- **Öncelik:** NOW

---

## B. Kodlama devam ederken alınabilecek kararlar

| Id | Karar (açıklama) | Neden | A / B / C | Öneri | Avantaj | Risk | Maliyet | Bloke ettiği | Karar yoksa güvenli varsayılan | Öncelik |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| D-08 | Haftalık geliştirme bütçesi (oturum/saat ya da token) ve dağılımı | Kota geçmişte işin %55'ini durdurdu (G-10) | A: sabit haftalık sınır + %90'da sert durma · B: yalnız gözlem · C: sınırsız | **A** | Kota duruşu planlı olur | Sınır düşük seçilirse yavaşlar | Yok (sınırlar) | UASCO-T0110 | W1'de en fazla 3 builder; USAGE_LIMIT görülünce durdur | BEFORE_W1 |
| D-29 | Claude CLI launcher hash pin'i ile otomatik güncelleme politikası (YENİ) | Güncelleme executor'ı NOT_READY yapabilir (G-09) | A: güncellemede Founder tek tıkla yeniden doğrular · B: W1 boyunca Claude Code otomatik güncellemesi kapalı · C: pin'i kaldır (güvenliği zayıflatır) | **A**; W1'in 3 ardışık run'ı sırasında **B** geçici olarak | Güvenlik korunur, run'lar kesilmez | B'de güncel güvenlik yamaları gecikebilir | Yok | UASCO-T0061.a, W1 run'ları | Pin korunur; değişimde run BLOCKED | BEFORE_W1 |
| D-21 | IR reviewer: token'ı yenilemek mi, IR'ı emekli etmek mi (FD-D) | Her PR'da sahte FAIL ve çift review (G-14) | A: token yenile (`claude setup-token` → `uasco-review` env secret) · B: IR'ı resmen opsiyonel işaretle ve alt ajan reviewer'ı tek yol yap · C: ayrı reviewer App (D-05) | **B** şimdi, **C** P2'de | Gürültü ve maliyet azalır | IR'ın GitHub tarafından zorlanan bağımsızlığı P2'ye kalır | Yok | V3-T1034, UASCO-T0098 | IR check yok sayılır, ledger review'u geçerli | BEFORE_W1 |
| D-19 | SEC-PROFILE-R1 (yerleşik secret scan + gitleaks + SCA) ve pre-dev kalite eşiği | SECURITY_ACCEPTED için araç gerekli | A: Founder-PC'ye gitleaks ve SCA kur (pinned) · B: yalnız yerleşik secret scan (sonuç PARTIAL olur, VERIFIED etiketi verilmez) · C: araçları installer'a göm (lisans ve boyut incelemesi gerekir) | **A** (R1); **C** W4'te değerlendirilir | Dürüst SECURITY_ACCEPTED | Founder kurulum adımı | ~15 dk | V3-T1010, W1 kabulü | Teslim DELIVERED_SECURITY_PARTIAL etiketi alır | BEFORE_W1 |
| D-20 | Windows CI kararlılığı ile #231 paralel mi (FD-A) | Sıra belirsiz | A: paralel; #231 merge'ü CI kararlılığından sonra · B: önce CI · C: önce #231 | **A** | Kritik yol kısalır | — | Yok | V3-T1001, UASCO-T0031 | A gibi davranılır (merge güvenliği korunur) | BEFORE_W1 |
| D-30 | "Latest-known-good" `.exe`'nin saklanması (YENİ) | Artifact 2026-12-02'de siliniyor (G-12) | A: Founder indirir ve kendi deposunda saklar; SHA register'da · B: GitHub draft Release (dış dağıtım değil, ama T3 sınırına yakın) · C: yalnız artifact | **A** | Dış dağıtım yok | Elle adım | Yok | W0 kanıtı | SHA register'a yazılır, binary saklanmaz | BEFORE_W1 |
| D-17 | Base kırmızıyken merge durur, geliştirme durmaz | V4 ile uyumlu | A: kabul · B: tam dondurma | **A** | Hız | — | Yok | V3-T1007 | A | BEFORE_W1 |
| D-18 | CI shard provenance kuralları | Sahte PASS riski | A: kabul (V3.1 §7.5) · B: yalnız "Re-run all jobs" | **A** | Güvenlik | — | Yok | V3-T1002/1003/1036 | Yalnız "Re-run all jobs" kullanılır | BEFORE_W1 |
| D-22 | #282 yeniden ele alma ölçütü | DEFER kararı var | A: 3 ardışık yeşil Windows + base kontrol koşusu · B: kapat | **A** | Teşhis değeri korunur | — | Yok | UASCO-T0090 | DEFER | BEFORE_W2 |
| D-04 | Birleşik SHA CI: native merge queue ya da up-to-date + seri tren | Yanlış merge riski (G-18) | A: merge queue (kullanılabilirliği doğrulanmalı) · B: ruleset'te "branch up to date" zorunlu · C: yalnız supervisor seri kuralı | **C** şimdi, **A ya da B** W2'den önce | Ara güvenlik hemen | C insan/ajan disiplinine dayanır | B: CI süresi uzar | V3-T1008, V3-T1020 | C | BEFORE_W2 |
| D-06 | Ledger ↔ founder-authority köprüsü (FD-10) | #293 türü kilitlenmeler | A: API'den okunan kayıt türü · B: Founder elle merge eder | **A** | Otomasyon | Değişiklik geliştirme altyapısında (T2) | ~4–10 h | V3-T1004 | B | BEFORE_W2 |
| D-01 | V3.1 + V4 delta'larının tek yetkili plan olması (FD-H) | Kayıt dağınıklığı | A: V3.1 kayıtları + V4 dalgaları + bu denetimin delta'ları · B: yalnız V4 | **A** | Tek kaynak | — | Yok | UASCO-T0120 | V4 proposal olarak kalır | BEFORE_W1 |
| D-02 | v1 kapsamı (R1 = kaynak teslimi) | V4 ile uyumlu | A: kaynak/ZIP · B: + PR · C: + deploy | **A** | Küçük R1 | — | Yok | UASCO-T0038 | A | BEFORE_W1 |
| D-11 | #66 SUPERSEDED | Ortak geçmişi yok | A: SUPERSEDED · B: yeniden kur | **A** | Temizlik | — | Yok | UASCO-T0096 | Açık kalır | BEFORE_W2 |
| D-14 | Repo public kalır | Actions ücretsiz | A: public · B: private (aylık Actions bütçesi gerekir) | **A** | Maliyet | — | Yok | UASCO-T0113 | A | BEFORE_W2 |
| D-25 | Siyah/kırmızı/beyaz tasarım sistemi gerçek bir gereksinim mi? (YENİ) | V4 PK-05 ekledi; kaynağı yok (G-13) | A: evet, W2'de yalnız CSS token katmanında · B: mevcut paleti koru · C: W4'e ertele | Founder tercihi. Teknik öneri: **A ise yalnız token katmanında** | Marka uyumu | Snapshot/test churn | ~8–20 h (ESTIMATE) | PK-05 | Mevcut palet korunur | BEFORE_W2 |
| D-26 | Desteklenen işletim sistemi matrisi (YENİ) | WSL2 Windows 10 ve 11'de farklı davranabilir (UNVERIFIED) | A: R1–R2 yalnız Windows 11 · B: Windows 10 + 11 · C: R2'de karar | **A** | Test yüzeyi küçük kalır | İkinci kullanıcı Windows 10 kullanıyorsa kapsam dışı kalır | Yok | DS-R2-INSTALL | A | BEFORE_W2 |

## C. İleri fazlarda alınabilecek kararlar (bugün sorulması gerekmiyor)

| Id | Karar | Seçenekler | Öneri | Bloke ettiği | Karar yoksa güvenli varsayılan | Öncelik |
| --- | --- | --- | --- | --- | --- | --- |
| D-05 | Builder/Reviewer GitHub App'leriyle kimlik ayrımı | A: App'ler · B: ikinci hesap · C: yalnız ledger | A (P2 başında) | UASCO-T0072, UASCO-T0097 | Ledger + alt ajan review | LATER (W2) |
| D-09 | Ürün içi ücretli API / ikinci sağlayıcı | A: P3'te T3 onayıyla · B: hiç · C: şimdi | A | UASCO-T0066 | Yalnız Claude CLI | LATER (W3) |
| D-10 | 599 rol → arketip + uzmanlık paketi | A: evet (eval sonrası) · B: hayır | A, V3-T1017 sonuçlarından sonra | UASCO-T0059 | 9 bağlı rol | LATER (W2–W3) |
| D-13 | Code-signing sertifikası | A: OV/EV sertifika · B: imzasız devam · C: ertele | A, W4 başında (tür ve maliyet araştırması gerekir) | UASCO-T0093 | İmzasız; SmartScreen uyarısı belgelenir | LATER (W4) |
| D-15 | Mobil ve ses (gizlilik) | A: W5 · B: iptal | A | UASCO-T0082, UASCO-T0018 | Kapsam dışı | LATER (W5) |
| D-16 | Faz maliyet sınırları | A: P0–P1 sınırlarını şimdi onayla, P2+ R1 ölçümünden sonra | A | Bütün fazlar | Sınır yok; yalnız ölçüm | P0–P1 kısmı BEFORE_W1, kalanı LATER |
| D-27 | RunAsNode fuse: backend'i `utilityProcess`'e taşımak mı, AC'yi düzeltmek mi (YENİ, G-11) | A: utilityProcess'e taşı, sonra fuse'u kapat · B: fuse açık kalsın, diğer fuse'lar kapatılsın, AC düzeltilsin | A (W4); A gerçekleşmezse B | UASCO-T0023 | Fuse açık (mevcut durum) | LATER (W4) |
| D-28 | Sandbox'ta müşteri bağımlılıklarının kurulma politikası (YENİ, G-16) | A: sandbox dışında kilit dosyası + integrity ile ön indirme, ağsız test · B: yalnız registry'ye izinli egress · C: ağ açık (önerilmez) | A | V3-F016, PK-12 | Yalnız bağımlılıksız şablonlar desteklenir | LATER (BEFORE_W3) |

---

## Hangi karar neyi bloke ediyor (özet)

| Karar | Bloke ettiği Task'lar | Etkilenen dalga |
| --- | --- | --- |
| D-23 | Bütün kabul kanıtları (T0002, T0014, T0029, T0035, T0044, V3-T1018) | W0, W1 kabulü |
| D-31 | T0016 (export), T0031 (#231), V3-T1002/1003/1036, T0069.a | W1 kritik yolu |
| D-03 | T0031 merge'ü | W1 |
| D-07 | T0069.a, T0031, CI provenance merge'ü | W1 |
| D-12 | Güvenli eşzamanlılık | W1 |
| D-24 | Seed dışındaki Task seçimi | W2+ |
| D-08, D-29, D-19 | W1'in 3 ardışık run'ı ve SECURITY_ACCEPTED | W1 kabulü |
| Diğerleri | Hiçbir kodlama işini durdurmuyor | — |
