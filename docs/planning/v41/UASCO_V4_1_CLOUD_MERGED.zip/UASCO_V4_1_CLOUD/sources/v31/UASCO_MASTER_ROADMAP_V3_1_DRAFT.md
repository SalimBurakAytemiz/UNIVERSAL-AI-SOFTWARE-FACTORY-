# MASTER ROADMAP V3.1 — DRAFT (bağımsız revizyon)

| Alan | Değer |
| --- | --- |
| Durum | **DRAFT — yürürlükte değil.** Bu belge V3'ün bağımsız revizyonudur; Founder kararları (§12) verilmedi, uygulama başlatılmadı. |
| Hazırlanma | V3: 2026-11-02 sabah · V3.1: 2026-11-02 öğleden sonra; salt-okur oturum. Repository, PR, commit, branch ve rutinlerde değişiklik yapılmadı. |
| Temel kaynak | `UASCO_REMAINING_WORK.md` + `.json` + `DELTA_HANDOVER_V3.md` @ `uasco/production-reports` **770c551** (bölüm A–P), evidence G1–G9; V3 taslağı (sha256 f8146594…cadd) |
| Entegrasyon snapshot'ı | `v7/integration` @ **16d3a925** (merge #294; git ls-remote ile doğrulandı, §0.4) |
| Eşlik eden kayıtlar | `V3_FEATURE_CROSSWALK`, `V3_TASK_DEPENDENCY_MATRIX`, `V3_ACCEPTANCE_EVIDENCE_MATRIX`, `V3_FOUNDER_DECISION_REGISTER`, `V3_REVISION_CHANGELOG` (her biri `.json` + `.csv` + `.md`; kimlikler makine-eşleştirilebilir). Tablolar bu belgeyle aynı veri setinden üretildi. |
| Etiketler | Raporun etiketleri aynen kullanılıyor: VERIFIED · CLAIMED · ESTIMATE · UNKNOWN · NOT_RUN_ENV_UNAVAILABLE. Bu taslağın kendi önerileri **PROPOSAL** olarak işaretli. |
| Seviye merdiveni | PLANNED > DESIGNED > CODED > INTEGRATED > TESTED(unit) > VERIFIED_REAL_ENV > USABLE_BY_END_USER (rapordaki gibi, değişmedi) |

**V3.1'de değişenlerin listesi:** §18 ve `V3_REVISION_CHANGELOG`.

**Temel ilke:** İlerleme, yazılan kodun, açılan PR'ın ya da çalışan ajanın sayısıyla ölçülmez. Ölçü, kurulu üründe baştan sona geçen ve kanıtı saklanan kullanıcı senaryolarının sayısıdır. Bugün bu sayı **0** (A.1, VERIFIED).

---

## 0. Başlangıç durumu ve geçici kabuller

### 0.1 Kesin kabul edilen olgular (değişmesi beklenmiyor)

- USABLE_BY_END_USER = 0. Release ve tag sayısı 0.
- Fikirden teslime giden döngü kurulu Windows uygulamasında "çalıştır ve doğrula" adımında kopuyor. Sandbox sağlayıcısı yok (`apps/control-api/src/packaged-entry.ts:52-57`), Desktop export da kırık (AUD-022).
- Gerçek modelle elde edilmiş tek ürün kanıtı 2026-10-14 tarihli 32 saniyelik bir oyuncak çalıştırma (EV11). Pre-dev zinciri (BA, gereksinim, mimari, plan) gerçek modelle hiç koşmadı.
- Ürün düzleminde tek sağlayıcı var (Claude CLI, iki profil). Model routing, ölçüm ve failover yok. 599 rolün 9'u bağlı, değerlendirilmiş rol sayısı 0.
- Geliştirme düzleminde maliyetin %85'i koordinatörde. Takvimin %55'i kota nedeniyle sıfır commit ile geçti. Değişen satırların %49,5'i süreç dosyası, %16,1'i ürün kodu.

### 0.2 Geçici değerler (kapanış sürüyor, temel olarak alınmadı)

| Değer | Bu taslaktaki varsayım | Fark analizinde kontrol edilecek |
| --- | --- | --- |
| v7/integration head ve push CI | **16d3a925**; push CI 41434581692 PASS, Windows Installer 41434581581 PASS (rapor P; CLAIMED, run sonucu bu oturumda Actions'tan okunmadı) | Sonraki push'larda Windows flake'leri (TD-V2-06/07) |
| #294 | **MERGED** 11:09:54Z (VERIFIED, GitHub API) | — |
| #282 | **Açık**, head 5d66b03, DEFER_TO_ROADMAP; son CI run 41427606970: shard 1 FAIL, aggregator FAIL (VERIFIED, check-runs) | Yeniden ele alma ölçütü (UASCO-T0090) |
| #251, #247, #231, #66 | Founder-tier, açık; trust-root manifest çakışması | D-07 (iki batch önerisi), D-11 |
| RW-002 | Rutinler 05:40Z'de kapandı, 24 saatlik gözlem açık | UASCO-T0115 (VERIFY_PENDING) |
| Yerel V6 supervisor, Task Scheduler, Cowork | UNKNOWN (M.7) | D-12 / FA-7 |
| IR token (REVIEWER_AUTH_REJECTED) | Yenilenmedi; #282'de de IR FAIL (VERIFIED, check-runs) | D-21 / V3-T1034 |

### 0.3 Taslağı son hâle getirme prosedürü (PROPOSAL)

1. PR kapanışı biter ve kanonik rapor güncellenir.
2. Bu taslakla yeni rapor arasında yalnız §0.2'deki satırlar ve §3'teki durum sütunları için fark analizi yapılır.
3. Founder §12'deki kararları verir.
4. V3.1 (ya da onaylanmış halefi) tek yetkili roadmap olarak ilan edilir (RW-015, D-01). Eski planlar arşivlenir (§11).

### 0.4 Kapanış yeniden doğrulaması (V3.1, zorunlu düzeltme 13)

| Olgu | Bulgu | Kanıt / yöntem | Etiket |
| --- | --- | --- | --- |
| `v7/integration` head | `16d3a925b8a3f4ffc08dea2ea64c53862a7bcb03` = "Merge pull request #294" (2026-11-02 14:09:53 +0300) | `git ls-remote origin refs/heads/v7/integration`; `git log` | VERIFIED |
| d5f4365 → 16d3a925 arası | 3 commit: 075545d (base sync), 6d19132 (rapor kopyası), 16d3a925 (merge). Yalnız `docs/closure/...` dosyaları | `git log d5f4365..16d3a925` | VERIFIED |
| #294 | closed, merged_at 2026-11-02T11:09:54Z, head 6d19132 | GitHub API list_pull_requests | VERIFIED |
| #282 | open, head 5d66b03; updated_at 14:05:19Z, ama 11:10Z'den sonra yeni check-run yok. 14:05Z güncellemesinin nedeni okunmadı (yorum ya da auto-merge değişikliği olabilir) | GitHub API check-runs | VERIFIED (durum) / UNKNOWN (14:05Z nedeni) |
| #295 | merged 09:51:06Z (d5f4365) | GitHub API | VERIFIED |
| Ledger | `uasco/production-queue` = 122a1b12 | git ls-remote | VERIFIED |
| Kanonik rapor | `uasco/production-reports` = 770c551; V3'ten sonra 4 rapor commit'i (N, O, P bölümleri + DELTA_HANDOVER_V3). JSON değişikliği: yalnız RW-044 OPEN→BLOCKED; 129 Task ve 49 Feature kaydı değişmedi | `git diff 44b9311 770c551` | VERIFIED |
| Yeni bulgular | TD-V2-06 (sıfır baytlık store-lock dosyası → LOCK_TIMEOUT), TD-V2-07 (Windows'ta 4 farklı PR-dışı test kırmızı), #282 için "PR dışı" iddiasının düzeltilmesi (`store.ts`'e dokunuyor) | Rapor N–P | CLAIMED (rapor) |
| Rutinler | 0/11 etkin (rapor P). Bu oturumda list_triggers çağrılmadı | — | CLAIMED |

---

## 1. Korunacak çalışan bileşenler (yeniden yazılmayacak)

Ölçüt: Kod bağlı, kendi bağımlılığına karşı test edilmiş ve CI kanıtı var. Bu bileşenler ancak kanıtlanmış bir kusur olursa değiştirilir.

| # | Bileşen | Düzlem | Kanıt | V3'teki rolü |
| --- | --- | --- | --- | --- |
| K1 | Electron kabuğu + paketli backend başlatma (loopback, stdin token, tek örnek kilidi) | Ürün | Installer smoke run 40497319565, VERIFIED_REAL_ENV (CI) | V3-E1 çekirdeği |
| K2 | Renderer → Control API (73/73 `/v1` yolu bağlı) | Ürün | G3 §3.2, VERIFIED | Tüm UI işleri bunun üstüne kurulur |
| K3 | Intake formu → idempotent mission DRAFT | Ürün | `routes/intake.ts`, `core/workos/intake.ts`; unit + CI | Komut alanı bunun önüne eklenir (RW-025) |
| K4 | Pre-dev zinciri + DRAFT/SUBMITTED/APPROVED onayı ("onaylayan ≠ kaydeden") | Ürün | `core/workos/predev/*`; unit | Gerçek model kalitesi ölçülecek (RW-026) |
| K5 | Plan → görev store'u (dependsOn, durum kuralları) | Ürün | `createTaskDetailed`; unit | Görev güdümlü yürütmenin temeli (N2) |
| K6 | MissionRunner (lease TTL, runner.lock, fenced takeover, retry ≤2, remediation ≤2) | Ürün | `core/workos/runner.ts`; v7-b3a* | Ürün düzleminin tek supervisor'ı |
| K7 | Hash-zincirli journal + sha256 run kanıtı + git log/diff route'ları | Ürün | tamper testleri; CI | Kanıt zincirinin temeli |
| K8 | ExecutionGate + SandboxProvider soyutlaması; Linux unshare sağlayıcısı (RW-085 CLOSED) | Ürün | CI | Windows sağlayıcısı aynı arayüze eklenir |
| K9 | Sunucu tarafı teslim ZIP'i + secret-scan bloğu (RW-086 CLOSED) | Ürün | v7-m1a-c2-delivery | Desktop export bunu çağıracak (RW-009) |
| K10 | GLOBAL_STOP, Tower, Cockpit, flow ve run görünümleri | Ürün | unit + renderer testleri | İzleme yüzeyi |
| K11 | test-surface bütünlük koruması, action-gateway çekirdeği, dependency-supply-chain kapısı | Ürün + Geliştirme | unit; kapı #293'te çalıştı | Politika bağlamı gerçeğe bağlanacak (RW-028) |
| K12 | Command-intake (#134) ve routeModel/chooseProvider (#130) çekirdekleri | Ürün | Yalnız unit; üretimde bağlı değil | **Yeniden yazılmaz, yalnız bağlanır** |
| K13 | CrewCoordinator / composeTeam, LeaseManager, pkg-lease1 kodu | Ürün + Geliştirme | CODED + unit | P3'te bağlanır |
| K14 | coord-ledger SHA-bound review + merge-gate | Geliştirme | 129 kayıt; #291/#288/#292 doğru merge edildi | Merge kuyruğu bunun üstüne kurulur |
| K15 | dispatch claim (create-only ref + nonce + ls-remote read-back) | Geliştirme | Kod VERIFIED | FA-LEASE2'nin taşıyıcısı |
| K16 | CI: ubuntu + 3 Windows shard + aggregator + installer build | Geliştirme | Çalışıyor; flake'li | Katmanlı CI'ın L1/L2 katmanı (§7) |
| K17 | Trust root mührü (373 dosya) + protected-paths.json | Geliştirme | verify OK, imzasız | Kapsamı genişletilecek (RW-006), imzalanacak (RW-029) |
| K18 | Lane A/B işletim kalıbı (dosya alanına göre lane, $3,66–4,01 / merged PR) | Geliştirme | EV23 | Lane modelinin şablonu |
| K19 | Açık PR'larda hazır iş: #231 WSL2 (42 dosya), #251 CI-TEP1 (aggregator düzeltmesi dahil), #247 temp temizliği | Geliştirme | Draft, Founder-tier | Rebase + delta review ile alınır; yeniden yazılmaz |

---

## 2. Düzeltilmesi gereken mimari bağlantılar

Bunlar yeni özellik değil. Kodu var ama birbirine bağlanmamış ya da yanlış bağlanmış noktalar. Sıra önceliğe göredir.

| # | Kopuk bağlantı | Bugün | Hedef bağlantı | Envanter | Faz |
| --- | --- | --- | --- | --- | --- |
| W1 | Paketli backend → SandboxProvider (Windows) | `packaged-entry.ts:52-57` sandbox seçeneği vermiyor; Windows'ta sağlayıcı `null` | WSL2 sağlayıcısı (#231) kaydedilir; kurulu uygulamada VERIFY=PASSED üretilir | RW-004 | P1 |
| W2 | Desktop export → `prepareRunDelivery` | Scrubber yüzünden her zaman başarısız (AUD-022) | Düğme sunucu ZIP'ini sha256 ile kaydeder | RW-009 | P1 |
| W3 | Paketli uygulama → Claude CLI keşfi | PATH ve CLI keşfi UNKNOWN (AUD-115) | Deterministik keşif + Desktop'ta tanılama ekranı | RW-010 | P1 |
| W4 | Teslim etiketi → doğrulama sonucu | Etiket her zaman NOT_VERIFIED | VERIFY=PASSED + review CLEAN + güvenlik raporu varsa `PRODUCT_VERIFIED_LOCAL` (yeni etiket, N8) | — (yeni) | P1 |
| W5 | Ledger merge-gate ↔ Founder yetkisi | Environment onayı ledger'a yansımıyor (M.1, TD-V2-02) | `founder-authority` kayıt türü; GitHub deployment-approval API'sinden okunur, elle yazılamaz | FD-10 / N4 | P0 |
| W6 | CI aggregator ↔ shard raporları | Yalnız aynı attempt'in raporlarını okuyor (COORD-001) | Aynı SHA için shard başına en son başarılı rapor | #251 / N5 | P0 |
| W7 | Ruleset ↔ birleşik CI | "Up-to-date" istenmiyor; #291 ile #288 birlikte installer testini kırdı (M.3) | Merge kuyruğu (§7.3) | N3 / TD-V2-05 | P0 |
| W8 | Merged PR'lar ↔ görev kaydı | 168 merged PR hiçbir kayıtta yok; BACKLOG 10-20, queue 10-22'de kalmış | Merge'lerden beslenen tek makine-okunur kayıt (§3.4) | RW-014 | P0 |
| W9 | Command-intake → Desktop | 0 üretim importer'ı | Tek komut alanı → intake DRAFT | RW-025 | P2 |
| W10 | routeModel/chooseProvider → executor seçimi | Sabit Claude CLI; model id kaydedilmiyor | Her adımda model id + routing kararı journal'a yazılır | RW-036 | P2 (yalnız kayıt) / P3 (çoklu sağlayıcı) |
| W11 | Executor → token/maliyet ölçümü | `maxTokens` yalnız kaydediliyor | Adım başına ölçülen kullanım ve bütçe kesmesi | RW-032 | P2 |
| W12 | Action-gateway → gerçek politika bağlamı | Sabit ALLOW (`server.ts:193-196`) | Risk sınıfı (R0–R3) + yetki matrisi (§8) | RW-028 | P2 |
| W13 | Plan/görev → yürütme | Runner mission seviyesinde çalışıyor; görevler yürütmeyi sürmüyor | Görev DAG'ı yürütmeyi sürer; her görevin kendi kanıtı olur | N2 (yeni) | P3 |
| W14 | Ürün içi Epic/Feature hiyerarşisi | Yalnız plan → task (16 aşamalı akışın 6. adımı PARTIAL) | Pre-dev Plan artifact'ı Epic → Feature → Task + AC üretir | N1 (yeni) | P2 |
| W15 | CrewCoordinator/composeTeam → runner | Yalnız tip/yer tutucu referansları var | Görev başına rol seçimi | RW-033 | P3 |
| W16 | FA-LEASE2 / LeaseManager → dev-plane claim | `refs/uasco/*` = 0; V6 claim çağırmıyor | Önce yalnız log, sonra zorunlu lease | RW-035 | P0 (log) / P3 (zorunlu) |
| W17 | core/qa/api validator'ları | Bağlı değil | Bağla ya da sil | RW-056 | P2 |
| W18 | V6 supervisor kodu ürün ağacında | Ölü yüzeyler (`server.ts:117-176`, task-selector) | Ürün ağacından ayrılır | RW-059 | P2 |

---

## 3. Envanter uzlaştırması ve V3 hiyerarşisi

### 3.1 Uzlaştırma bulguları (JSON üzerinden hesaplandı)

| Kontrol | Sonuç | Değerlendirme |
| --- | --- | --- |
| 87 RW maddesinin en az bir Task'a bağlı olması | **87/87 bağlı**. Boşta kalan RW yok, olmayan RW'ye giden referans yok | İyi |
| 129 Task'ın bir RW'ye bağlı olması | **30 Task'ın `inventoryId` alanı boş** (TD-V2-04) | 27'si COMPLETE baz varlık, yani "kalan iş" değil. Asıl eksik, bir **varlık (asset) kaydı**. |
| Bağı boş olup COMPLETE olmayan Task'lar | T0008 (Linux Electron journey, UNVERIFIABLE), T0028 (B3B canlı smoke, UNVERIFIABLE), T0094 (desktop journey harness, PARTIAL) | Gerçek boşluk bunlar. Öneri: T0008 ve T0094 → RW-024, T0028 → RW-005 |
| Birden fazla Task'a bağlı RW | 10 | Normal (RW birleştirilmiş madde) |
| Task'ı olmayan Feature | 0 | İyi |
| GitHub ↔ kayıtlar | 292 PR'ın 187'si hiçbir kayıtta yok, bunların 168'i merged (G2 §6) | Teslim edilen iş kayıtlarda değil, PR başlıklarında duruyor |
| Paralel kayıt kaynakları | BACKLOG_CHECKPOINT (102), PRODUCTION-QUEUE (16 + 17 + 15), ROADMAP.md (149 faz / 183 anahtar), 252 ekran anahtarı, Master V2 (21 madde, 6 merge), 87 RW, 129 Task | En az 7 kaynak. Tek kaynağa inmeli (§3.4) |
| Durum sözlüğü | Vocabulary'de `PRODUCT_ACCEPTED` var, kullanan kayıt 0 | Ürün kabulü hiç kaydedilmemiş |
| **V3.1 uzlaştırması** | 129 legacy Task'ın 129'u tek bir V3 Feature'a bağlandı. 3 Task yeniden bağlandı (T0008, T0094 → RW-024; T0028 → RW-005). 3 Task taşındı (T0040 → V3-F016, T0125 → V3-F009, T0127 → V3-F010). 35 yeni Task PROPOSED. Kapanış kanıtıyla değişen durumlar: 6 DONE_OBSERVED, 5 DEFERRED, 1 VERIFY_PENDING | `V3_TASK_DEPENDENCY_MATRIX` | Var olmayan hiçbir kayıt tamamlanmış gösterilmedi. Yeni Task'lar PROPOSED; ASSET Task'lar kalan iş sayılmaz. |
| **Yeniden doğrulanması gereken legacy durumlar** | T0076 (#293), T0089 (base kırmızısı), T0053/54/55 (#292/#291/#288), T0128 kapanışta tamamlandı; JSON hâlâ BLOCKED/PARTIAL gösteriyor | git merge SHA + rapor M/N/P | Kanonik JSON'un Task durumları bayat. Bu taslak eski kaydı değiştirmez; `v31Status` alanında kanıtıyla gösterir. |

### 3.2 Kimlik koruma kuralı (PROPOSAL)

- Eski kimlikler **değişmez ve silinmez**: `UASCO-E0x`, `UASCO-F0xx`, `UASCO-T0xxx`, `UASCO-RW-0xx`, Master V2 (A1…Z3, C-RDY-*), BACKLOG (UI-xxx, PQ-xxx, MOB-xx), FD-xx, AUD-xxx, ROADMAP Ph.N.
- Yeni V3 kimlikleri: `V3-E0..E8`, `V3-F###`, `V3-T####`, `V3-AC-###`, `V3-EV-####`. Her V3 kaydı `legacyIds[]` taşır.
- 27 baz varlık Task'ı için yeni bir tür eklenir: `ASSET-###` (korunacak bileşen, §1). Bunlar "kalan iş" sayımına girmez, ama gerilemeye karşı bir AC'ye bağlanır.
- Bir eski kimlik birden fazla V3 kaydına bölünürse (örnek: F017 → PR teslimi + deploy) her parça `splitFrom` alanı taşır.

### 3.3 Yeni Epic yapısı: ürün yeteneğine göre

Eski 9 Epic modüle göre bölünmüştü (A–F, CI, GOV, OPS). V3 Epic'leri ise **kullanıcının bir şeyi yapabildiği sonuçlara** göre bölünüyor. Geliştirme altyapısı (V3-E0) ürün Epic'lerinden ayrı tutuluyor.

| V3 Epic | Teslim edilen kullanılabilir sonuç ("bitti" tanımı) | Eski Feature'lar (V3.1: 49'un 49'u birebir V3-F kimliği aldı; bölünme yok) |
| --- | --- | --- |
| **V3-E0 Fabrika temeli (geliştirme düzlemi)** | UASCO repo'su bütçe içinde, tek supervisor ile, yeşil ve deterministik CI'la, kayıt sapması 0 olacak şekilde kendini geliştirebiliyor | F030, F031, F033, F034, F038, F041, F042, F043, F044, F045, F046, F047, F048, F049, F023 + yeni F052, F053, F054 |
| **V3-E1 Kur ve çalıştır** | Kullanıcı imzalı installer'la kurar, uygulama açılır, backend sağlıklıdır, güncelleme ve geri alma veri kaybetmez | F001, F002, F010, F039, F040 |
| **V3-E2 Fikirden spesifikasyona** | Kullanıcı tek komutla fikir girer, gerçek model BA, gereksinim, mimari ve Epic/Feature/Task + AC üretir, kullanıcı onaylar | F003, F004, F007, F011 + yeni F050 |
| **V3-E3 İnşa ve doğrulama** | Onaylanan görevler izole sandbox'ta kodlanır, testleri koşar (PASSED), güvenlik taraması ve bağımsız review'dan geçer, hata çıkarsa remediation döngüsü işler | F012, F013, F014, F029 (+ taşınan T0125 hariç) |
| **V3-E4 Teslim** | Kullanıcı doğrulanmış teslim paketini Desktop'tan alır ya da müşteri repo'suna PR olarak alır; teslim edilen proje UASCO dışında bağımsız olarak build ve test edilir | F005, F006, F015, F017 (PR teslimi), F018 + yeni F057 |
| **V3-E5 Yürütme motoru (ajan + model)** | Görevler uygun role ve modele yönlendirilir; maliyet ölçülür ve bütçeyle sınırlanır; kota dolunca run kurtarılabilir şekilde durur, yedek yola geçer; paralel güvenli yürütme yapılabilir | F019, F020, F021 (ürün bulut devri dahil), F022, F024, F025, F026, F027, F028 + yeni F051, F055 |
| **V3-E6 Ürün içi güven ve kontrol** | Her ürün aksiyonu risk sınıfına göre politika kapısından geçer; onaylar attestation'lıdır; Desktop sertleştirilmiştir | F009 (+ T0125 CLI sandbox), F032 + yeni F056 |
| **V3-E7 İzleme ve uzaktan kontrol** | Founder ilerlemeyi, maliyeti ve engelleri canlı görür; sonraki fazda telefondan izler ve STOP verebilir | F008 (Founder Cockpit), F035, F036, F037 |
| **V3-E8 Stack ve yaşam döngüsü genişliği** | Birden fazla gerçek müşteri stack'i; müşteri projesi için CI/CD, deploy ve izleme | F016 (+ T0040 deploy) (RW-027, RW-069, RW-080) |

**Yeni Feature'lar** (49'da yoktu; boşluk analizinden çıktı):

| Id | V3 kimliği | Feature | Neden gerekli |
| --- | --- | --- | --- |
| N1 | V3-F050 | Ürün içi Epic → Feature → Task + AC hiyerarşisi | 16 aşamalı akışın 6. adımı PARTIAL. Founder'ın hedefi tam olarak bu. |
| N2 | V3-F051 | Görev güdümlü yürütme (görev DAG'ı → runner) | Bugün görevler yürütmeyi sürmüyor (W13) |
| N3 | V3-F052 | Merge kuyruğu / birleşik CI | M.3 entegrasyon hatası |
| N4 | V3-F053 | Ledger ↔ Founder-authority köprüsü | M.1 tasarımsal senkronizasyon boşluğu |
| N5 | V3-F054 | CI sonuç provenance'ı ve shard toplama (attempt'ler arası güvenli birleştirme) | COORD-001; §7.5 |
| N6 | V3-F055 | Gerçek modelle "golden" değerlendirme seti (pre-dev + implement + review) | 3594 eval spec'in 0'ı koşuldu. Rol ve model kararları bunsuz verilemez. |
| N7 | V3-F056 | Birleşik yetki matrisi (ürün R0–R3 + geliştirme tier'ları) | §8 |
| N8 | V3-F057 | Teslim doğrulama etiketi + bağımsız yeniden build kanıtı | W4. "Ürün çalışıyor" ile "kod yazıldı" arasındaki fark burada ölçülüyor. |

### 3.3.1 57 Feature: tam liste (V3.1, zorunlu düzeltme 1)

Kimlik kuralı: `V3-F001..F049` = `UASCO-F001..F049` (aynı numara), `V3-F050..F057` = N1..N8. Açıklama, bağımlılık, Task ilişkisi ve AC metinleri `V3_FEATURE_CROSSWALK` ve `V3_ACCEPTANCE_EVIDENCE_MATRIX` dosyalarında. Kabul fazı = Feature'ın en geç AC fazı. Bir release kapısı Feature'lara değil, **AC'lere** bağlanır: bir Feature R1'de kısmen (yalnız R1 AC'leriyle) kullanılabilir, ACCEPTED olması ise bütün AC'lerine bağlıdır.

| V3 Feature | Legacy | Epic | Ad | Mevcut olgunluk | Kabul fazı | Task sayısı | AC'ler |
|---|---|---|---|---|---|---|---|
| V3-F030 | UASCO-F030 | V3-E0 | Trust root ve korunan yollar | SEALED (373 dosya), imzasız | P2 | 4 | V3-AC-F030-1, V3-AC-F030-2, V3-AC-F030-3 |
| V3-F031 | UASCO-F031 | V3-E0 | Kimlik ayrımı ve ruleset | yok (0 onay) | P2 | 1 | V3-AC-F031-1 |
| V3-F033 | UASCO-F033 | V3-E0 | Bağımlılık tedarik zinciri kapısı | Kapı çalışıyor; base kırmızı | P2 | 3 | V3-AC-F033-1, V3-AC-F033-2 |
| V3-F034 | UASCO-F034 | V3-E0 | Repo güvenlik taraması | kapalı | P2 | 1 | V3-AC-F034-1 |
| V3-F038 | UASCO-F038 | V3-E0 | CI hattı (ubuntu + 3 Windows shard + aggregator) | Çalışıyor; şu an base-wide kırmızı; flaky | P2 | 7 | V3-AC-F038-1, V3-AC-F038-2, V3-AC-F038-3 |
| V3-F041 | UASCO-F041 | V3-E0 | Windows desktop E2E CI | Linux harness CLAIMED | P2 | 3 | V3-AC-F041-1 |
| V3-F042 | UASCO-F042 | V3-E0 | Bağımsız review yolu | Workflow canlı, ai-review skipped | P2 | 3 | V3-AC-F042-1, V3-AC-F042-2 |
| V3-F043 | UASCO-F043 | V3-E0 | Founder yetki kaydı ve kararlar | Serbest metin | P1 | 4 | V3-AC-F043-1 |
| V3-F044 | UASCO-F044 | V3-E0 | Self-hosted runner hijyeni | UNKNOWN (API 403) | P0 | 1 | V3-AC-F044-1 |
| V3-F045 | UASCO-F045 | V3-E0 | Geliştirme düzlemi orkestrasyonu | Gerçek, günlük kullanımda; SPOF | P1 | 7 | V3-AC-F045-1, V3-AC-F045-2 |
| V3-F046 | UASCO-F046 | V3-E0 | Kota ve bütçe kontrolü | yok | P1 | 4 | V3-AC-F046-1, V3-AC-F046-2, V3-AC-F046-3 |
| V3-F047 | UASCO-F047 | V3-E0 | Rutin ve oturum hijyeni | 4 trigger kapatıldı; 2'si Founder'da | P2 | 5 | V3-AC-F047-1, V3-AC-F047-2 |
| V3-F048 | UASCO-F048 | V3-E0 | Tek görev kaydı ve tek roadmap | dağınık, bayat | P2 | 8 | V3-AC-F048-1, V3-AC-F048-2, V3-AC-F048-3 |
| V3-F049 | UASCO-F049 | V3-E0 | Kanıt saklama | artifact'lar siliniyor | P0 | 1 | V3-AC-F049-1 |
| V3-F023 | UASCO-F023 | V3-E0 | Yerel + bulut lease (FA-LEASE2) | CODED, bağlı değil | P3 | 3 | V3-AC-F023-1, V3-AC-F023-2 |
| V3-F052 | NEW:N3 | V3-E0 | Merge kuyruğu / birleşik CI | NONE (V3.1 yeni Feature) | P2 | 2 | V3-AC-F052-1, V3-AC-F052-2 |
| V3-F053 | NEW:N4 | V3-E0 | Ledger ↔ Founder-authority köprüsü | NONE (V3.1 yeni Feature) | P1 | 1 | V3-AC-F053-1 |
| V3-F054 | NEW:N5 | V3-E0 | CI sonuç provenance'ı ve shard toplama | NONE (V3.1 yeni Feature) | P0 | 3 | V3-AC-F054-1, V3-AC-F054-2, V3-AC-F054-3 |
| V3-F001 | UASCO-F001 | V3-E1 | Electron kabuğu + paketli backend başlatma | VERIFIED_REAL_ENV (yalnız CI runner) | P2 | 5 | V3-AC-F001-1, V3-AC-F001-2, V3-AC-F001-3 |
| V3-F002 | UASCO-F002 | V3-E1 | UI kabuğu ve renderer → Control API | INTEGRATED + TESTED(unit) | P2 | 4 | V3-AC-F002-1, V3-AC-F002-2, V3-AC-F002-3 |
| V3-F010 | UASCO-F010 | V3-E1 | Güncelleme ve geri alma | PLANNED (manuel NSIS hook CODED) | P4 | 2 | V3-AC-F010-1, V3-AC-F010-2 |
| V3-F039 | UASCO-F039 | V3-E1 | Windows installer build | VERIFIED_REAL_ENV (CI); release yok | P1 | 1 | V3-AC-F039-1, V3-AC-F039-2 |
| V3-F040 | UASCO-F040 | V3-E1 | İmzalı sürüm | yok | P2 | 1 | V3-AC-F040-1 |
| V3-F003 | UASCO-F003 | V3-E2 | Intake ve tek komut alanı | INTEGRATED + TESTED(unit) (form); komut alanı PLANNED | P2 | 3 | V3-AC-F003-1, V3-AC-F003-2 |
| V3-F004 | UASCO-F004 | V3-E2 | Görev/plan/çalıştırma ekranları ve Founder akışı | INTEGRATED + TESTED(unit); Linux Electron CLAIMED | P1 | 3 | V3-AC-F004-1 |
| V3-F007 | UASCO-F007 | V3-E2 | Ses girişi | PLANNED | P4 | 1 | V3-AC-F007-1 |
| V3-F011 | UASCO-F011 | V3-E2 | Pre-dev zinciri (BA, Requirements, Architecture, Plan, UxSpec) | TESTED(unit), sahte builder | P2 | 3 | V3-AC-F011-1, V3-AC-F011-2 |
| V3-F050 | NEW:N1 | V3-E2 | Ürün içi Epic → Feature → Task + AC hiyerarşisi | NONE (V3.1 yeni Feature) | P2 | 2 | V3-AC-F050-1, V3-AC-F050-2 |
| V3-F012 | UASCO-F012 | V3-E3 | Implement + review runner | INTEGRATED + TESTED(unit); bir kez canlı (2026-10-14) | P1 | 3 | V3-AC-F012-1, V3-AC-F012-2 |
| V3-F013 | UASCO-F013 | V3-E3 | Sandbox'ta test yürütme | Linux: CODED + CI; Windows: yok | P1 | 2 | V3-AC-F013-1, V3-AC-F013-2, V3-AC-F013-3 |
| V3-F014 | UASCO-F014 | V3-E3 | Güvenlik aşaması | TESTED(unit), sahte binary | P2 | 4 | V3-AC-F014-1, V3-AC-F014-2, V3-AC-F014-3 |
| V3-F029 | UASCO-F029 | V3-E3 | Test-surface bütünlük koruması | INTEGRATED + TESTED(unit) | BASE | 1 | V3-AC-F029-1 |
| V3-F005 | UASCO-F005 | V3-E4 | Teslim kartı ve dışa aktarma | CODED, Desktop export kırık | P1 | 2 | V3-AC-F005-1 |
| V3-F006 | UASCO-F006 | V3-E4 | Akıllı revizyon | PLANNED | P4 | 1 | V3-AC-F006-1 |
| V3-F015 | UASCO-F015 | V3-E4 | Kaynak teslimi ve kabul | INTEGRATED + TESTED(unit) | P1 | 2 | V3-AC-F015-1 |
| V3-F017 | UASCO-F017 | V3-E4 | Müşteri repo'suna PR teslimi | PLANNED | P3 | 2 | V3-AC-F017-1 |
| V3-F018 | UASCO-F018 | V3-E4 | Dokümantasyon üretimi | DESIGNED (registry) | P4 | 1 | V3-AC-F018-1 |
| V3-F057 | NEW:N8 | V3-E4 | Teslim doğrulama etiketleri ve bağımsız yeniden üretim | NONE (V3.1 yeni Feature) | P1 | 2 | V3-AC-F057-1, V3-AC-F057-2 |
| V3-F019 | UASCO-F019 | V3-E5 | Tek mission runner (lease, fencing, retry, remediation) | INTEGRATED + TESTED(unit) | P1 | 3 | V3-AC-F019-1, V3-AC-F019-2 |
| V3-F020 | UASCO-F020 | V3-E5 | Crew/team çalışma zamanı | CODED + TESTED(unit), bağlı değil | P3 | 2 | V3-AC-F020-1 |
| V3-F021 | UASCO-F021 | V3-E5 | Paralel çalışma ve görev dağıtımı | yok | P3 | 2 | V3-AC-F021-1 |
| V3-F022 | UASCO-F022 | V3-E5 | Duraklatma, devam, kurtarma | GLOBAL_STOP INTEGRATED | P2 | 4 | V3-AC-F022-1, V3-AC-F022-2 |
| V3-F024 | UASCO-F024 | V3-E5 | Rol bağlama ve hazırlık ölçümü | 9 rol bağlı; 6/21 V2 maddesi merge | P3 | 8 | V3-AC-F024-1 |
| V3-F025 | UASCO-F025 | V3-E5 | Claude CLI executor çifti ve ProviderPort | INTEGRATED; paketli uygulamada UNKNOWN | P1 | 3 | V3-AC-F025-1, V3-AC-F025-2 |
| V3-F026 | UASCO-F026 | V3-E5 | Model yönlendirme | CODED çekirdek, bağlı değil | P3 | 4 | V3-AC-F026-1, V3-AC-F026-2 |
| V3-F027 | UASCO-F027 | V3-E5 | Token/maliyet ölçümü | yok | P2 | 2 | V3-AC-F027-1, V3-AC-F027-2 |
| V3-F028 | UASCO-F028 | V3-E5 | Failover, ikinci sağlayıcı, yerel model | DESIGNED (OmniRoute yalnız keşif) | P3 | 3 | V3-AC-F028-1 |
| V3-F051 | NEW:N2 | V3-E5 | Görev güdümlü yürütme | NONE (V3.1 yeni Feature) | P3 | 2 | V3-AC-F051-1, V3-AC-F051-2 |
| V3-F055 | NEW:N6 | V3-E5 | Golden değerlendirme seti | NONE (V3.1 yeni Feature) | P2 | 2 | V3-AC-F055-1, V3-AC-F055-2 |
| V3-F009 | UASCO-F009 | V3-E6 | Masaüstü ve yürütme sertleştirmesi | TESTED(unit) + kısmen VERIFIED_REAL_ENV (CI) | P4 | 5 | V3-AC-F009-1, V3-AC-F009-2, V3-AC-F009-3 |
| V3-F032 | UASCO-F032 | V3-E6 | Action-gateway politikası | INTEGRATED, sabit ALLOW | P2 | 2 | V3-AC-F032-1 |
| V3-F056 | NEW:N7 | V3-E6 | Birleşik yetki matrisi | NONE (V3.1 yeni Feature) | P2 | 2 | V3-AC-F056-1, V3-AC-F056-2 |
| V3-F008 | UASCO-F008 | V3-E7 | Founder Cockpit: ilerleme, bildirim, rapor ve maliyet | INTEGRATED (in-app) | P4 | 3 | V3-AC-F008-1, V3-AC-F008-2, V3-AC-F008-3 |
| V3-F035 | UASCO-F035 | V3-E7 | Mobil tasarım ve salt-okur çekirdek | DESIGNED + TESTED(unit, local) | P4 | 3 | V3-AC-F035-1 |
| V3-F036 | UASCO-F036 | V3-E7 | Mobil uygulama ve gateway | DESIGNED | P4 | 4 | V3-AC-F036-1 |
| V3-F037 | UASCO-F037 | V3-E7 | Uzaktan onay ve STOP | DESIGNED | P4 | 1 | V3-AC-F037-1 |
| V3-F016 | UASCO-F016 | V3-E8 | Müşteri stack, şablon ve yaşam döngüsü | 3 basit Node şablonu | P4 | 3 | V3-AC-F016-1, V3-AC-F016-2, V3-AC-F016-3 |

### 3.4 Zincir: Epic → Feature → Task → AC → Test Evidence → Product Delivery

```
V3-E# (kullanılabilir sonuç)
 └─ V3-F### (yetenek; done = §3.5)
     ├─ V3-AC-### (ölçülebilir kabul ölçütü; Given/When/Then + ortam + eşik)
     │    └─ V3-EV-#### (kanıt kaydı)
     └─ V3-T#### (iş birimi; PR'a bağlı)
          └─ PR / merge SHA / CI run (otomatik eşlenir)
Product Delivery = bir Demo Senaryosu (DS-*), bir release kapısının AC'lerinin kurulu build'de birlikte geçmesi
```

Her Feature için bu zincir makine-okunur olarak var: `feature.acceptanceCriteria[]` → `ac.evidenceId` → `ac.deliveryScenario`; `task.v3Feature` + `task.acId` + `task.evidenceId`. 102 AC'nin 102'si en az bir Task tarafından karşılanıyor (doğrulama betiği: kapsanmayan AC = 0, döngü = 0, eksik referans = 0).

**Tek kayıt (RW-014 + W8), PROPOSAL:**

- Biçim: tek makine-okunur dosya. Supervisor'a ait, protected, CI'sız bir dalda tutulur (örnek: `uasco/register` → `REGISTER.json`). İnsanlar için Markdown görünümü bundan üretilir; elle düzenlenmez.
- Yazanlar: (a) merge olayı (PR başlığı ya da gövdesindeki `V3-T####` → Task DONE adayı), (b) CI kanıt üreticisi (V3-EV), (c) Founder kabulleri (attestation). Bunların dışında yazan yok.
- Doğrulama: her merge'de `register verify` çalışır. Kuralları: Task'sız merged PR = 0 ve AC'siz Feature = 0. Durum sözlüğü dışında durum = 0.
- Kanıt kaydı alanları: `{id, acId, level, env{os, build, installerSha256, sandbox}, scenario, command, result, artifactDigest, producedBy(runId|founderAttestation), at, retainedUntil}`. Özet her zaman register dalına yazılır, çünkü Actions artifact'ları siliniyor (RW-048).

### 3.5 Gerçek tamamlanma kuralları

| Seviye | COMPLETE sayılması için | COMPLETE sayılmaz |
| --- | --- | --- |
| **Task** | Merge edilmiş + kendi kapsamındaki testler CI'da (merge kuyruğu SHA'sında) yeşil + bağlı AC için en az bir V3-EV kaydı (TESTED ya da üstü) | Yalnız PR açılmış, yalnız review CLEAN, yalnız "done" yazılmış |
| **Feature → ACCEPTED** | Bütün AC'leri **VERIFIED_REAL_ENV** seviyesinde geçiyor: kurulu build'de, AC'nin belirttiği ortamda, gerçek modelle (model gerekiyorsa), kanıt saklanmış, AC sahibinin kabul kaydı var | Kod yazılmış, merge edilmiş, unit testi geçmiş, sahte executor'la geçmiş, yalnız Linux'ta geçmiş |
| **Feature → STABLE_7D** | ACCEPTED + 7 gün boyunca ilgili L3 koşuları yeşil, gerileme yok. Release'in "bitti" sayılması için STABLE_7D aranır; ACCEPTED tek başına yeterli değil | ACCEPTED olup L3'te izlenmeyen Feature |
| **Epic** | Kullanılabilir sonucu **USABLE_BY_END_USER**, Epic'e özgü senaryo ve tekrar kuralıyla (aşağıdaki tablo; V3'teki "bütün Epic'ler için 3 ardışık run" kuralı kaldırıldı) | Feature'ların hepsi ACCEPTED ama senaryo hiç uçtan uca koşmamış |
| **Faz** | Fazın kapı AC'leri (§10) + fazın maliyet sınırı aşılmamış + açık P0 = 0 | Planlanan madde sayısı tamamlanmış |

**Feature durum sözlüğü (V3.1):** `PLANNED → CODED → INTEGRATED → TESTED → VERIFIED_REAL_ENV → ACCEPTED → STABLE_7D`; gerilemede `REGRESSED` (bir önceki seviyeye düşer). Bugün ACCEPTED Feature sayısı **0**.

**Epic kabul kuralları (zorunlu düzeltme 9):**

| Epic | Senaryo | Kural | Release |
| --- | --- | --- | --- |
| V3-E0 | DS-OPS-01 | Zaman penceresi: 14 gün boyunca CI hedefi tutar, bütçe aşımı 0, kayıt sapması 0, SPOF duruşu 0 | R2 |
| V3-E1 | DS-R2-INSTALL | 2 farklı Windows makinesinde temiz kurulum + onarım + kaldırma, 1 upgrade; makine başına 1 kez | R2 |
| V3-E2 | DS-R2-SPEC | 3 farklı fikir (≥2 proje tipi); çeşitlilik tekrarın yerine geçer; Founder kalite puanı ≥ eşik | R2 |
| V3-E3 | DS-R1 + DS-R2-QA | R1: 3 ardışık run; R2: 5 run, ≥1 tohumlanmış hata remediation ile düzeltilmiş, ≥1 tohumlanmış secret yakalanmış | R2 |
| V3-E4 | DS-R1 + DS-R3-PR | R1: 3 ardışık teslim, her biri bağımsız yeniden üretimle; R3: 1 gerçek müşteri repo'suna PR | R3 |
| V3-E5 | DS-R3-ENGINE | İstatistiksel: arketip başına ≥20 eval vakası; 2 kota simülasyonu; 2 paralel run | R3 |
| V3-E6 | DS-SEC-NEG | Negatif test seti %100; her release'de 1 kez | R2 |
| V3-E7 | DS-R2-COCKPIT + DS-R4-MOBILE | 5 iş günü Cockpit kullanım kaydı; mobil STOP 1 kez + replay negatif | R4 |
| V3-E8 | DS-R3-STACK2 + DS-R4-DEPLOY | Stack başına 1 uçtan uca; deploy kapsamı varsa deploy + rollback + izleme | R4 |

NOT_RUN_ENV_UNAVAILABLE ve SKIPPED hiçbir zaman PASS sayılmaz (mevcut kural korunuyor). FAKE executor kanıtı en fazla TESTED(unit) sayılır.

---

## 4. Öncelik ve bağımlılık grafiği

### 4.1 Faz grafiği

```mermaid
flowchart LR
  P0["P0 Stabilize ve konsolide et<br/>(E0)"] --> G0{{"Kapı G0"}}
  G0 --> P1["P1 Founder Alpha<br/>ilk gerçek uçtan uca<br/>(E1·E3·E4 çekirdek)"]
  P1 --> G1{{"Kapı G1 = R1"}}
  G1 --> P2["P2 Güvenilir Beta<br/>ikinci kullanıcı<br/>(E1·E2·E6·E0-güven)"]
  P2 --> G2{{"Kapı G2 = R2"}}
  G2 --> P3["P3 Verimli fabrika<br/>görev güdümlü, çoklu model, paralel<br/>(E5·E4-PR)"]
  P3 --> G3{{"Kapı G3 = R3"}}
  G3 --> P4["P4 Tam yaşam döngüsü<br/>deploy, doküman, revizyon, mobil<br/>(E8·E7·E4)"]
  P4 --> P5["P5 Ölçek<br/>rol genişliği (E5/E8)"]
  P0 -.paralel izinli.-> P1
```

**V3.1 P0 ayrımı (zorunlu düzeltme 4):**

- **P0-CRIT** (R1'i bloke eder, 11 Task, 33.5–82 h): store-lock düzeltmesi (V3-T1001), shard provenance (V3-T1002/1003/1036), minimal bütçe koruması (UASCO-T0110), ileriye dönük register (UASCO-T0119, V3-T1005/1006), kanıt digest'i (UASCO-T0124), runner kontrolü (UASCO-T0103), rutin gözlemi (UASCO-T0115).
- **P0-PAR** (R1'i bloke etmez, 11 Task, 9.8–30 h): kararlar ve hijyen (heartbeat, rutin prompt'ları, #66/#251/#247 kararları, base-red politikası, seri merge kuralı, IR kararı).
- **P2'ye taşınan:** tarihsel 168 PR'ın geriye dönük eşlemesi (V3-T1021, gating değil). Eski kayıtlar LEGACY_BASELINE olarak dondurulur (V3-T1006); yeni merge'ler için tam izlenebilirlik zorunludur (V3-T1005).

P1, P0-CRIT bittiği anda başlayabilir; P0-PAR paralel sürer.

### 4.2 R1 için kritik yol (seri)

```mermaid
flowchart TD
  A["P0-CRIT: store-lock + shard provenance<br/>(V3-T1001/1002/1003/1036)"] --> A2["CI kararlılığı<br/>UASCO-T0088"]
  B["RW-006 korunan yol kapsamı<br/>reseal batch 1 (#251/#247)<br/>UASCO-T0069"] --> C["RW-004 #231 rebase + delta review<br/>reseal batch 2<br/>UASCO-T0031"]
  C --> D["FA-5 Windows 11 + WSL2<br/>gerçek kabul (Founder-PC)"]
  B --> E["RW-009 Export düzeltmesi<br/>(main.mjs korumalı)"]
  F["RW-011 Installer pilotu<br/>Founder-PC"] --> G["RW-010 PATH / Claude CLI keşfi"]
  A --> F
  A2 --> H
  D --> H["UASCO-T0029 / T0014 / T0035<br/>3 ardışık gerçek uçtan uca + üç bağımsız kabul"]
  E --> H
  G --> H
  H --> R1(["R1 Founder Alpha"])
```

- **V3.1 hesaplanan en uzun zincir (Task bazında):** UASCO-T0069 → UASCO-T0031 → UASCO-T0029 → UASCO-T0014 → UASCO-T0035 = 54–154 h (ESTIMATE). R1 kapanış kümesi (kritik Task'lar + bütün öncülleri) 29 Task, 125–342 h.
- **En uzun halka:** RW-004 (40–120 h, ESTIMATE) + FA-5. Bu halka Founder-PC'ye ve WSL2'ye bağlı. Bulut ajanı bu kabul testini kendisi yapamaz.
- **En çok işi bloke eden maddeler:** RW-006 (8 madde bekliyor), RW-005 (7), RW-015 (5), RW-014 (3).
- **R1 için kritik yolda olmayanlar:** komut alanı, model routing, crew, mobil, imzalı release, ikinci sağlayıcı. Bunlar bilinçli olarak R1'in dışında tutuluyor.

### 4.2.1 R1 kapanış kümesi (Task bazında)

| Task | V3 Feature | Faz | Ad | Bitiş ölçütü | Bağımlılık | Efor h |
|---|---|---|---|---|---|---|
| UASCO-T0103 | V3-F044 | P0 | Runner kontrolü | Founder Settings > Actions > Runners'da 0 runner görür veya kaldırır; ekran görüntüsü/kayıt eklenir. | — | 0.25–0.5 |
| UASCO-T0110 | V3-F046 | P0 | Bütçe ve USAGE_LIMIT | USAGE_LIMIT simülasyonunda pause kaydı yazılır, bekleyen tick ≤1; Founder bütçe kararı (D-08) kayıtlı | UASCO-T0115 | 4–10 |
| UASCO-T0115 | V3-F047 | P0 | http_api rutinleri | get_trigger: iki http_api rutini enabled=false ve 2026-11-03T05:40Z'ye kadar last_fired değişmedi | — | 0.25–0.5 |
| UASCO-T0119 | V3-F048 | P0 | Tek görev kaydı | Baseline sonrası her yeni merge bir V3-T'ye bağlı; register verify istisna = 0 | V3-T1006, V3-T1005, UASCO-T0120 | 6–12 |
| UASCO-T0120 | V3-F048 | P0 | Tek roadmap | Founder D-01 kararı kayıtlı; V3.1 (ya da halefi) tek kanonik plan; eski planlar ARCHIVED işaretli | — | 2.0–6.0 |
| UASCO-T0124 | V3-F049 | P0 | Kanıt digest manifesti | Merge geçmişindeki SHA-bound evidence artifact'ları için digest + özet manifest repo'da; HEAD installer artifact'ı süresi dolmadan güvenli saklanır. | — | 3.0–8.0 |
| V3-T1001 | V3-F038 | P0 | Store-lock sıfır-bayt kilit kurtarma (TD-V2-06) | Deterministik Windows testi: öldürülen yazar sonrası LOCK_TIMEOUT yok; relfx-1:459 ailesi 20 base push'ta 0 | — | 8–20 |
| V3-T1002 | V3-F054 | P0 | Provenance kontrollü shard aggregator | Negatif testler: farklı SHA, farklı run_id, farklı partition reddedilir; aynı run_id içindeki attempt'ler doğru birleşir | — | 4–10 |
| V3-T1003 | V3-F054 | P0 | Shard verdict ↔ GitHub job conclusion çapraz kontrolü | Sahte PASS raporu + failure job conclusion senaryosu FAIL verir; PASS_AFTER_RETRY etiketi görünür | V3-T1002 | 2–6 |
| V3-T1005 | V3-F048 | P0 | PR şablonu + V3-T kimliği zorunlu check | Kimliksiz PR merge kuyruğuna alınmaz (negatif test) | V3-T1006 | 3–8 |
| V3-T1006 | V3-F048 | P0 | LEGACY_BASELINE snapshot'ı | Snapshot sha256 register'da; sonraki register verify baseline'ı değiştirmez | — | 1–3 |
| V3-T1036 | V3-F054 | P0 | Attempt geçmişi ve PASS_AFTER_RETRY raporu | 'Re-run failed jobs' senaryosunda önceki FAIL kayıtlı, verdict doğru; FAIL→PASS shard PASS_AFTER_RETRY | V3-T1002 | 2–4 |
| UASCO-T0002 | V3-F001 | P1 | Founder-PC kurulum pilotu | Founder-PC kontrol listesi PASS kaydı: interaktif kurulum, varsayılan dizin, kısayollar, SmartScreen notu, ilk açılış, aynı sürüm onarım, kaldırma (veri koru ve sil). | V3-T1019 | 2.0–6.0 |
| UASCO-T0003 | V3-F001 | P1 | Paketli uygulamada PATH/Claude CLI keşfi | Kurulu uygulamada GET /v1/system/executors LOCAL_CLAUDE için READY döner (CLI_NOT_FOUND değil); PATH sözleşmesi testi Windows davranışına göre güncellenir. | UASCO-T0002 | 1.0–4.0 |
| UASCO-T0014 | V3-F004 | P1 | Gerçek ortamda Founder akışı | 3 ardışık run; elle dosya düzenleme = 0; her run için V3-EV kaydı | UASCO-T0029, UASCO-T0016, V3-T1013, UASCO-T0031, UASCO-T0003, UASCO-T0061, UASCO-T0002 | 3.2–8.0 |
| UASCO-T0016 | V3-F005 | P1 | Desktop export düzeltmesi | Scrubber+export birleşik testi iki OS'ta geçer; installer CI job'unda kurulu uygulamadan export bir ZIP üretir ve sha256 eşleşir. | UASCO-T0069 | 3.0–8.0 |
| UASCO-T0029 | V3-F012 | P1 | Windows'ta gerçek implement + verify | 3 ardışık run'da VERIFY=PASSED (sandbox), review CLEAN; kanıt V3-EV | UASCO-T0031, UASCO-T0003, UASCO-T0061, UASCO-T0016, UASCO-T0002 | 3.2–8.0 |
| UASCO-T0031 | V3-F013 | P1 | Windows sağlayıcısı (#231) | Sağlayıcı merge; kurulu uygulamada (Founder-PC, Windows 11) bir projenin testCommand'ı sandbox içinde çalışır ve evidence PASSED/FAILED döner (NOT_EXECUTED değil); negatif testler (ağ çıkışı, workspace dışı yazma) reddedilir. | UASCO-T0069 | 40.0–120.0 |
| UASCO-T0035 | V3-F015 | P1 | Founder kabulü gerçek ortamda | 3/3 run'da TEST/SECURITY/DELIVERY kabul kayıtları ayrı; etiket V3-F057 kuralıyla türetildi | UASCO-T0014, V3-T1011, V3-T1012, V3-T1010, UASCO-T0031, UASCO-T0016, UASCO-T0003, UASCO-T0061, UASCO-T0002 | 3.2–8.0 |
| UASCO-T0044 | V3-F019 | P1 | Gerçek ortamda remediation döngüsü | ≥1 gerçek run'da remediation sonrası VERIFY=PASSED; döngü sayısı kayıtlı | UASCO-T0029, UASCO-T0031, UASCO-T0016, UASCO-T0003, UASCO-T0061, UASCO-T0002 | 3.2–8.0 |
| UASCO-T0061 | V3-F025 | P1 | Paketli uygulamada READY durumu | Kurulu uygulamada LOCAL_CLAUDE READY (Founder-PC kanıtı) | UASCO-T0003, UASCO-T0002 | 1.0–4.0 |
| UASCO-T0069 | V3-F030 | P1 | Korunan yol kapsamı | config/protected-paths.json bu yolları (execution-gate.ts, linux-unshare-sandbox.ts, runner.ts, security-tools.ts, claude-profiles.ts, core/action-gateway/** dahil) kapsar; trust root yeniden mühürlenir ve verifyTrustRoot ok; bunlardan birine dokunan test PR'ı gate'te bloklanır. | — | 4.0–10.0 |
| UASCO-T0088 | V3-F038 | P1 | Kararlılık ≥%95 | 20 ardışık base push'ta bilinen-flake kırmızısı 0; karantina listesi sahipli ve süreli | V3-T1001, V3-T1002 | 8–20 |
| V3-T1010 | V3-F014 | P1 | SEC-PROFILE-R1 araç sağlama | Kurulu ortamda araç hash'leri doğrulandı; tohumlanmış secret yakalandı | UASCO-T0002 | 4–12 |
| V3-T1011 | V3-F057 | P1 | Üç bağımsız kabulden teslim etiketi türetme | Negatif test: SECURITY PARTIAL iken PRODUCT_VERIFIED_LOCAL verilmez | UASCO-T0016 | 4–10 |
| V3-T1012 | V3-F057 | P1 | Bağımsız yeniden üretim script'i | Script örnek teslimde geçer; bozulmuş ZIP'te FAIL | — | 2–6 |
| V3-T1013 | V3-F011 | P1 | Gerçek modelle pre-dev koşusu (R1 projeleri) | Artifact hash'leri ve model çıktısı journal'da; Founder APPROVED | UASCO-T0003 | 4–12 |
| V3-T1018 | V3-F022 | P1 | R1 negatif senaryoları | STOP → CANCELLED; sağlayıcı hatası → açık BLOCKED; kanıt V3-EV | UASCO-T0029 | 3–8 |
| V3-T1019 | V3-F001 | P1 | Founder-PC R1 ortam kontrol listesi | Liste PASS kaydı; eksik yoksa FA-5'e geçilir | — | 1–2 |

### 4.3 Paralel yürüyebilecek bağımsız iş blokları

| Blok | İçerik | Neye bağlı | Neyle çakışır |
| --- | --- | --- | --- |
| PAR-1 Kayıt ve bütçe | RW-014, RW-018, RW-003, RW-046, RW-019, RW-020, RW-048 | Hiçbir ürün işine bağlı değil | Yalnız supervisor dosyaları |
| PAR-2 CI kararlılığı | RW-013 (Windows flake), N5 (aggregator), N3 (merge kuyruğu), RW-061 | Protected workflow'lar için Founder onayı | `.github/workflows/*` (protected; tek lane) |
| PAR-3 Desktop paketleme | RW-009, RW-010, RW-011 desteği, RW-053 | RW-006 (main.mjs) | `apps/desktop/*` |
| PAR-4 Sandbox | RW-004 | RW-006 | `core/agents/*`, `apps/control-api/src/packaged-entry.ts` |
| PAR-5 Golden eval setinin hazırlığı (N6) | 9 bağlı rol için gerçek-model senaryoları | Yok (veri ve script işi) | `registries/`, `tests/eval/` |

### 4.4 Engeller

| Engel | Tür | Çözen |
| --- | --- | --- |
| Trust-root manifest çakışması (#251, #247, #231) | Founder-tier | FA-4: tek birleşik reseal kararı |
| Windows 11 + WSL2 gerçek ortam | Ortam | FA-5 (Founder-PC) |
| IR token reddi | Kimlik | FA-3, sonra §8.3 GitHub App |
| Haftalık kota | Kaynak | §9 bütçe ve kota planlayıcısı |
| Yerel V6 durumu UNKNOWN | Görünürlük | FD-07 |

---

## 5. İlk kullanılabilir ürün (R1 "Founder Alpha"): kesin kabul kriterleri

**Kapsam:** Tek kullanıcı (Founder), Windows 11 + WSL2, tek sağlayıcı (yerel Claude CLI, iki profil), iki proje tipi (`web-node`, `node-lib`), kaynak teslimi (ZIP). Deploy, PR teslimi ve komut alanı **yok**.

| AC | Kriter | Kanıt (V3-EV) | Eşik |
| --- | --- | --- | --- |
| R1-AC1 | CI'da üretilen installer (sha256 kayıtlı) Founder-PC'ye kurulur, açılır, backend HEALTHY olur, Claude CLI bulunur | Installer sha256, ekran görüntüsü ya da tanılama JSON'u, sürüm | 1/1 |
| R1-AC2 | Intake formu → gerçek modelle BA, Requirements, Architecture ve Plan artifact'ları → her biri Founder tarafından APPROVED | Journal kayıtları (gerçek model; FAKE değil), artifact hash'leri | 3/3 çalıştırma |
| R1-AC3 | Plan → görevler → implement + review → **VERIFY=PASSED, WSL2 sandbox içinde** (NOT_EXECUTED değil) | Run kanıtı; sandbox sağlayıcı kimliği; test çıktısı digest'i | 3/3 |
| R1-AC4 | **SEC-PROFILE-R1** (yerleşik secret scan + pinned gitleaks + SCA) gerçek binary ile çalışır ve temizdir → SECURITY_ACCEPTED. Araç eksikse ya da sonuç PARTIAL ise R1 kabulü **geçmez**: teslim etiketi DELIVERED_SECURITY_PARTIAL olur, PRODUCT_VERIFIED_LOCAL olmaz (V3.1 değişikliği; V3'te PARTIAL kabul ediliyordu) | security-report.json + araç hash'leri (V3-EV-F014-1) | 3/3 |
| R1-AC5 | Desktop "Export delivery package" düğmesi ZIP üretir; sha256 kaydedilir. Teslim etiketi yalnız üç **ayrı** kayıttan türetilir: TEST_ACCEPTED (R1-AC3), SECURITY_ACCEPTED (R1-AC4), DELIVERY_ACCEPTED (R1-AC6 + SOURCE_DELIVERY_ACCEPTED). Biri eksikse PRODUCT_VERIFIED_LOCAL verilmez (negatif test) | V3-EV-F005-1, V3-EV-F057-1 | 3/3 |
| R1-AC6 | **Bağımsız yeniden üretim:** teslim ZIP'i temiz bir dizine açılır, UASCO dışında `npm ci && npm test` geçer (script ile, insan müdahalesi olmadan) | Ayrı doğrulama script'inin çıktısı | 3/3 |
| R1-AC7 | Çalıştırmalar ardışık. En az 1 `web-node` ve 1 `node-lib`. Founder çalıştırma sırasında dosya düzenlemedi; müdahale yalnız onay olarak sayılır | Müdahale sayacı (journal) | 3 ardışık; elle düzenleme = 0 |
| R1-AC8 | Negatif testler: STOP çalışan run'ı CANCELLED yapar; sağlayıcı hatası ya da kota run'ı açık bir BLOCKED nedeni ile durdurur (sessiz başarısızlık yok) | İki negatif senaryonun kanıtı | 2/2 |
| R1-AC9 | Run başına süre, CLI'nin raporladığı token ya da maliyet (varsa) ve remediation tur sayısı kaydedilir. Ölçülemeyen alan UNKNOWN olarak etiketlenir | Run özeti | 3/3 |
| R1-AC11 | En az 1 gerçek run'da tohumlanmış başarısız test remediation döngüsüyle düzeltilir | V3-EV-F019-2 | ≥1 |
| R1-AC10 | Geliştirme düzlemi: R1 süresince 10 ardışık push CI yeşil, npm audit moderate+ = 0, haftalık bütçe aşılmadı | CI run listesi, bütçe kaydı | — |

**Demo senaryosu (R1-DEMO):** "Görev listesi REST API'si (Express, testli)". Founder'ın ekranında sırasıyla: kur → intake → 4 onay → kodlama ve test (canlı ilerleme) → teslim → ZIP'i aç ve `npm test` yeşil. İkinci demo `node-lib` ile aynı akış.

**R1'in bilinçli olarak içermedikleri:** imza (SmartScreen uyarısı kabul edilir), auto-update, ikinci kullanıcı, çoklu model, paralel run, PR teslimi, tek komut alanı, ürün içi Epic hiyerarşisi, görev güdümlü yürütme.

**R1 release kapısı = 52 AC** (`releaseGate = R1`; bunların 9'u mevcut testlerin REGRESSION AC'si). Kapı "R1 bitti" ise ayrıca R1 Feature'larının STABLE_7D olmasını ister.

### 5.1 R1 ile hedeflenen otonom AI Software Factory arasındaki yetenek ayrımı (zorunlu düzeltme 7)

| Yetenek | R1 Founder Alpha | En erken güvenilir sürüm | Neden daha erken değil | Hedef fabrika (nihai) |
| --- | --- | --- | --- | --- |
| Komut girişi | Yapılandırılmış intake formu | **Minimum tek komut alanı: R2** (UASCO-T0011; komut → DRAFT önerisi, asla authorize etmez, netleştirme sorusu) | Komut alanının çıktısı ancak R1'de gerçek uçtan uca kanıtlanmış hatta beslenirse anlamlı; alan R1 kritik yolunda değil | Doğal dil + ses + revizyon diyaloğu (P4) |
| İş analizi / gereksinim / mimari | Gerçek modelle pre-dev, Founder onaylı (kalite ölçülmüyor) | Kalite rubric'iyle **R2** | Rubric eşiği gerçek çıktılar görülmeden belirlenemez | Eval-sertifikalı arketipler |
| Epic → Feature → Task + AC üretimi | Yok; Plan → görev listesi | **R2** (V3-F050; şema + Desktop onayı) | Pre-dev'in gerçek modelle çalıştığı R1'de kanıtlanmalı | Revizyon döngüsü, izlenebilirlik görünümü |
| Görev tabanlı yürütme | Mission seviyesinde tek run | **R3** (V3-F051; görev DAG'ı + Task başına kanıt + alt lease) | Hiyerarşi (R2) ve Task başına AC olmadan görev DAG'ının neyi doğrulayacağı tanımsız | Paralel crew, otomatik dağıtım |
| Ajan seçimi | 9 statik rol | Arketip + paket, eval ile **R2/R3** | Golden eval (R1 v0) gerekli | Ölçümle terfi eden rol kataloğu |
| Model seçimi | Tek sağlayıcı (Claude CLI) | Model id kaydı **R2**, routing **R3**, failover **R3** | Ölçüm ve eval altyapısı önce | Maliyet/risk tabanlı çok sağlayıcı |
| Test / güvenlik | WSL2 sandbox, SEC-PROFILE-R1 | SAST + SBOM **R2** | Araç paketleme ve CI süresi | Tam SAST/DAST/SCA/SBOM |
| Teslim | ZIP + bağımsız yeniden üretim | Müşteri repo'suna PR **R3** | Kimlik/onay modeli (V3-F056) önce | PR → merge → deploy → izleme |
| Görünürlük | Mevcut ekranlar | Founder Cockpit (maliyet, onay kuyruğu) **R2** | Ölçüm verisi (V3-F027) önce | Canlı Cockpit + mobil |
| Otonomi düzeyi | **L1**: her aşama Founder onaylı, tek run | L2 (R2): Feature onaylı, Task'lar otomatik | — | L3–L4: bütçe ve risk sınırında otonom portföy |

---

## 6. Paralel geliştirme hatları ve görev dağılımı

**İlke (PROPOSAL):** Lane dosya sahipliğine göre bölünür. İki lane aynı dosyaya dokunacaksa iş merge kuyruğunda seri olarak birleşir (M.3 dersi). Builder cap fazın kapı metriğine göre açılır; takvime göre açılmaz.

| Faz | Hatlar | Görev dağılımı |
| --- | --- | --- |
| **P0** (V3.1: P0-CRIT / P0-PAR) | Supervisor (kısa ömürlü oturumlar) + Lane B + Founder | **Supervisor:** RW-014 kayıt, RW-018/RW-003 bütçe, RW-020 rutin prompt'ları, RW-048 kanıt saklama, RW-047 Founder kuyruğu, RW-060 review yolunu teke indirme. **Lane B:** V3-T1001 store-lock, V3-T1002/1003/1036 shard provenance (#251 ile birleşir), UASCO-T0088 flake karantinası; #282 DEFER (UASCO-T0090). Merge kuyruğu P2'ye (V3-T1020); P0'da yalnız ara seri kural (V3-T1008). **Founder:** FA-1..FA-9, §12 kararları |
| **P1** | Lane A + Lane B + Founder (+ supervisor) | **Lane A** (`apps/desktop`, installer): RW-009, RW-010, RW-011 hazırlığı, R1-AC6 doğrulama script'i, N8 etiketi (UI kısmı). **Lane B** (`core/agents`, `control-api`): RW-004 rebase + delta review, W4/N8 (sunucu kısmı), R1-AC8 negatif testleri. **Founder:** RW-006 reseal onayı, FA-5 WSL2 kabulü, R1 demo koşuları. **PAR-5** (N6 hazırlığı) boşta kalan kapasiteyle |
| **P2** | Lane A (Desktop UX) + Lane B (Motor) + Lane C (Güven/QA/CI) | **A:** RW-025 komut alanı, RW-050 güncelleme, RW-022 imzalı release, RW-051, RW-052, RW-066. **B:** N1 ürün içi hiyerarşi, RW-032 ölçüm, RW-036 (yalnız model id kaydı), RW-057 duraklatma/devam, RW-026 pre-dev kalitesi, RW-054 müşteri repo'su (P3'e kayabilir). **C:** RW-023 + RW-008 kimlik ayrımı (GitHub App), RW-029 imzalı trust root, RW-031 gerçek SAST, RW-024 Windows E2E CI, RW-028 politika bağlamı, RW-030, RW-062–065 |
| **P3** | A + B + C (+ D: teslim) | **B:** N2 görev güdümlü yürütme, RW-033 crew, RW-034 paralel, RW-035 zorunlu lease. **C:** RW-037 failover/yerel model (eval ile). **D:** RW-054 PR teslimi, RW-027 ikinci stack, RW-070 dokümantasyon |
| **P4+** | + Mobil lane (yalnız G3 sonrası) | RW-038–041, RW-069, RW-067, RW-073, RW-068, RW-074, RW-075 |

---

## 7. CI, test, güvenlik ve merge stratejisi

### 7.1 Katmanlı CI (PROPOSAL)

| Katman | Ne zaman | Ne koşar | Amaç |
| --- | --- | --- | --- |
| L0 | Builder push öncesi (lokal ya da bulut sandbox) | lint, typecheck, etkilenen unit testler (import grafiğinden) | Kırmızı push'u kaynağında durdurmak |
| L1 | PR (draft dahil değil) | ubuntu tam + Windows shard'ları **yalnız Windows'a duyarlı yollar değiştiyse** (desktop, installer, sandbox, fs, journal) + installer build (yalnız ilgili yollarda) | Hızlı ve odaklı geri bildirim |
| L2 | Merge kuyruğu (`merge_group` SHA) | ubuntu tam + 3 Windows shard + installer + register verify | **Birleşik SHA**'da entegrasyon kanıtı (M.3 sınıfı hataları yakalar) |
| L3 | Gece (ya da her N merge'de bir) | Windows Electron journey E2E, gerçek gitleaks/trivy/semgrep, golden eval alt kümesi, flake raporu | Feature'ların VERIFIED_REAL_ENV seviyesini ve gerileme durumunu korumak |

Gereksiz tekrarı azaltan kurallar:

- **Base kırmızıysa merge durur, geliştirme durmaz (V3.1, D-17):** bağımsız işler branch'lerde sürer ve PR hazırlanır. Draft PR'larda yalnız L0 koşar. Ready PR'larda L1 koşabilir ama sonucu "base red" etiketiyle kaydedilir ve merge kuyruğuna alınmaz. Base düzeldiğinde PR'lar güncellenir ve L2'den geçer. V3'teki "lane push'larını dondur" kuralı kaldırıldı; amaç CI israfını önlemekti ve bu artık draft-L0 kuralıyla sağlanıyor.
- `concurrency: cancel-in-progress` her PR'da açık.
- Yalnız doküman ve rapor değiştiren PR'larda Windows çalışmaz.
- Aynı SHA için CI sonucu yeniden kullanılır.
- "Re-run failed jobs" yerine aggregator düzeltilir (N5).

### 7.2 Flake politikası

- Otomatik yeniden deneme en fazla 1. Yeniden denemeyle geçen test "PASS" değil, **"PASS_AFTER_RETRY"** olarak kaydedilir ve flake sayacına eklenir.
- Karantina listesi protected, sahipli ve süreli (ör. 14 gün). Karantinadaki test L3'te koşmaya devam eder. Karantinaya almak testi kaldırmak ya da zayıflatmak demek değil (CLAUDE.md sınırı).
- Windows zamanlama testleri (PAR-03, F-B1-006 eşzamanlı journal yazarları) deterministik saate ya da senkronizasyon noktalarına taşınır (RW-013).
- Hedef: L2 flake oranı ≤ %2. PR CI pass oranı ≥ %95 (bugün %72,6).

### 7.3 Merge kuyruğu stratejisi (N3, W7)

**Seçenek A:** GitHub native merge queue. Ruleset "require merge queue" olarak ayarlanır; L2 `merge_group` olayında koşar. **V3.1 notu:** Bu seçeneğin bu kişisel hesap reposunda kullanılabilir olduğu doğrulanmadı (UNVERIFIED; D-04). Doğrulanana kadar önerilen yol değildir.

- Review bağlılığı: ledger kaydı PR head SHA'sına bağlıdır. Kuyruk SHA'sı farklı olacağı için kural şöyle: kuyruk girdisinin diff'i (patch-id) gözden geçirilmiş head ile aynıysa review geçerli kalır. Değilse BASE_MERGE_ONLY zinciri uygulanır (mevcut ledger mantığı).
- Batch boyutu 1–3. Kırmızı batch otomatik ikiye bölünür (bisect). Protected-tier PR'lar tek başına girer.
- Aynı dosyaya dokunan iki PR, aynı batch'te olsa bile birleşik SHA'da test edilmiş olur.

**Seçenek B:** Ruleset'te "branch up to date" zorunluluğu (FD-E) + supervisor'ın sürdüğü seri tren (ledger tabanlı). Her merge'den önce `update-branch` + tam L2. Daha yavaş ama ek GitHub özelliği gerektirmez. P0'da ara kural olarak yalnız dosya kümesi çakışan PR'lar seri merge edilir (V3-T1008).

**Ön koşullar:** Founder'ın ruleset değişikliği (D-04) ve L2 süresinin kısalması. Bugün PR CI medyanı 26,9 dk, p90 54,2 dk. Hedef L2 p90 ≤ 35 dk.

### 7.4 Güvenlik (geliştirme düzlemi)

- RW-006: CI'ı etkileyen bütün dosyalar korunur (workflow'lar, `scripts/ci/*`, vitest/vite config'leri (RW-030), `package.json` overrides). Ardından tek reseal.
- RW-029: Trust root repo dışında tutulan bir anahtarla imzalanır.
- RW-007: Self-hosted runner listesinin boş olduğu kanıtlanır. Public repo'da self-hosted runner kullanılmaz.
- RW-062: Dependabot, secret scanning ve code scanning açılır.
- Ürün güvenlik aşaması (V3-E3): FAKE scanner testleri kalır, L3'e gerçek araç koşusu eklenir. SBOM P2'de gelir.

### 7.5 Attempt'ler arası shard sonucu birleştirme: güvenlik değerlendirmesi (zorunlu düzeltme 6)

**Sorun (COORD-001):** Windows aggregator yalnız aynı attempt'in shard raporlarını okuyor. "Re-run failed jobs" sonrası diğer shard'ların raporları eski attempt'te kaldığı için aggregator her zaman FAIL veriyor. Naif düzeltme ("en son bulunan raporu al") yanlış PASS üretebilir.

| Risk | Nasıl yanlış PASS üretir | V3.1 kuralı (V3-F054) |
| --- | --- | --- |
| Farklı SHA'nın raporu | Başka bir run'ın (ör. önceki head ya da farklı merge ref) PASS raporu birleştirilir | Rapor `headSha` + (PR için) merge ref SHA'sı aggregator'ın SHA'sıyla aynı olmalı; değilse reddedilir |
| Farklı run_id | Farklı tetikleyici, farklı workflow sürümü | Yalnız **aynı run_id** içindeki attempt'ler birleşir; run_id'ler arası yeniden kullanım yok |
| Workflow ya da test kapsamı değişmiş | Shard bölümlemesi değişince bazı testler hiçbir shard'da koşmaz | Rapor `workflowBlobSha` ve `testManifestDigest`/shard-partition digest'ini taşır; aggregator bütün shard'ların aynı manifest'i kapsadığını ve birleşiminin tam manifest olduğunu doğrular |
| Rapor sahteciliği | Test edilen kod rapor dosyasını kendisi yazar; PR kodu sahte PASS raporu bırakabilir | Rapor verdict'i GitHub Actions API'deki **job conclusion** ile çapraz kontrol edilir; uyuşmazlık FAIL (V3-T1003) |
| Önceki başarısızlığın kaybolması | FAIL→PASS shard'ı temiz PASS gibi görünür; flake gizlenir | Shard başına attempt geçmişi rapora yazılır; FAIL→PASS shard'ı **PASS_AFTER_RETRY** olarak etiketlenir ve flake sayacına girer (V3-T1036) |
| Ortam farkı | Runner imajı ya da Node sürümü attempt'ler arasında değişebilir | Rapor runner image/Node sürümünü taşır; farklıysa uyarı kaydedilir. Merge kararını tek başına bloke etmez, flake analizine girer |

**Karar kuralı:** Aynı run_id'de her shard'ın en son attempt'i PASS ise ve provenance alanları eşleşiyorsa aggregator PASS verir. Herhangi bir shard'ın son attempt'i FAIL ise FAIL. PASS_AFTER_RETRY içeren sonuç merge için geçerlidir ama yalnız yeniden deneme politikası (≤1) içindeyse. İlgili test 14 gün içinde ikinci kez PASS_AFTER_RETRY olursa karantina incelemesine düşer. Korunan alanlar: `headSha, runId, runAttempt, jobId, workflowPath, workflowBlobSha, testManifestDigest, shardIndex, previousAttempts[], conclusionFromApi`.

---

## 8. Founder yetkisi, onaylar, güvenlik ve auto-merge: tek kontrol modeli

### 8.1 Bugünkü çakışmalar

1. GitHub environment onayı ile ledger merge-gate iki ayrı yetki kaydı ve aralarında köprü yok (M.1).
2. Ruleset 0 onay istiyor ve tek kimlik var. Bağımsız review GitHub tarafından zorlanmıyor.
3. Aynı kodu dört ayrı review mekanizması inceliyor: koordinatör TEP-1, ICR rutini, IR workflow, lane self-check.
4. Founder yetki talepleri serbest metin (47 adet). Sahibi ve son tarihi yok.

### 8.2 Birleşik yetki matrisi (N7, PROPOSAL)

Tek kaynak: `config/authority-matrix.json` (protected; V3-F056, V3-T1025). Hem CI gate'i hem ledger aynı değerlendiriciyi çağırır.

| Tier | Kapsam (örnek) | Gereken | Auto-merge |
| --- | --- | --- | --- |
| T0 | `docs/`, raporlar, register görünümleri | L1 yeşil | Evet |
| T1 | Ürün kodu, testler (protected olmayan yollar) | L2 yeşil + **bağımsız reviewer check** (ayrı GitHub App kimliği) NO_BLOCKERS + aynı SHA ya da patch-id | Evet (merge kuyruğu) |
| T2 | Protected yollar: workflow'lar, trust root, `package.json` deps/overrides, güvenlik politikası, sandbox sağlayıcıları, authority-matrix'in kendisi | T1 + **Founder onayı** (tek mekanizma: GitHub environment approval ya da Founder hesabının required review'u; ledger bunu API'den okur, N4) | Hayır. Founder onayından sonra kuyruğa otomatik girer |
| T3 | Ücretli API kullanımı, gerçek deploy, secret'lar, repo görünürlüğü, release imzalama, yeni sağlayıcı | Aksiyon başına Founder kararı, yazılı ve süreli. Kalıcı yetki verilmez | Hayır |

**Ürün düzlemi eşlemesi:** Intake'teki R0–R3 risk sınıfı aynı matrisle action-gateway'e bağlanır (W12). Örnek: R3 bir ürün aksiyonu (müşteri repo'suna push, deploy) her zaman insan onayı ister. Onay journal'a attestation olarak yazılır.

### 8.3 Kimlik ayrımı (RW-008, RW-023)

| Kimlik | Yapabildiği | Yapamadığı |
| --- | --- | --- |
| Builder App | Branch'e push, PR açma | Onay, merge, protected yol |
| Reviewer App | Check-run ve review yazma (salt-okur clone) | Push, merge |
| Supervisor (merge lane) | Merge kuyruğuna alma, ledger kaydı | Kod push'u, T2 onayı |
| Founder hesabı | T2 ve T3 onayları | — |

Review yolu teke iner (RW-060): Reviewer App, ledger kaydını üretir ve aynı kayıt check-run olarak görünür. ICR rutini ve ayrı koordinatör review'u kaldırılır. Lane self-check yalnız L0 olarak kalır. Bu düzen mevcut CLAUDE.md sözleşmesiyle uyumlu (governed CLAUDE_REVIEWER: taze, izole, salt-okur, exact commit). Değişen tek şey, review'un tek bir kimlikle ve tek bir kanıt yoluyla yapılması.

### 8.4 Founder kuyruğu (RW-047)

Her yetki talebinin standart alanları olur: tier, istenen aksiyon, etkilenen dosyalar, son tarih, varsayılan sonuç ve PR linki. Varsayılan sonuç "bekle" değil, "**park et ve kritik yol dışı işe geç**". Founder günde tek seferde toplu karar verir.

---

## 9. Ajan ve model yürütme mimarisi

### 9.1 Ürün düzlemi: 599 rolü aşamalı olarak yürütülebilir hâle getirmek

**Rol olgunluk merdiveni (PROPOSAL):** `CATALOG → PROFILED → BOUND → EVALUATED → CERTIFIED → PRODUCTION` (gerilemede bir alt seviyeye düşer).

- **EVALUATED:** Rolün golden eval seti (N6) gerçek modelle koşulmuş. Başarı oranı, maliyet ve süre ölçülmüş.
- **CERTIFIED:** Eşik geçilmiş (ör. ≥ %80 ve eşik Founder'ca onaylanmış) ve son 30 günde gerileme yok.

| Aşama | Faz | Hedef | Ölçüt |
| --- | --- | --- | --- |
| S1 | P1 | Bağlı 9 rol gerçek modelle çalışıyor | 9/9 EVALUATED (küçük set, rol başına ≥5 vaka) |
| S2 | P2 | **599 rol ~12–20 yürütülebilir arketipe katlanır.** Örnek arketipler: BA, gereksinim, mimar, planlayıcı, stack'e göre implementer, test yazarı, kod reviewer'ı, güvenlik reviewer'ı, DevOps, doküman, UX. Uzmanlık ayrı ajan olarak değil, arketipe eklenen **skill/context paketi** olarak gelir. | Her arketip EVALUATED; ≥6 CERTIFIED |
| S3 | P3 | composeTeam görev etiketlerine göre arketip ve paket seçer; crew sürücüsü bir mission'da ≥3 rol çalıştırır | AC-C3 |
| S4 | P5 | Kalan 599 profil ancak ölçülmüş bir fayda gösterirse paket olarak eklenir (eval'de iyileşme / maliyet). 363 legacy ajan eşlenir ya da arşivlenir | Eklenen paket başına pozitif eval etkisi |

**Kural:** Ajan sayısı bir hedef metrik değil. Bir rol ya da paket ancak eval başarısını artırıyor veya maliyeti düşürüyorsa eklenir.

### 9.2 Ürün düzlemi: model routing ve ücretsiz fallback

Routing girdileri: görev sınıfı, veri hassasiyeti, risk tier'ı, kalan bütçe, sağlayıcı sağlığı ve kotası.

| Katman | Kullanım | Örnek görev |
| --- | --- | --- |
| M0 Deterministik | Model yok | Şablon scaffold, delivery paketleme (bugünkü DETERMINISTIC_STUDIO) |
| M1 Hızlı / ucuz (küçük model ya da yerel) | Düşük riskli, kolay doğrulanabilen işler | Özet, lint düzeltme, doküman taslağı, commit mesajı |
| M2 Standart | Varsayılan implement ve review | Görev implementasyonu, kod review'u |
| M3 Derin | Yalnız gerekçeyle | Mimari, kritik güvenlik review'u, ikinci kez başarısız olan remediation |

**Fallback zinciri:** aynı sağlayıcıda alt katman → (Founder T3 onayı varsa) ikinci sağlayıcı → yerel ya da ücretsiz model (yalnız M0/M1 sınıfı ve eval ile sertifikalı görevler) → **BLOCKED_RESUMABLE** (checkpoint ile; RW-057).

**Bağımsızlık kuralı:** Fallback sonucunda reviewer implementer ile aynı model ve profile düşerse review "INDEPENDENCE_DEGRADED" olarak etiketlenir ve T1 merge'ü ya da teslim etiketi için yeterli sayılmaz.

**Kayıt:** Her adım için model id, katman, token, maliyet ve fallback nedeni journal'a yazılır (W10, W11).

**Belirsizlik notu:** Hangi yerel modelin, hangi ikinci sağlayıcının ve OmniRoute'un hangi sürümünün kullanılacağı bu taslakta seçilmedi. Hepsi eval ile doğrulanacak; mevcut bilgi güncel kabul edilmiyor.

**Erken mimari ön koşullar (zorunlu düzeltme 10).** Hiçbir sağlayıcı ya da yerel model entegrasyonu doğrulanmış sayılmaz. Bütün adaylar **UNVERIFIED_INTEGRATION** etiketini taşır; ancak V3-F055 eval kanıtıyla EVALUATED olur.

| Ön koşul | Faz | Task | Neden erken | Claude CLI bağımlılığını nasıl azaltır |
| --- | --- | --- | --- | --- |
| ProviderPort arayüzü (sağlayıcıya özgü kod tek modülde) | P1 | V3-T1014 | Sonraki her model işi bu sınıra bağlı; R1'i bozmadan yapılabilir | Yeni sağlayıcı = yeni adapter, hat kodu değişmez |
| CLI kullanım yakalama (token/maliyet ya da UNKNOWN) | P1 | V3-T1015 | Ölçüm olmadan routing ve bütçe kararı verilemez | Sağlayıcılar arası karşılaştırma verisi |
| Kota olay modeli (BLOCKED_RESUMABLE + checkpoint) | P1 | V3-T1016 | Haftalık kota en büyük kayıp kaynağı | Fallback'in bağlanacağı durum makinesi |
| Golden eval v0 (9 rol) | P1 | V3-T1017 | Model ve rol kararlarının tek nesnel girdisi | Aday modeller aynı setle ölçülür |
| Adım başına model id kaydı | P2 | V3-T1028 | Hangi modelin ne ürettiği izlenebilir olmalı | Karışık sağlayıcılı run'ların denetimi |
| Routing politika tablosu (M0–M3) + eval harness | P2 | V3-T1029 | Politika yeni sağlayıcı eklemeden test edilir | M0/M1 işler Claude dışı adaya taşınabilir |
| Yerel/ücretsiz model aday spike'ı (ürün koduna bağlanmaz) | P2 | V3-T1030 | Ücretsiz fallback'in gerçek kalitesi bilinmiyor | Kota dolunca düşük riskli işler sürebilir |
| Bütçe kesmesi + Desktop harcama görünümü | P2 | UASCO-T0064 | Kullanıcı tarafı kota/maliyet kontrolü | — |
| Routing bağlama + rol başına model | P3 | UASCO-T0063 | Eval verisi gerekli | — |
| Failover + ikinci sağlayıcı/yerel modelle gerçek run | P3 | UASCO-T0066 | T3 Founder kararı (D-09) gerekli | Tek sağlayıcı riski (RK12) kapanır |

**Ürün ile geliştirme düzlemi ayrımı:** Yukarıdaki ön koşullar ürün düzlemi içindir. Geliştirme düzleminin kota yönetimi (V3-F046: USAGE_LIMIT pause, bütçe, kademeli uyanma) ayrıdır ve P0'da başlar.

### 9.3 Ürün düzlemi: supervisor, sahiplik, lease, idempotency, eşzamanlılık

| Konu | Tasarım |
| --- | --- |
| Tek supervisor | Veri dizini başına bir MissionRunner (`runner.lock`). Bu kural korunur. |
| Sahiplik | Run → lease (TTL + fencing token). P3'te görev → alt lease (run lease'inin fencing'ini miras alır) |
| Idempotency | Her adım `(runId, stepId, attempt)` anahtarıyla journal'a yazılır. Yan etkili aksiyonlar (commit, export, müşteri push'u, deploy) idempotency anahtarı ve ön kontrol taşır. Tekrarlanan aksiyon "ALREADY_APPLIED" döner. |
| Eşzamanlılık | P1–P2'de aynı anda 1 run. P3'te kota bütçesine göre N run ve görev DAG'ında paralel dallar |
| Yerel ve bulut | P1–P2'de yalnız yerel. Bulut backend'i P3+'da gelir ve aynı lease protokolünü kullanır. Bir mission aynı anda tek bir backend'e aittir. Devir açık bir handoff kaydıyla yapılır. Journal otorite kaynağıdır. |
| Kota | PROVIDER_QUOTA olduğunda run terminal BLOCKED olmaz, BLOCKED_RESUMABLE olur. Pencere açılınca kaldığı checkpoint'ten devam eder. |

### 9.4 Geliştirme düzlemi (ürün düzleminden ayrı tasarım)

| Konu | Bugün | V3 tasarımı (PROPOSAL) |
| --- | --- | --- |
| Tek supervisor | Tek uzun koordinatör oturumu (%85 maliyet, SPOF, %97 cache-read) | **Kısa ömürlü supervisor oturumları.** Durum git'te tutulur (register, ledger). Her uyanış durumu yeniden okur, iş yapar ve kapanır (RW-017). Merge eden tek aktör supervisor'dır. |
| Görev sahipliği | Owner bölümlemesi bir konvansiyon; backlog ve queue bayat | Register'daki her V3-T kaydının `owner` alanı ve `claimRef` alanı var |
| Lease | Create-only claim ref; FA-LEASE2 yetkili değil | `refs/uasco/claims/<taskId>`: nonce + TTL + heartbeat. P0'da yalnız log, P3'te zorunlu (RW-035) |
| Idempotency | Fingerprint hızlı yolu | Her otomasyon aksiyonunun anahtarı `(taskId, headSha, action)`. Aynı anahtar ikinci kez işlenmez. |
| Cloud ve local | V6, Task Scheduler ve yerel worker UNKNOWN | Yerel aktörler ya kapalı (FD-07) ya da aynı claim protokolüne katılır. Ayrı otorite yok. Yerel Windows test worker yalnız SHADOW modunda (RW-058). |
| Uyanma | Saatlik tick'ler; kota sonrası ~115 tick birikti | **Olay güdümlü:** PR olayı, CI tamamlanması, Founder kararı. Ek olarak günde bir güvenlik ağı. Hourly tick'ler emekli edilir (RW-046). |
| Kota | Haftalık limit bütün filoyu durduruyor | Bütçe planlayıcısı (§10) + USAGE_LIMIT algılanınca global pause kaydı + reset'ten sonra kademeli uyanma (önce supervisor, sonra lane'ler) |
| Rutinler | 60 trigger (50 one-shot) | Supervisor uyanışı + PR aboneliği + günlük özet. Cloud Development, ICR ve heartbeat emekli edilir. Rutin prompt'ları repo'da sürümlenir (RW-020). |

---

## 10. Faz kapıları: kabul testleri, demo, kaynak, maliyet sınırı, başarı metriği

**Efor varsayımları (ESTIMATE):** Efor builder + review mühendislik saatidir, takvim süresi değildir. RW efor aralıkları toplandı.

**Takvim dönüşümü:** `takvim ≈ efor / (aktif lane × haftalık efektif saat)`.

- Ölçülen geçmiş: 2,2 merge / aktif saat. Kota penceresi başına 34–79 aktif saat.
- Founder bekleme süresi dahil değil. Geçmişte protected-tier medyanı 11,8 saat, p90'ı 87,3 saat.

**Maliyet:** Faturalanan değil, API-eşdeğeri.

- Formül: `PR ≈ efor saatinin ~1/4–1/6'sı (ESTIMATE)` × $/PR.
- Hedef $/merged PR ≤ $8. Ölçülen değerler: filo ortalaması $20,3, Lane A/B $3,66–4,01.

| Faz | Kapı AC'leri | Demo | Kaynak | Efor (h, ESTIMATE) | Maliyet sınırı (API-eşdeğeri, PROPOSAL) | Başarı metriği |
| --- | --- | --- | --- | --- | --- | --- |
| **P0-CRIT** | G0-1: V3-F038 AC1 (store-lock), V3-F054 AC1–3 (provenance), V3-F046 AC2 (USAGE_LIMIT pause), V3-F048 AC1–2 (baseline + ileriye dönük izlenebilirlik), V3-F049, V3-F044 | Founder, "Re-run failed jobs" sonrası aggregator'ın doğru verdict ürettiğini ve yeni bir merge'ün register'a otomatik bağlandığını görür | Supervisor + Lane B + Founder ~1–2 h | 33.5–82 | $22–$416 (hedef ≈$92) | R1 kritik yolunun açılması |
| **P0-PAR** | Kararlar ve hijyen (gating değil) | — | Supervisor + Founder | 9.8–30 | $6–$152 (hedef ≈$32) | Açık karar sayısı ↓ |
| **P1 Founder Alpha (R1)** | §5 R1-AC1..AC11 = 52 R1 AC'si | R1-DEMO (2 proje) | Lane A + Lane B + Founder-PC (Windows 11, WSL2, Claude login) + Founder ~6–12 h | 154.1–420.5 (R1 kapanış kümesi yalnız 125–342) | $103–$2,134 (hedef ≈$460); ürün run başına ≤ $5 hedef (ölçülmemiş) | **Kurulu üründe geçen senaryo: 0 → 2**; ACCEPTED Feature 0 → 13 (+3 P0) |
| **P2 Güvenilir Beta (R2)** | 30 R2 AC'si (komut alanı, hiyerarşi, Cockpit, imzalı release, kimlik ayrımı, SAST/SBOM, eval) | İkinci kullanıcı imzalı release'ten kurar, komut alanından fikir girer, hiyerarşiyi onaylar, teslimi alır | 3 lane + code-signing + GitHub App'ler | 299.5–780 | $200–$3,958 (hedef ≈$864) | İkinci kullanıcıda USABLE senaryo ≥1; ACCEPTED Feature +22 |
| **P3 Verimli fabrika (R3)** | 10 R3 AC'si (görev güdümlü yürütme, routing, failover, crew, paralel, PR teslimi, ikinci stack) | Fikir → müşteri repo'sunda merge edilebilir PR; kota simülasyonunda run devam eder | 3–4 lane | 380–1020 | $253–$5,176 (hedef ≈$1,120) | Teslim başına maliyet/süre P2'ye göre ↓; ACCEPTED Feature +8 |
| **P4 Tam yaşam döngüsü** | 10 R4 AC'si | Telefondan STOP; deploy + rollback | 4 lane + mobil | 566–1446 | Faz başında belirlenir ($377–$7,338 (hedef ≈$1,610)) | Her Epic'te ≥1 USABLE akış; ACCEPTED Feature +10 |
| **P5 Ölçek** | Rol paketi ekleme kuralı (§9.1 S4), RW-077/078/079/080 | — | Ölçülen hıza göre | 286–826 | Faz başında belirlenir | Paket başına eval iyileşmesi / maliyet |

**V3.1 hesap yöntemi (ESTIMATE):** Efor artık Task bazında toplanıyor. Legacy Task'larda RW efor aralığı, aynı RW'ye bağlı açık Task'lara eşit bölündü; yeni Task'larda tahmin elle verildi. PR ≈ efor/6 … efor/4. Maliyet = PR × $4 (alt) … × $20,3 (üst); hedef = ortalama efor/5 × $8.

V3'teki P0+P1 tahmini 166–453 h idi. V3.1'de **R1'e giden zorunlu iş (kapanış kümesi) 125–342 h**. P0+P1'in tamamı ise 197–532 h; bunun gating olmayan kısmı (golden eval, ProviderPort, lease log, review konsolidasyonu, supervisor dönüşümü) R1'i geciktirmez.

**İş metrikleri (zorunlu düzeltme 14; $/merged PR ikincil metrik olur):**

| Metrik | Tanım | P0+P1 tahmini (ESTIMATE) |
| --- | --- | --- |
| **Accepted Feature başına maliyet** | (Faz geliştirme maliyeti + CI) / o fazda ACCEPTED olan Feature sayısı | P0+P1 hedef ≈ $584 / 16 Feature ≈ **$36** (aralık $8–$169) |
| **İlk kullanılabilir teslime kadar maliyet** | R1 kapanış kümesinin geliştirme maliyeti / 1 release | ≈ $84–$1,736 (hedef ≈ $374) |
| **Kullanılabilir teslim başına maliyet (ürün)** | Bir R1 demo run'ının API-eşdeğer maliyeti + Founder dakikası | UNKNOWN; R1 hedefi ≤ $5 ve ≤ 30 dk Founder onay süresi (R1-AC9 ölçer) |
| $/merged PR (ikincil) | Geliştirme düzlemi verimliliği | Hedef ≤ $8 (ölçülen $20,3) |

**Takvim kaba aralığı (ESTIMATE, düşük güven):** En uzun seri zincir 54–154 h. 2 lane ve haftada ~30–60 efektif saat varsayımıyla R1 yaklaşık 3–7 hafta. Bu süreyi asıl belirleyen #231/FA-5 ve Founder karar hızı. Kesin tarih verilmiyor.

---

## 11. Konsolidasyon önerileri: süreç ve yönetişim maliyetini azaltma

| # | Bugün | Öneri | Beklenen etki |
| --- | --- | --- | --- |
| C1 | ROADMAP.md (149 faz), .ai/MASTER_STATE.json, BACKLOG_CHECKPOINT, PRODUCTION-QUEUE.tasks, Master V2 listeleri | V3 tek yetkili. Diğerleri `archive/` altına alınır ve salt-okur olur; kimlikleri crosswalk'ta yaşar (RW-015) | Bayat kayıt kaynaklı tekrarlı iş biter (RK13) |
| C2 | 4 review mekanizması | 1 governed reviewer yolu (§8.3) + L0 self-check | Review maliyeti ve çelişen verdict'ler azalır |
| C3 | Tek uzun koordinatör | Kısa ömürlü supervisor oturumları | %85'lik maliyet payı ve cache-read vergisi düşer |
| C4 | Hourly tick'ler, heartbeat, Cloud Development, ICR, 50 one-shot hatırlatıcı | Olay güdümlü uyanma + PR başına 1 abonelik + günlük özet | ~153 no-op fire ve ≈$16/gün boş çalışma ortadan kalkar |
| C5 | LANES.json'da 26 lane | Aktif 2–3 lane; registry kapasite sayılmaz | Conflict ve review yükü azalır |
| C6 | LOW bulgular için ayrı PR zincirleri (son 100 PR'ın 15'i) | LOW'lar toplanır, sonraki ilgili PR'a ya da haftalık temizliğe eklenir (RW-049) | Daha az PR, daha az CI |
| C7 | Kanonik rapora L/M delta bölümleri eklenerek büyümesi (210 KB) | Rapor her seferinde register'dan **yeniden üretilir**, delta eklenmez. Değişiklikler kısa bir changelog'a yazılır | Okuma ve bağlam maliyeti düşer |
| C8 | Değişen satırların %49,5'i süreç dosyası | Hedef: ürün kodu payı ≥ %40. Yeni governance dosyası yalnız bir P0 kararıyla açılır | Ürün odağı artar |
| C9 | ≈24k satır mutasyon ve kanıt harness'ı | Yeni mutasyon harness'ı yalnız T2 güvenlik koduna eklenir; diğer yerlerde L3 coverage yeterli | Daha az bakım yükü |
| C10 | 82 bayat oturum, 58 bayat branch | Bekleyen sorular kaydedildikten sonra arşivlenir (RW-072) | Görünürlük artar |

---

## 12. Founder tarafından verilmesi gereken kararlar

### 12.1 V3.1 yeniden değerlendirmesi (zorunlu düzeltme 12)

Sınıflar: **APPROVABLE_NOW** = karar için gereken kanıt mevcut · **NEEDS_VERIFICATION** = önce bir doğrulama gerekli · **DEFERRABLE** = R1'i bloke etmiyor. Hiçbir karar verilmedi; öneriler bağlayıcı değildir. Tam kayıt (gerekçe, bloke ettiği Task'lar, DELTA_HANDOVER_V3 FD-A..H ve FA-x eşlemesi): `V3_FOUNDER_DECISION_REGISTER`.

| Id | Karar | Sınıf | Gereken doğrulama | Öneri (karar değil) |
|---|---|---|---|---|
| D-01 | V3.1'in tek yetkili roadmap olması; eski planların arşivi | **APPROVABLE_NOW** | Fark analizi tamamlandı (bu revizyon, §0) | Onaylanmaya aday |
| D-02 | v1 kapsamı: R1 = kaynak teslimi; PR R3; deploy P4 ayrı karar | **APPROVABLE_NOW** | — | (a) kaynak teslimi |
| D-03 | Windows sandbox yaklaşımı: WSL2 (#231) | **NEEDS_VERIFICATION** | V3-T1019 kontrol listesi + FA-5 gerçek kabul | WSL2; sandbox'sız host modu önerilmez |
| D-04 | Birleşik SHA CI: native merge queue mi, zorunlu up-to-date + seri tren mi | **NEEDS_VERIFICATION** | GitHub ayarlarında merge queue seçeneğinin varlığı | Varsa merge queue; yoksa up-to-date + V3-T1008 seri kural |
| D-05 | Builder/Reviewer GitHub App'leriyle kimlik ayrımı | **DEFERRABLE** | App oluşturma ve ruleset'te required check olarak tanınması | P2 başında karar |
| D-06 | Ledger ↔ founder-authority köprüsü (FD-10/FD-F) | **APPROVABLE_NOW** | — | Onay adayı |
| D-07 | Trust-root reseal: tek seferde değil, iki batch | **NEEDS_VERIFICATION** | #251/#247 rebase + delta review | Batch 1 = RW-006 + #251 + #247; Batch 2 = #231 (FA-5 sonrası) |
| D-08 | Haftalık geliştirme bütçesi ve dağılımı | **APPROVABLE_NOW** | — | Örnek %60 build / %20 review / %10 supervisor / %10 yedek; %90'da sert durma |
| D-09 | Ürün içi ücretli API ve ikinci sağlayıcı | **DEFERRABLE** | V3-T1030 spike sonuçları | P3'te T3 kararı |
| D-10 | Rol stratejisi: 599 rol → arketip + paket | **NEEDS_VERIFICATION** | V3-T1017 golden eval v0 sonuçları | Yön olarak not edilsin; kesin karar P2 |
| D-11 | #66 Electron E2E: SUPERSEDED | **APPROVABLE_NOW** | — | SUPERSEDED |
| D-12 | Yerel V6/Task Scheduler/worker durdurma | **APPROVABLE_NOW** | FA-7 PowerShell kontrol çıktısı | Durdur ve raporla |
| D-13 | Code-signing sertifikası | **DEFERRABLE** | Sertifika türü/maliyet araştırması | P2 başı |
| D-14 | Repo görünürlüğü public kalır | **APPROVABLE_NOW** | — | Public kalsın |
| D-15 | Mobil ve ses (gizlilik) | **DEFERRABLE** | — | P4, G3 sonrası |
| D-16 | Faz maliyet sınırları | **APPROVABLE_NOW** | P2+ için R1 run maliyet verisi | P0–P1 sınırlarını onayla, P2+ ertele |
| D-17 | Base-red politikası: merge-freeze, build-freeze değil | **APPROVABLE_NOW** | — | Onay adayı |
| D-18 | CI shard provenance kuralları (attempt birleştirme) | **APPROVABLE_NOW** | — | Onay adayı |
| D-19 | SEC-PROFILE-R1 ve pre-dev kalite eşiği | **NEEDS_VERIFICATION** | V3-T1010, V3-T1013 | Profil: yerleşik secret + gitleaks + SCA; eşik R1 sonrası |
| D-20 | Sıra: Windows CI kararlılığı ile #231 paralel mi (FD-A) | **APPROVABLE_NOW** | — | Paralel; #231 merge'ü V3-F038 AC1-AC2 sonrası |
| D-21 | IR: token yenile mi, IR'ı emekli et mi (FD-D) | **APPROVABLE_NOW** | — | Token yenile + P2'de App'e taşı |
| D-22 | #282 yeniden ele alma ölçütü | **APPROVABLE_NOW** | — | Ölçütü kabul et |

Özet: APPROVABLE_NOW 13 · NEEDS_VERIFICATION 5 · DEFERRABLE 4 (toplam 22: D-01..D-16 + yeni D-17..D-22).

### 12.2 V3 karar tablosu (referans için korundu)

| Id | Karar | Seçenekler | Öneri | Bloke ettiği |
| --- | --- | --- | --- | --- |
| D-01 | Master Roadmap V3'ün tek yetkili plan olması ve eski planların arşivlenmesi | Evet / revizyonla evet | Fark analizinden sonra evet | Her şey (RW-015) |
| D-02 | v1 kapsamı | (a) Yalnız kaynak teslimi (b) + müşteri repo'suna PR (c) + deploy | R1 = (a), R3 = (b), deploy P4'te ve ayrı bir kararla | RW-016 |
| D-03 | Windows sandbox yaklaşımı | (a) WSL2 (#231 hazır) (b) Windows-native izolasyon (c) Docker/VM | (a). Kullanıcıda WSL2 ve sanallaştırma gereksinimi kabul edilir. Sandbox'sız "host'ta çalıştır" modu **önerilmez**: doğrulama kuralını zayıflatır | RW-004, R1 |
| D-04 | Merge kuyruğu ve ruleset değişikliği | Native merge queue / seri tren | Native merge queue | N3, P0 |
| D-05 | Kimlik ayrımı: Builder ve Reviewer GitHub App'leri | Evet / ikinci kullanıcı hesabı | GitHub App'ler | RW-008, RW-023 |
| D-06 | Ledger ↔ Founder-authority köprüsü (FD-10) | Evet / hayır | Evet (API'den okunur, elle yazılamaz) | N4 |
| D-07 | Tek birleşik trust-root reseal (#251, #247, #231) | Tek seferde / sıralı | Tek seferde ve RW-006 kapsam genişletmesiyle birlikte | RW-006, P1 kritik yolu |
| D-08 | Haftalık geliştirme bütçesi ve dağılımı | Örnek: %60 build, %20 review, %10 supervisor, %10 yedek; %90'da sert durma | Evet, ölçüm (RW-018) ile birlikte | RW-003, P0 |
| D-09 | Ürün içi ücretli API ve ikinci sağlayıcı | P1–P2'de hayır, P3'te T3 kararıyla | P3'e kadar hayır | RW-037 |
| D-10 | Rol stratejisi: 599 rol → arketip + paket | Evet / hayır | Evet | §9.1 |
| D-11 | #66 (Electron E2E, ortak atası yok) | Yeniden kur / SUPERSEDED | SUPERSEDED. RW-024 güncel base'de yeniden kurulur | RW-024 |
| D-12 | Yerel V6, Task Scheduler ve worker durumu (FD-07) | Kapat / claim protokolüne kat | P0'da kapat; worker yalnız SHADOW | PAUSED_VERIFIED, eşzamanlılık |
| D-13 | Code-signing sertifikası | P2'de / ertele | P2 başında | RW-022 |
| D-14 | Repo görünürlüğü (public = ücretsiz Actions) | Public / private | Public kalsın (RK15) | RW-021 |
| D-15 | Mobil ve ses (gizlilik) | P4 / ertele | P4, G3'ten sonra | RW-038, RW-073 |
| D-16 | Faz maliyet sınırları (§10) | Onay / değiştir | Önerilen sınırlar | Bütün fazlar |

---

## 13. Riskler ve teknik borç

| Id | Risk | Olasılık / Etki | Azaltım |
| --- | --- | --- | --- |
| V3-R01 | WSL2 sağlayıcısı Founder-PC'de doğrulanamaz ya da kullanıcı makinesinde sanallaştırma kapalıdır | Orta / Yüksek | FA-5 erken yapılır; P1'in ilk işi; D-03(b) yedek tasarım olarak not edilir |
| V3-R02 | Gerçek modelle pre-dev çıktısı yetersiz kalır (hiç ölçülmedi) | **Yüksek** / Yüksek | N6 golden eval P1'de başlar; R1 kapsamı küçük projelerle sınırlı |
| V3-R03 | Haftalık kota yine bütün işi durdurur | Yüksek / Yüksek | D-08 bütçesi + olay güdümlü uyanma + BLOCKED_RESUMABLE |
| V3-R04 | Founder karar gecikmesi kritik yolu tıkar | Yüksek / Yüksek | Toplu karar oturumu, varsayılan "park et" kuralı, D-01..D-08 P0'da alınır |
| V3-R05 | Tek sağlayıcı yüzünden review bağımsızlığı zayıf kalır (ortak-mod hatası) | Orta / Yüksek | Profil ayrımı + INDEPENDENCE_DEGRADED etiketi + P3'te ikinci model |
| V3-R06 | Paralel PR'lar birlikte kırılır (M.3) | Kanıtlandı / Orta | Merge kuyruğu (N3) |
| V3-R07 | Windows flake'leri base'i kırmızıya çevirir | Yüksek / Orta | §7.2 |
| V3-R08 | Kapsam kayması (149 faz, 599 rol, 252 ekran) | Yüksek / Yüksek | Faz kapıları; rol ve ekran ancak kapıdan sonra eklenir |
| V3-R09 | Governance yükü yeniden büyür | Orta / Orta | C8 ürün kodu payı metriği |
| V3-R10 | Alpha electron-builder ve override kırılganlığı | Orta / Orta | RW-063 (P2) |
| V3-R11 | İmzasız installer, ikinci kullanıcıda SmartScreen ve güven sorunu | Yüksek / Orta | D-13 (P2) |
| V3-R12 | Kanıt artifact'larının silinmesi | Kesin / Orta | Register'a özet (RW-048) |

**Taşınan teknik borç:** Raporun I bölümündeki RK01–RK16 ile TD-V2-01..05 geçerliliğini koruyor. V3'te eklenen borç kalemleri:

- TD-V3-01: Ürün içi Epic hiyerarşisi yok (N1).
- TD-V3-02: Teslim etiketi doğrulamadan türetilmiyor (W4).
- TD-V3-03: Görevler yürütmeyi sürmüyor (W13).

---

## 14. Feature ve Epic tamamlama metrikleri

| Metrik | Tanım | Bugün | R1 hedefi | R2 hedefi |
| --- | --- | --- | --- | --- |
| **Çalışan yetenek skoru (ana metrik)** | Kurulu build'de geçen ve kanıtı saklanan demo senaryosu sayısı | 0 | 2 | ≥5 (ikinci kullanıcı dahil) |
| Feature seviye dağılımı | 49 (+8 yeni) Feature'ın merdivendeki en yüksek kanıtlı seviyesi | VERIFIED_REAL_ENV: yalnız CI'da 2–3 | R1 Feature'ları (~8) VERIFIED_REAL_ENV | ~20 |
| Epic USABLE sayısı | §3.5 kuralına göre | 0/9 | 0 (R1 bir Epic'i değil, bir senaryoyu kanıtlar) | E1 ve E4 USABLE |
| Fikir → teslim süresi | Intake'ten kabul kaydına kadar geçen süre | Ölçülmedi | Ölçülüyor | ↓ |
| Founder müdahalesi / run | Onay dışı manuel adım sayısı | — | 0 elle düzenleme | 0 |
| First-pass yield | Remediation gerekmeden VERIFY=PASSED olan run oranı | — | Ölçülüyor | ↑ |
| Teslim edilen proje başına maliyet | Token ve API-eşdeğeri | Ölçülmedi | Ölçülüyor (UNKNOWN ise etiketli) | Bütçeyle sınırlı |
| Gerileme | 7 günde COMPLETE durumdan düşen Feature sayısı | — | 0 | 0 |
| **Accepted Feature başına maliyet** | §10 | Ölçülmedi | P0+P1 ≈ $37 hedef (ESTIMATE) | Faz bazında izlenir |
| **Kullanılabilir teslim başına maliyet** | Ürün run maliyeti + Founder dakikası | Ölçülmedi | ≤ $5 + ≤ 30 dk (hedef) | ↓ |
| ACCEPTED / STABLE_7D Feature sayısı | §3.5 | 0 / 0 | 16 / 16 | 38 / 38 |
| **Geliştirme düzlemi** | $/merged PR · ürün kodu payı · CI pass · flake · kayıt sapması · kota duruş saati | $20,3 · %16,1 · %72,6 · ? · 168 · %55 | ≤$8 · ≥%30 · ≥%90 · ≤%5 · 0 · <%20 | ≤$8 · ≥%40 · ≥%95 · ≤%2 · 0 · <%10 |

Kural: Raporlarda "tamamlanan Task sayısı" ikincil metrik olarak gösterilir. Başlıkta her zaman "çalışan yetenek skoru" yer alır.

---

## 15. Aşamalı yürütme sırası ve tahmini iş yükü

| Sıra | Adım | İçerik | Bağımlılık | Efor (h, ESTIMATE) |
| --- | --- | --- | --- | --- |
| — | **V3.1 notu** | Aşağıdaki V3 sırası korunuyor. Task düzeyindeki bağlayıcı sıra `V3_TASK_DEPENDENCY_MATRIX` dosyasında (topolojik, faz tersliği yok). Adım 2 ve 4'ün bir kısmı P0-PAR'a, tarihsel backfill P2'ye taşındı | — | — |
| 0 | Kapanış ve fark analizi | §0.3, §0.4 (V3.1'de yapıldı) | Kapanış | 2–4 |
| 1 | P0-a Founder kararları | D-01..D-08, D-12; FA-1..FA-9 | 0 | Founder 2–4 |
| 2 | P0-b Kayıt ve bütçe | V3.1: RW-014 yalnız ileriye dönük + LEGACY_BASELINE (geriye dönük eşleme P2, V3-T1021); RW-003 minimal koruma; RW-048. RW-018 ve RW-047 P1'e | 1 | P0-CRIT içinde |
| 3 | P0-c CI ve merge | V3.1: V3-T1001, V3-T1002/1003/1036 (P0-CRIT); merge kuyruğu P2 (V3-T1020), ara kural V3-T1008; N4 (V3-T1004) P1; RW-060 P1 | 1 (D-18, D-20) | P0-CRIT + P1 |
| 4 | P0-d Hijyen | RW-007, RW-019, RW-021, RW-045, RW-046, RW-049, C1, C4, C10 | 1 | 12–31 |
| 5 | P1-a Güven ön koşulu | RW-006 + tek reseal (D-07) | 1, 3'ün bir kısmı | 4–10 |
| 6 | P1-b Kritik yol | RW-004 → FA-5 ∥ RW-009 ∥ RW-011 → RW-010 | 5 | 47–142 |
| 7 | P1-c Kanıt | W4/N8 + R1-AC6 script'i + R1-AC8 negatif testleri + N6 hazırlığı | 6 | 12–30 |
| 8 | P1-d R1 kabulü | RW-005: 3 ardışık demo | 6, 7 | 16–40 |
| 9 | G1 kapısı + V3 revizyonu | R1 metrikleriyle P2 kapsamı yeniden kalibre edilir | 8 | 2–4 |
| 10 | P2 | §6 P2 satırı | G1 | ≈290–800 |
| 11 | P3 | §6 P3 satırı | G2 | ≈270–720 |
| 12 | P4 / P5 | §6 | G3 | ≈880–2.380 |

**Toplamlar (ESTIMATE):**

- P0 + P1 ≈ 166–453 h.
- P0..P3 ≈ 726–1.973 h.
- Tam vizyon ≈ 1.600–4.350 h. Raporun Plan C kümülatif değeri 1.257–3.307 h idi. Fark, yeni Feature'lardan ve P5'ten geliyor.

**Not:** Toplamlar, her faz kapısında ölçülen gerçek hız ve maliyetle yeniden hesaplanır. P2 ve sonrasının rakamları, R1 verisi gelene kadar düşük güvenli kabul edilmeli.

---

## Ek A. Eski Feature → V3 eşlemesi (tam liste)

> V3.1 notu: Bu tablo V3'teki eşlemeyi gösteriyor. V3.1'de bölünme yok: F017 → V3-F017 (E4), F023 → V3-F023 (E0), F037 → V3-F037 (E7). Bölünen kısımlar Task taşımayla çözüldü (T0040 → V3-F016). Bağlayıcı eşleme §3.3.1 ve `V3_FEATURE_CROSSWALK`'tır.

| Eski | V3 | Eski | V3 | Eski | V3 |
| --- | --- | --- | --- | --- | --- |
| F001 | E1 | F018 | E4 | F035 | E7 |
| F002 | E1 | F019 | E5 | F036 | E7 |
| F003 | E2 | F020 | E5 | F037 | E6 (onay) + E7 (mobil) |
| F004 | E2 | F021 | E5 | F038 | E0 |
| F005 | E4 | F022 | E5 | F039 | E1 |
| F006 | E4 | F023 | E5 (ürün) + E0 (geliştirme) | F040 | E1 |
| F007 | E2 | F024 | E5 | F041 | E0 |
| F008 | E7 | F025 | E5 | F042 | E0 |
| F009 | E6 | F026 | E5 | F043 | E0 |
| F010 | E1 | F027 | E5 | F044 | E0 |
| F011 | E2 | F028 | E5 | F045 | E0 |
| F012 | E3 | F029 | E3 | F046 | E0 |
| F013 | E3 | F030 | E0 | F047 | E0 |
| F014 | E3 | F031 | E0 | F048 | E0 |
| F015 | E4 | F032 | E6 | F049 | E0 |
| F016 | E8 | F033 | E0 | | |
| F017 | E4 (PR) + E8 (deploy) | F034 | E0 | | |

Eski Epic → V3: E01 → E1/E2/E4/E6/E7 · E02 → E2/E3/E4/E8 · E03 → E5 · E04 → E5 · E05 → E0/E3/E6 · E06 → E7 · E07 → E0/E1 · E08 → E0 · E09 → E0.

## Ek B. Envanter bağı boş 30 Task için öneri

- **27 COMPLETE Task → `ASSET-###`.** Bunlar §1'deki korunacak bileşenler. Her biri bir gerileme AC'sine bağlanır:
  T0005, T0009, T0012, T0013, T0019, T0022, T0025, T0027, T0032, T0034, T0036, T0042, T0043, T0045, T0048, T0050, T0058, T0060, T0065, T0067, T0068, T0073, T0075, T0087, T0104, T0105, T0114.
- **T0008 → RW-024.** Linux Electron journey, UNVERIFIABLE. Windows E2E CI'da yeniden kurulacak.
- **T0094 → RW-024.** Desktop journey harness, PARTIAL.
- **T0028 → RW-005.** 2026-10-14 canlı smoke, UNVERIFIABLE. R1 kanıtı bunun yerini alacak.
- **V3.1:** Bu üç yeniden bağlama `V3_TASK_DEPENDENCY_MATRIX` dosyasında `inventoryRelinked = true` olarak işaretli. 27 ASSET Task'ın 5'i (T0010, T0045, T0050, T0062, T0065) **ASSET_CODED_UNWIRED**: kodu var ama bağlı değil, bağlama işi ayrı Task'ta. Bunlar "çalışan bileşen" sayılmaz.

---

## 16. Bu revizyonda değişmeyen V3 kararları

§1 (korunacak bileşenler), §2 (mimari bağlantılar), §8.1–8.4 (kontrol modeli), §9.1 ve §9.3–9.4 (ajan mimarisi, supervisor tasarımları), §11 (konsolidasyon) ve §13 (riskler) V3'teki hâliyle geçerli. Değişiklikler yalnız ilgili satırlarda yapıldı ve §18'de listelendi.

**§13'e eklenen riskler:**

| Id | Risk | Olasılık / Etki | Azaltım |
| --- | --- | --- | --- |
| V3-R13 | Attempt'ler arası shard birleştirmesi yanlış PASS üretir | Orta / Yüksek | §7.5, V3-F054 |
| V3-R14 | Kanonik JSON'daki Task durumları kapanıştan sonra bayat kalır (9 Task) | Kesin / Orta | `v31Status` + V3-T1005 ileriye dönük register |
| V3-R15 | Native merge queue'nun bu repoda bulunmaması | Bilinmiyor / Orta | D-04, Seçenek B |
| V3-R16 | SEC-PROFILE-R1 araçları Founder-PC'ye kurulamaz | Orta / Orta | V3-T1010; kurulamazsa R1 kabulü geçmez, etiket dürüst kalır |

## 17. Nihai vizyon kapsamı (zorunlu düzeltme 11; R1'i büyütmez)

Bu bölüm nihai ürünü tarif eder. Buradaki maddelerin hiçbiri R1 kapsamına girmez. Feature'a bağlı olanlar kendi fazlarında yürür. **CAND-** ile işaretlenenler 57 Feature'ın dışındaki aday Feature'lardır; ancak R2 kapısından sonra ve bir Founder kararıyla Feature'a dönüşür.

| Id | Vizyon yeteneği | Bağlı V3 Feature / aday | En erken | Not |
| --- | --- | --- | --- | --- |
| VIS-01 | Founder Cockpit: durum, engeller, onay kuyruğu, maliyet, kota, portföy | V3-F008 (R2 minimum), V3-F027, V3-F043 | R2 | R4'te canlı push (SSE) ve mobil |
| VIS-02 | Desktop UI/UX: tasarım sistemi, erişilebilirlik, TR/EN yerelleştirme, 252 ekran anahtarının sadeleştirilmesi | V3-F002, UASCO-T0122; CAND-01 Tasarım sistemi ve erişilebilirlik | R2 (sınıflama), R3 (tasarım sistemi) | Ekran sayısı hedef değil; ekran başına kabul ölçütü |
| VIS-03 | Tek komut alanı → netleştirme diyaloğu → DRAFT | V3-F003 | R2 | Ses P4 (V3-F007) |
| VIS-04 | Ürün içi görünürlük: Epic → Feature → Task → AC → kanıt izleyicisi | V3-F050, V3-F057; CAND-02 İzlenebilirlik görüntüleyici | R2 (hiyerarşi), R3 (kanıt izleyici) | Founder her teslimin hangi AC'yi kanıtladığını görür |
| VIS-05 | Onay ve revizyon akışları (Feature onayı, diff onayı, akıllı revizyon) | V3-F050, V3-F006, V3-F056 | R2 / R4 | Onaylar attestation'lı |
| VIS-06 | Çok kullanıcı ve çalışma alanı (rol tabanlı erişim) | CAND-03 | R4+ | Ticari ürün ön koşulu |
| VIS-07 | Lisanslama, abonelik ve müşteri kullanım ölçümü/faturalama | CAND-04 (V3-F027 ölçümünü kullanır) | R4+ | Ödeme işlemleri T3 |
| VIS-08 | Onboarding, kurulum sihirbazı, ortam tanılama (WSL2, CLI, araçlar) | CAND-05 (V3-T1019'un ürünleşmiş hâli) | R2 | İkinci kullanıcı kabulü (DS-R2-INSTALL) için faydalı |
| VIS-09 | Gizlilik, telemetri onayı, veri saklama politikası | CAND-06 | R2 (politika), R4 (ses) | Yerel-öncelikli mimariyle uyumlu |
| VIS-10 | Üretilen kodun lisans uyumu ve SBOM teslimi | CAND-07 (V3-F014'e bağlı) | R3 | Ticari teslim ön koşulu |
| VIS-11 | Destek: tanılama paketi, hata raporu, güncelleme kanalları (stable/beta) | CAND-08 (V3-F010'a bağlı) | R3 | — |
| VIS-12 | Portföy ve çoklu proje zamanlaması (SLA, bütçe önceliği) | CAND-09 (V3-F021'e bağlı) | R4 | Ph.25 vizyonu |

## 18. V3 → V3.1 değişiklik kaydı

| Id | Gereksinim | Bölüm | Değişiklik |
|---|---|---|---|
| CH-01 | Zorunlu 1 | §3.3, Ek A | 57 Feature'a kalıcı V3-F kimliği (V3-F001..049 = UASCO-F001..049; V3-F050..057 = N1..N8). Bölünen Feature yok; 3 Task taşındı (REPARENT). |
| CH-02 | Zorunlu 2 | Task matrisi | 129 legacy Task tek tek V3 Feature'a bağlandı; 30 boş inventoryId'nin 3'ü yeniden bağlandı, 27'si ASSET; 33 yeni Task PROPOSED. 9 Task'ın durumu kanıtla güncellendi (DONE_OBSERVED/DEFERRED/VERIFY_PENDING); hiçbir yeni Task tamamlanmış gösterilmedi. |
| CH-03 | Zorunlu 3 | AC/Evidence matrisi | Her AC için kanıt kimliği, sınıfı, üretici ve ortam; her Task için iş tanımı ve bitiş ölçütü. |
| CH-04 | Zorunlu 4 | §4, §10, §15 | P0, P0-CRIT (R1'i bloke eden) ve P0-PAR (bloke etmeyen) olarak ayrıldı; tarihsel 168 PR eşlemesi P2'ye (gating değil); ileriye dönük izlenebilirlik zorunlu. |
| CH-05 | Zorunlu 5 | §7.1 | 'Base kırmızıysa lane push'ları durur' kuralı kaldırıldı; yerine merge-freeze/build-freeze ayrımı (D-17). |
| CH-06 | Zorunlu 6 | §7.5 (yeni), V3-F054 | Attempt'ler arası shard birleştirme için provenance kuralları ve job conclusion çapraz kontrolü. |
| CH-07 | Zorunlu 7 | §5.1 (yeni) | R1 ile hedef fabrika arasında yetenek tablosu; tek komut alanı ve hiyerarşi R2, görev güdümlü yürütme R3 olarak kesinleştirildi. |
| CH-08 | Zorunlu 8 | §5, V3-F057, V3-F014 | R1-AC4 değişti: PARTIAL güvenlik raporu PRODUCT_VERIFIED etiketi alamaz; üç bağımsız kabul kaydı. |
| CH-09 | Zorunlu 9 | §3.5, EPIC_ACCEPT | Feature durumları ACCEPTED ve STABLE_7D ayrıldı; Epic kabulü Epic'e özgü senaryolarla (mekanik 3 tekrar kaldırıldı). |
| CH-10 | Zorunlu 10 | §9.2 | Model mimarisi ön koşulları faz faz (ProviderPort P1, kullanım yakalama P1, kota modeli P1, model id P2, politika+eval P2, yerel model spike P2, failover P3); tüm sağlayıcılar UNVERIFIED_INTEGRATION. |
| CH-11 | Zorunlu 11 | §17 (yeni) | Nihai vizyon kapsamı: Founder Cockpit, UI/UX, tek komut, görünürlük, onay/revizyon, ticari gereksinimler (CAND-xx); R1 büyütülmedi. |
| CH-12 | Zorunlu 12 | §12, karar kaydı | D-01..D-16 üç sınıfa ayrıldı; D-07 'tek reseal' → iki batch önerisi; D-04'e erişilebilirlik doğrulaması eklendi; D-17..D-22 eklendi; karar verilmedi. |
| CH-13 | Zorunlu 13 | §0 | GitHub kapanışı yeniden doğrulandı: 16d3a925 (#294 merge), #282 açık/DEFER; ledger 122a1b12; rapor dalı 770c551. |
| CH-14 | Zorunlu 14 | §10, §14 | Efor yeniden hesaplandı (Task bazında); accepted Feature başına ve kullanılabilir teslim başına maliyet ana metriklere eklendi. |
| CH-15 | Düzeltme | V3 §5 R1-AC4 | V3'teki 'araç yoksa dürüst PARTIAL etiketi' kabul ölçütü olarak yetersizdi; artık R1 kabulünü bloke eder. |
| CH-16 | Düzeltme | V3 §7.3 | V3 native merge queue'yu önerilen yol olarak sundu; erişilebilirliği doğrulanmamıştı (D-04 NEEDS_VERIFICATION). |
| CH-17 | Düzeltme | V3 §0.2 | Kapanış sonu durumları güncellendi (#295, #294 merge; base yeşil; açık 5 PR). |
| CH-18 | Düzeltme | V3 F033 olgunluğu | 'base kırmızı' ifadesi bayat; 6b174dc'den beri dependency-supply-chain PASS. |

## 19. V3'teki eksikler: kapatılanlar ve doğrulanamayanlar

**Bu revizyonda kapatılanlar:** 14 zorunlu düzeltmenin hepsi belge ve kayıt düzeyinde ele alındı (CH-01..CH-14). Ek olarak V3'te 4 hata bulundu ve düzeltildi (CH-15..CH-18):

- PARTIAL güvenliğin kabul sayılması
- Native merge queue'nun doğrulanmadan önerilmesi
- Bayat kapanış durumları
- F033 olgunluğu

Kayıtların iç tutarlılığı betikle doğrulandı:

- 57 Feature, 164 Task (129 legacy + 35 PROPOSED), 102 AC, 102 kanıt kaydı, 22 karar.
- Eksik referans 0, Task veya Feature bağımlılık döngüsü 0, faz tersliği 0, kapsanmayan AC 0.
- 129 legacy Task'ın her biri tam bir kez eşlendi.

**Kaynak ya da ortam eksikliği nedeniyle doğrulanamayanlar:**

| Konu | Neden doğrulanamadı | Etkisi | Ne zaman doğrulanır |
| --- | --- | --- | --- |
| 16d3a925 push CI ve installer run sonuçları | Bu oturumda Actions run'ları okunmadı; değerler rapordan (CLAIMED) | Base'in yeşil olduğu kabulü | Fark analizinde actions_get ile |
| #282'nin 14:05Z güncellemesinin nedeni | Yorumlar okunmadı | Yok (CI değişmedi) | İstenirse PR yorumlarıyla |
| Rutinlerin 0/11 etkin olduğu | list_triggers çağrılmadı (kapanış oturumuna müdahale etmemek için) | Yok | UASCO-T0115 gözleminde |
| Native merge queue'nun bu repoda kullanılabilirliği | Repo ayarları okunamaz; GitHub belgesi bu oturumda kontrol edilmedi | D-04 | Founder ayar ekranı |
| Founder-PC: Windows 11, WSL2, sanallaştırma, Claude login, V6/Task Scheduler | Bulut oturumu Founder-PC'ye erişemez | D-03, D-12, R1 kritik yolu | V3-T1019, FA-5, FA-7 |
| #231'in güncel base'e uyumu (166 commit geride) | Kod incelenmedi (salt-okur, kapsam dışı) | UASCO-T0031 eforu (40–120 h) | Rebase + delta review |
| #251/#247 içeriğinin güncel base'e göre geçerliliği | Kod incelenmedi | D-07 batch 1 | Rebase + delta review |
| Gerçek model çıktı kalitesi ve ürün run maliyeti | Hiç ölçülmedi (rapor A.3) | Kullanılabilir teslim başına maliyet UNKNOWN | R1 (R1-AC9, V3-T1017) |
| Sağlayıcı ve yerel model adayları | Entegrasyon yok; güncel bilgi doğrulanmadı | Bütün adaylar UNVERIFIED_INTEGRATION | V3-T1030 spike |
| Efor ve maliyet aralıkları | Raporun ESTIMATE değerleri + yeni Task tahminleri; geçmiş hız verisi kota duruşlarıyla bozuk | Takvim düşük güvenli | Her faz kapısında yeniden hesap |
| Legacy Task iş tanımlarının uygulanabilirliği | Kod düzeyinde doğrulama yapılmadı; bitiş ölçütleri raporun completionCriteria alanından ya da V3.1 önerisinden | Task bazında efor sapabilir | Task başlarken builder doğrular |

**Yürürlük durumu:** Bu belge ve eşlik eden kayıtlar **DRAFT**'tır. Founder kararı verilmedi, uygulama başlatılmadı, repository, PR ve rutinlerde değişiklik yapılmadı.
