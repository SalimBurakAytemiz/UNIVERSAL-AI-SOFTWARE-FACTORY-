<!-- Makine-eşleştirilebilir kaynak: aynı adlı .json/.csv dosyaları. Bu tablo onlardan üretildi. -->

# V3_REVISION_CHANGELOG (V3 → V3.1)

| Id | Gereksinim | Bölüm | Değişiklik |
|---|---|---|---|
| CH-01 | Zorunlu 1 | §3.3, Ek A | 57 Feature'a kalıcı V3-F kimliği (V3-F001..049 = UASCO-F001..049; V3-F050..057 = N1..N8). Bölünen Feature yok; 3 Task taşındı (REPARENT). |
| CH-02 | Zorunlu 2 | Task matrisi | 129 legacy Task tek tek V3 Feature'a bağlandı; 30 boş inventoryId'nin 3'ü yeniden bağlandı, 27'si ASSET; 33 yeni Task PROPOSED. 9 Task'ın durumu kanıtla güncellendi (DONE_OBSERVED/DEFERRED/VERIFY_PENDING); hiçbir yeni Task tamamlanmış gösterilmedi. |
| CH-03 | Zorunlu 3 | AC/Evidence matrisi | Her AC için kanıt kimliği, sınıfı, üretici ve ortam; her Task için iş tanımı ve bitiş ölçütü. |
| CH-04 | Zorunlu 4 | §4, §10, §15 | P0, P0-CRIT (R1'i bloke eden) ve P0-PAR (bloke etmeyen) olarak ayrıldı; tarihsel 168 PR eşlemesi P2'ye (gating değil); ileriye dönük izlenebilirlik zorunlu. |
| CH-05 | Zorunlu 5 | §7.1 | 'Base kırmızıysa lane push'ları durur' kuralı kaldırıldı; yerine merge-freeze/build-freeze ayrımı (D-17). |
| CH-06 | Zorunlu 6 | §7.5 (yeni), V3-F054 | Attempt'ler arası shard birleştirme için provenance kuralları ve job conclusion çapraz kontrolü. |
| CH-07 | Zorunlu 7 | §5.1 (yeni) | R1 ile hedef fabrika arasında yetenek tablosu; tek komut alanı ve hiyerarşi R2, görev güdümlü yürütme R3 olarak kesinleştirildi. |
| CH-08 | Zorunlu 8 | §5, V3-F057, V3-F014 | R1-AC4 değişti: PARTIAL güvenlik raporu PRODUCT_VERIFIED etiketi alamaz; üç bağımsız kabul kaydı. |
| CH-09 | Zorunlu 9 | §3.5, EPIC_ACCEPT | Feature durumları ACCEPTED ve STABLE_7D ayrıldı; Epic kabulü Epic'e özgü senaryolarla (mekanik 3 tekrar kaldırıldı). |
| CH-10 | Zorunlu 10 | §9.2 | Model mimarisi ön koşulları faz faz (ProviderPort P1, kullanım yakalama P1, kota modeli P1, model id P2, politika+eval P2, yerel model spike P2, failover P3); tüm sağlayıcılar UNVERIFIED_INTEGRATION. |
| CH-11 | Zorunlu 11 | §17 (yeni) | Nihai vizyon kapsamı: Founder Cockpit, UI/UX, tek komut, görünürlük, onay/revizyon, ticari gereksinimler (CAND-xx); R1 büyütülmedi. |
| CH-12 | Zorunlu 12 | §12, karar kaydı | D-01..D-16 üç sınıfa ayrıldı; D-07 'tek reseal' → iki batch önerisi; D-04'e erişilebilirlik doğrulaması eklendi; D-17..D-22 eklendi; karar verilmedi. |
| CH-13 | Zorunlu 13 | §0 | GitHub kapanışı yeniden doğrulandı: 16d3a925 (#294 merge), #282 açık/DEFER; ledger 122a1b12; rapor dalı 770c551. |
| CH-14 | Zorunlu 14 | §10, §14 | Efor yeniden hesaplandı (Task bazında); accepted Feature başına ve kullanılabilir teslim başına maliyet ana metriklere eklendi. |
| CH-15 | Düzeltme | V3 §5 R1-AC4 | V3'teki 'araç yoksa dürüst PARTIAL etiketi' kabul ölçütü olarak yetersizdi; artık R1 kabulünü bloke eder. |
| CH-16 | Düzeltme | V3 §7.3 | V3 native merge queue'yu önerilen yol olarak sundu; erişilebilirliği doğrulanmamıştı (D-04 NEEDS_VERIFICATION). |
| CH-17 | Düzeltme | V3 §0.2 | Kapanış sonu durumları güncellendi (#295, #294 merge; base yeşil; açık 5 PR). |
| CH-18 | Düzeltme | V3 F033 olgunluğu | 'base kırmızı' ifadesi bayat; 6b174dc'den beri dependency-supply-chain PASS. |
