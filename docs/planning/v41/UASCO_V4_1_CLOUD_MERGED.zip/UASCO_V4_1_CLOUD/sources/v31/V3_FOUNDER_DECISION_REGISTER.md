<!-- Makine-eşleştirilebilir kaynak: aynı adlı .json/.csv dosyaları. Bu tablo onlardan üretildi. -->

# V3_FOUNDER_DECISION_REGISTER (V3.1 DRAFT)

Hiçbir karar verilmedi; öneriler bağlayıcı değildir.

| Id | Karar | Sınıf | Gerekçe | Gereken doğrulama | Öneri (karar değil) | Bloke ettiği | Bağlantı | Durum |
|---|---|---|---|---|---|---|---|---|
| D-01 | V3.1'in tek yetkili roadmap olması; eski planların arşivi | APPROVABLE_NOW | İçerik kapanış verisiyle uzlaştırıldı (16d3a925); karar yalnız yön belirler, uygulama başlatmaz | Fark analizi tamamlandı (bu revizyon, §0) | Onaylanmaya aday | UASCO-T0120, UASCO-T0099 | RW-015, FD-H (Plan A0 + yazılı yeniden başlatma talimatı; yeniden başlatma bu kararla ayrı verilir) | AWAITING_FOUNDER |
| D-02 | v1 kapsamı: R1 = kaynak teslimi; PR R3; deploy P4 ayrı karar | APPROVABLE_NOW | R1'i küçük tutar; geri dönüşü ucuz | — | (a) kaynak teslimi | UASCO-T0038, UASCO-T0039, UASCO-T0040 | RW-016 | AWAITING_FOUNDER |
| D-03 | Windows sandbox yaklaşımı: WSL2 (#231) | NEEDS_VERIFICATION | Founder-PC sanallaştırma/WSL2 durumu ve #231'in güncel base'e uyumu doğrulanmadı | V3-T1019 kontrol listesi + FA-5 gerçek kabul | WSL2; sandbox'sız host modu önerilmez | UASCO-T0031 → R1 kritik yolu | RW-004, FA-5 | AWAITING_FOUNDER |
| D-04 | Birleşik SHA CI: native merge queue mi, zorunlu up-to-date + seri tren mi | NEEDS_VERIFICATION | Native merge queue'nun bu kişisel hesap reposunda kullanılabilirliği doğrulanmadı (UNVERIFIED); up-to-date CI süresini artırır (FD-E) | GitHub ayarlarında merge queue seçeneğinin varlığı | Varsa merge queue; yoksa up-to-date + V3-T1008 seri kural | V3-T1020 | TD-V2-05, FD-E | AWAITING_FOUNDER |
| D-05 | Builder/Reviewer GitHub App'leriyle kimlik ayrımı | DEFERRABLE | R1'i bloke etmiyor; P2 başında gerekli; App ile required check kurulumu doğrulanmalı | App oluşturma ve ruleset'te required check olarak tanınması | P2 başında karar | UASCO-T0072, UASCO-T0097 | RW-008, RW-023 | AWAITING_FOUNDER |
| D-06 | Ledger ↔ founder-authority köprüsü (FD-10/FD-F) | APPROVABLE_NOW | Kök neden kanıtlı (M.1); değişiklik geliştirme altyapısında, T2 (Founder onaylı) PR ile | — | Onay adayı | V3-T1004 | FD-10, FD-F | AWAITING_FOUNDER |
| D-07 | Trust-root reseal: tek seferde değil, iki batch | NEEDS_VERIFICATION | #231 gerçek ortam kabulü yokken aynı reseal'e girmesi kritik yolu kilitler; #251/#247 içeriği güncel base'e göre yeniden doğrulanmalı (199-263 commit geride) | #251/#247 rebase + delta review | Batch 1 = RW-006 + #251 + #247; Batch 2 = #231 (FA-5 sonrası) | UASCO-T0069, UASCO-T0031, UASCO-T0100 | FA-4, FD-B | AWAITING_FOUNDER |
| D-08 | Haftalık geliştirme bütçesi ve dağılımı | APPROVABLE_NOW | Ölçüm (UASCO-T0111) bütçeyi sonradan kalibre eder; başlangıç değeri gerekir | — | Örnek %60 build / %20 review / %10 supervisor / %10 yedek; %90'da sert durma | UASCO-T0110 | RW-003 | AWAITING_FOUNDER |
| D-09 | Ürün içi ücretli API ve ikinci sağlayıcı | DEFERRABLE | P3'e kadar gerekli değil; sağlayıcı seçenekleri UNVERIFIED_INTEGRATION | V3-T1030 spike sonuçları | P3'te T3 kararı | UASCO-T0066 | RW-037 | AWAITING_FOUNDER |
| D-10 | Rol stratejisi: 599 rol → arketip + paket | NEEDS_VERIFICATION | Yön makul ama arketip sayısı ve eşik eval verisi olmadan seçilemez | V3-T1017 golden eval v0 sonuçları | Yön olarak not edilsin; kesin karar P2 | UASCO-T0059, V3-T1029 | §9.1 | AWAITING_FOUNDER |
| D-11 | #66 Electron E2E: SUPERSEDED | APPROVABLE_NOW | Ortak geçmiş yok (merge-tree: unrelated histories, M.5); RW-024 güncel base'de yeniden kurulur | — | SUPERSEDED | UASCO-T0096, UASCO-T0095 | FA-6, FD-C | AWAITING_FOUNDER |
| D-12 | Yerel V6/Task Scheduler/worker durdurma | APPROVABLE_NOW | Durum UNKNOWN; durdurma düşük riskli; worker yalnız SHADOW | FA-7 PowerShell kontrol çıktısı | Durdur ve raporla | PAUSED_VERIFIED, V3-F023 | FD-07, FD-G | AWAITING_FOUNDER |
| D-13 | Code-signing sertifikası | DEFERRABLE | R1 imzasız kabul ediyor; P2 başında gerekli | Sertifika türü/maliyet araştırması | P2 başı | UASCO-T0093 | RW-022 | AWAITING_FOUNDER |
| D-14 | Repo görünürlüğü public kalır | APPROVABLE_NOW | Mevcut durum; Actions ücretsiz | — | Public kalsın | UASCO-T0113 | RW-021 | AWAITING_FOUNDER |
| D-15 | Mobil ve ses (gizlilik) | DEFERRABLE | P4 kapsamı | — | P4, G3 sonrası | UASCO-T0082, UASCO-T0018 | RW-038, RW-073 | AWAITING_FOUNDER |
| D-16 | Faz maliyet sınırları | APPROVABLE_NOW | Yalnız P0–P1 sınırları onaya hazır; P2+ R1 ölçümlerine bağlı (NEEDS_VERIFICATION) | P2+ için R1 run maliyet verisi | P0–P1 sınırlarını onayla, P2+ ertele | Tüm fazlar | §10 | AWAITING_FOUNDER |
| D-17 | Base-red politikası: merge-freeze, build-freeze değil | APPROVABLE_NOW | Merge güvenliği korunur; bağımsız geliştirme durmaz | — | Onay adayı | V3-T1007 | Zorunlu düzeltme 5 | AWAITING_FOUNDER |
| D-18 | CI shard provenance kuralları (attempt birleştirme) | APPROVABLE_NOW | Güvenlik açığı kapatır; #251 kapsamıyla birleşir | — | Onay adayı | V3-T1002, V3-T1003 | COORD-001, #251 | AWAITING_FOUNDER |
| D-19 | SEC-PROFILE-R1 ve pre-dev kalite eşiği | NEEDS_VERIFICATION | Araçların Founder-PC'ye kurulabilirliği ve eşik değeri ölçülmedi | V3-T1010, V3-T1013 | Profil: yerleşik secret + gitleaks + SCA; eşik R1 sonrası | V3-T1010, UASCO-T0026 | Zorunlu düzeltme 8 | AWAITING_FOUNDER |
| D-20 | Sıra: Windows CI kararlılığı ile #231 paralel mi (FD-A) | APPROVABLE_NOW | Store-lock ve aggregator düzeltmesi küçük ve bağımsız; #231 rebase'i paralel yürüyebilir, merge'ü CI kararlılığına bağlı | — | Paralel; #231 merge'ü V3-F038 AC1-AC2 sonrası | V3-T1001, UASCO-T0031 | FD-A | AWAITING_FOUNDER |
| D-21 | IR: token yenile mi, IR'ı emekli et mi (FD-D) | APPROVABLE_NOW | Required değil; merge'leri engellemiyor; her PR'da FAIL gürültüsü | — | Token yenile + P2'de App'e taşı | V3-T1034 | FA-3, FD-D | AWAITING_FOUNDER |
| D-22 | #282 yeniden ele alma ölçütü | APPROVABLE_NOW | Kabul ölçütü raporda tanımlı (3 ardışık yeşil Windows + base kontrol) | — | Ölçütü kabul et | UASCO-T0090 | Rapor P | AWAITING_FOUNDER |
