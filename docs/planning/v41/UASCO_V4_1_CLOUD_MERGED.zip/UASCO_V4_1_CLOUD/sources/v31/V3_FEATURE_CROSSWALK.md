<!-- Makine-eşleştirilebilir kaynak: aynı adlı .json/.csv dosyaları. Bu tablo onlardan üretildi. -->

# V3_FEATURE_CROSSWALK (V3.1 DRAFT)

| V3 Feature | Legacy | Epic | Ad | Mevcut olgunluk | Kabul fazı | Bağımlılık | Task'lar | AC'ler | Teslim senaryosu |
|---|---|---|---|---|---|---|---|---|---|
| V3-F030 | UASCO-F030 | V3-E0 | Trust root ve korunan yollar | SEALED (373 dosya), imzasız | P2 | V3-F056 | UASCO-T0068, UASCO-T0069, UASCO-T0070, UASCO-T0071 | V3-AC-F030-1, V3-AC-F030-2, V3-AC-F030-3 | INTERNAL |
| V3-F031 | UASCO-F031 | V3-E0 | Kimlik ayrımı ve ruleset | yok (0 onay) | P2 | V3-F042, V3-F056 | UASCO-T0072 | V3-AC-F031-1 | INTERNAL |
| V3-F033 | UASCO-F033 | V3-E0 | Bağımlılık tedarik zinciri kapısı | Kapı çalışıyor; base kırmızı | P2 | — | UASCO-T0075, UASCO-T0076, UASCO-T0077 | V3-AC-F033-1, V3-AC-F033-2 | INTERNAL |
| V3-F034 | UASCO-F034 | V3-E0 | Repo güvenlik taraması | kapalı | P2 | — | UASCO-T0078 | V3-AC-F034-1 | INTERNAL |
| V3-F038 | UASCO-F038 | V3-E0 | CI hattı (ubuntu + 3 Windows shard + aggregator) | Çalışıyor; şu an base-wide kırmızı; flaky | P2 | V3-F054 | UASCO-T0087, UASCO-T0088, UASCO-T0089, UASCO-T0090, UASCO-T0091, V3-T1001, V3-T1007 | V3-AC-F038-1, V3-AC-F038-2, V3-AC-F038-3 | INTERNAL |
| V3-F041 | UASCO-F041 | V3-E0 | Windows desktop E2E CI | Linux harness CLAIMED | P2 | V3-F001, V3-F038 | UASCO-T0094, UASCO-T0095, UASCO-T0096 | V3-AC-F041-1 | INTERNAL |
| V3-F042 | UASCO-F042 | V3-E0 | Bağımsız review yolu | Workflow canlı, ai-review skipped | P2 | — | UASCO-T0097, UASCO-T0098, V3-T1034 | V3-AC-F042-1, V3-AC-F042-2 | INTERNAL |
| V3-F043 | UASCO-F043 | V3-E0 | Founder yetki kaydı ve kararlar | Serbest metin | P1 | V3-F048 | UASCO-T0099, UASCO-T0100, UASCO-T0101, UASCO-T0102 | V3-AC-F043-1 | INTERNAL |
| V3-F044 | UASCO-F044 | V3-E0 | Self-hosted runner hijyeni | UNKNOWN (API 403) | P0 | — | UASCO-T0103 | V3-AC-F044-1 | INTERNAL |
| V3-F045 | UASCO-F045 | V3-E0 | Geliştirme düzlemi orkestrasyonu | Gerçek, günlük kullanımda; SPOF | P1 | V3-F046, V3-F048 | UASCO-T0104, UASCO-T0105, UASCO-T0106, UASCO-T0107, UASCO-T0108, UASCO-T0109, UASCO-T0128 | V3-AC-F045-1, V3-AC-F045-2 | INTERNAL |
| V3-F046 | UASCO-F046 | V3-E0 | Kota ve bütçe kontrolü | yok | P1 | — | UASCO-T0110, UASCO-T0111, UASCO-T0112, UASCO-T0113 | V3-AC-F046-1, V3-AC-F046-2, V3-AC-F046-3 | INTERNAL |
| V3-F047 | UASCO-F047 | V3-E0 | Rutin ve oturum hijyeni | 4 trigger kapatıldı; 2'si Founder'da | P2 | — | UASCO-T0114, UASCO-T0115, UASCO-T0116, UASCO-T0117, UASCO-T0118 | V3-AC-F047-1, V3-AC-F047-2 | INTERNAL |
| V3-F048 | UASCO-F048 | V3-E0 | Tek görev kaydı ve tek roadmap | dağınık, bayat | P2 | — | UASCO-T0119, UASCO-T0120, UASCO-T0121, UASCO-T0122, UASCO-T0123, V3-T1005, V3-T1006, V3-T1021 | V3-AC-F048-1, V3-AC-F048-2, V3-AC-F048-3 | INTERNAL |
| V3-F049 | UASCO-F049 | V3-E0 | Kanıt saklama | artifact'lar siliniyor | P0 | — | UASCO-T0124 | V3-AC-F049-1 | INTERNAL |
| V3-F023 | UASCO-F023 | V3-E0 | Yerel + bulut lease (FA-LEASE2) | CODED, bağlı değil | P3 | V3-F045 | UASCO-T0050, UASCO-T0051, V3-T1033 | V3-AC-F023-1, V3-AC-F023-2 | INTERNAL |
| V3-F052 | NEW:N3 | V3-E0 | Merge kuyruğu / birleşik CI | NONE (V3.1 yeni Feature) | P2 | V3-F038, V3-F054 | V3-T1008, V3-T1020 | V3-AC-F052-1, V3-AC-F052-2 | INTERNAL |
| V3-F053 | NEW:N4 | V3-E0 | Ledger ↔ Founder-authority köprüsü | NONE (V3.1 yeni Feature) | P1 | — | V3-T1004 | V3-AC-F053-1 | INTERNAL |
| V3-F054 | NEW:N5 | V3-E0 | CI sonuç provenance'ı ve shard toplama | NONE (V3.1 yeni Feature) | P0 | — | V3-T1002, V3-T1003, V3-T1036 | V3-AC-F054-1, V3-AC-F054-2, V3-AC-F054-3 | INTERNAL |
| V3-F001 | UASCO-F001 | V3-E1 | Electron kabuğu + paketli backend başlatma | VERIFIED_REAL_ENV (yalnız CI runner) | P2 | V3-F039 | UASCO-T0001, UASCO-T0002, UASCO-T0003, UASCO-T0004, V3-T1019 | V3-AC-F001-1, V3-AC-F001-2, V3-AC-F001-3 | DS-R1-WEB |
| V3-F002 | UASCO-F002 | V3-E1 | UI kabuğu ve renderer → Control API | INTEGRATED + TESTED(unit) | P2 | V3-F001 | UASCO-T0005, UASCO-T0006, UASCO-T0007, UASCO-T0008 | V3-AC-F002-1, V3-AC-F002-2, V3-AC-F002-3 | DS-R2-INSTALL |
| V3-F010 | UASCO-F010 | V3-E1 | Güncelleme ve geri alma | PLANNED (manuel NSIS hook CODED) | P4 | V3-F040 | UASCO-T0024, UASCO-T0127 | V3-AC-F010-1, V3-AC-F010-2 | DS-R2-INSTALL |
| V3-F039 | UASCO-F039 | V3-E1 | Windows installer build | VERIFIED_REAL_ENV (CI); release yok | P1 | — | UASCO-T0092 | V3-AC-F039-1, V3-AC-F039-2 | DS-R1-WEB |
| V3-F040 | UASCO-F040 | V3-E1 | İmzalı sürüm | yok | P2 | V3-F030, V3-F039 | UASCO-T0093 | V3-AC-F040-1 | DS-R2-INSTALL |
| V3-F003 | UASCO-F003 | V3-E2 | Intake ve tek komut alanı | INTEGRATED + TESTED(unit) (form); komut alanı PLANNED | P2 | V3-F004 | UASCO-T0009, UASCO-T0010, UASCO-T0011 | V3-AC-F003-1, V3-AC-F003-2 | DS-R2-SPEC |
| V3-F004 | UASCO-F004 | V3-E2 | Görev/plan/çalıştırma ekranları ve Founder akışı | INTEGRATED + TESTED(unit); Linux Electron CLAIMED | P1 | V3-F012 | UASCO-T0012, UASCO-T0013, UASCO-T0014 | V3-AC-F004-1 | DS-R1-WEB |
| V3-F007 | UASCO-F007 | V3-E2 | Ses girişi | PLANNED | P4 | V3-F003 | UASCO-T0018 | V3-AC-F007-1 | DS-R4-VOICE |
| V3-F011 | UASCO-F011 | V3-E2 | Pre-dev zinciri (BA, Requirements, Architecture, Plan, UxSpec) | TESTED(unit), sahte builder | P2 | V3-F025, V3-F055 | UASCO-T0025, UASCO-T0026, V3-T1013 | V3-AC-F011-1, V3-AC-F011-2 | DS-R1-WEB |
| V3-F050 | NEW:N1 | V3-E2 | Ürün içi Epic → Feature → Task + AC hiyerarşisi | NONE (V3.1 yeni Feature) | P2 | V3-F011 | V3-T1022, V3-T1023 | V3-AC-F050-1, V3-AC-F050-2 | DS-R2-SPEC |
| V3-F012 | UASCO-F012 | V3-E3 | Implement + review runner | INTEGRATED + TESTED(unit); bir kez canlı (2026-10-14) | P1 | V3-F013, V3-F025 | UASCO-T0027, UASCO-T0028, UASCO-T0029 | V3-AC-F012-1, V3-AC-F012-2 | DS-R1-WEB |
| V3-F013 | UASCO-F013 | V3-E3 | Sandbox'ta test yürütme | Linux: CODED + CI; Windows: yok | P1 | — | UASCO-T0030, UASCO-T0031 | V3-AC-F013-1, V3-AC-F013-2, V3-AC-F013-3 | DS-R1-WEB |
| V3-F014 | UASCO-F014 | V3-E3 | Güvenlik aşaması | TESTED(unit), sahte binary | P2 | V3-F013 | UASCO-T0032, UASCO-T0033, UASCO-T0129, V3-T1010 | V3-AC-F014-1, V3-AC-F014-2, V3-AC-F014-3 | DS-R1-WEB |
| V3-F029 | UASCO-F029 | V3-E3 | Test-surface bütünlük koruması | INTEGRATED + TESTED(unit) | BASE | — | UASCO-T0067 | V3-AC-F029-1 | DS-R1-WEB |
| V3-F005 | UASCO-F005 | V3-E4 | Teslim kartı ve dışa aktarma | CODED, Desktop export kırık | P1 | V3-F030 | UASCO-T0015, UASCO-T0016 | V3-AC-F005-1 | DS-R1-WEB |
| V3-F006 | UASCO-F006 | V3-E4 | Akıllı revizyon | PLANNED | P4 | V3-F003, V3-F050 | UASCO-T0017 | V3-AC-F006-1 | DS-R4-REVISION |
| V3-F015 | UASCO-F015 | V3-E4 | Kaynak teslimi ve kabul | INTEGRATED + TESTED(unit) | P1 | V3-F005 | UASCO-T0034, UASCO-T0035 | V3-AC-F015-1 | DS-R1-WEB |
| V3-F017 | UASCO-F017 | V3-E4 | Müşteri repo'suna PR teslimi | PLANNED | P3 | V3-F015, V3-F056 | UASCO-T0038, UASCO-T0039 | V3-AC-F017-1 | DS-R3-PR |
| V3-F018 | UASCO-F018 | V3-E4 | Dokümantasyon üretimi | DESIGNED (registry) | P4 | V3-F015 | UASCO-T0041 | V3-AC-F018-1 | DS-R4-DOCS |
| V3-F057 | NEW:N8 | V3-E4 | Teslim doğrulama etiketleri ve bağımsız yeniden üretim | NONE (V3.1 yeni Feature) | P1 | V3-F013, V3-F014, V3-F015 | V3-T1011, V3-T1012 | V3-AC-F057-1, V3-AC-F057-2 | DS-R1-WEB |
| V3-F019 | UASCO-F019 | V3-E5 | Tek mission runner (lease, fencing, retry, remediation) | INTEGRATED + TESTED(unit) | P1 | — | UASCO-T0042, UASCO-T0043, UASCO-T0044 | V3-AC-F019-1, V3-AC-F019-2 | DS-R1-WEB |
| V3-F020 | UASCO-F020 | V3-E5 | Crew/team çalışma zamanı | CODED + TESTED(unit), bağlı değil | P3 | V3-F024, V3-F051 | UASCO-T0045, UASCO-T0046 | V3-AC-F020-1 | DS-R3-ENGINE |
| V3-F021 | UASCO-F021 | V3-E5 | Paralel çalışma ve görev dağıtımı | yok | P3 | V3-F020, V3-F051 | UASCO-T0047, V3-T1035 | V3-AC-F021-1 | DS-R3-ENGINE |
| V3-F022 | UASCO-F022 | V3-E5 | Duraklatma, devam, kurtarma | GLOBAL_STOP INTEGRATED | P2 | V3-F019 | UASCO-T0048, UASCO-T0049, V3-T1016, V3-T1018 | V3-AC-F022-1, V3-AC-F022-2 | DS-R1-WEB |
| V3-F024 | UASCO-F024 | V3-E5 | Rol bağlama ve hazırlık ölçümü | 9 rol bağlı; 6/21 V2 maddesi merge | P3 | V3-F055 | UASCO-T0052, UASCO-T0053, UASCO-T0054, UASCO-T0055, UASCO-T0056, UASCO-T0057, UASCO-T0058, UASCO-T0059 | V3-AC-F024-1 | DS-R3-ENGINE |
| V3-F025 | UASCO-F025 | V3-E5 | Claude CLI executor çifti ve ProviderPort | INTEGRATED; paketli uygulamada UNKNOWN | P1 | — | UASCO-T0060, UASCO-T0061, V3-T1014 | V3-AC-F025-1, V3-AC-F025-2 | DS-R1-WEB |
| V3-F026 | UASCO-F026 | V3-E5 | Model yönlendirme | CODED çekirdek, bağlı değil | P3 | V3-F025, V3-F027 | UASCO-T0062, UASCO-T0063, V3-T1028, V3-T1029 | V3-AC-F026-1, V3-AC-F026-2 | DS-R3-ENGINE |
| V3-F027 | UASCO-F027 | V3-E5 | Token/maliyet ölçümü | yok | P2 | V3-F025 | UASCO-T0064, V3-T1015 | V3-AC-F027-1, V3-AC-F027-2 | DS-R2-COCKPIT |
| V3-F028 | UASCO-F028 | V3-E5 | Failover, ikinci sağlayıcı, yerel model | DESIGNED (OmniRoute yalnız keşif) | P3 | V3-F026, V3-F055 | UASCO-T0065, UASCO-T0066, V3-T1030 | V3-AC-F028-1 | DS-R3-ENGINE |
| V3-F051 | NEW:N2 | V3-E5 | Görev güdümlü yürütme | NONE (V3.1 yeni Feature) | P3 | V3-F050, V3-F019 | V3-T1031, V3-T1032 | V3-AC-F051-1, V3-AC-F051-2 | DS-R3-ENGINE |
| V3-F055 | NEW:N6 | V3-E5 | Golden değerlendirme seti | NONE (V3.1 yeni Feature) | P2 | V3-F025 | V3-T1017, V3-T1037 | V3-AC-F055-1, V3-AC-F055-2 | DS-R3-ENGINE |
| V3-F009 | UASCO-F009 | V3-E6 | Masaüstü ve yürütme sertleştirmesi | TESTED(unit) + kısmen VERIFIED_REAL_ENV (CI) | P4 | — | UASCO-T0021, UASCO-T0022, UASCO-T0023, UASCO-T0125, UASCO-T0126 | V3-AC-F009-1, V3-AC-F009-2, V3-AC-F009-3 | DS-SEC-NEG |
| V3-F032 | UASCO-F032 | V3-E6 | Action-gateway politikası | INTEGRATED, sabit ALLOW | P2 | V3-F056 | UASCO-T0073, UASCO-T0074 | V3-AC-F032-1 | DS-SEC-NEG |
| V3-F056 | NEW:N7 | V3-E6 | Birleşik yetki matrisi | NONE (V3.1 yeni Feature) | P2 | V3-F053 | V3-T1025, V3-T1026 | V3-AC-F056-1, V3-AC-F056-2 | DS-SEC-NEG |
| V3-F008 | UASCO-F008 | V3-E7 | Founder Cockpit: ilerleme, bildirim, rapor ve maliyet | INTEGRATED (in-app) | P4 | V3-F027 | UASCO-T0019, UASCO-T0020, V3-T1027 | V3-AC-F008-1, V3-AC-F008-2, V3-AC-F008-3 | DS-R2-COCKPIT |
| V3-F035 | UASCO-F035 | V3-E7 | Mobil tasarım ve salt-okur çekirdek | DESIGNED + TESTED(unit, local) | P4 | — | UASCO-T0079, UASCO-T0080, UASCO-T0081 | V3-AC-F035-1 | DS-R4-MOBILE |
| V3-F036 | UASCO-F036 | V3-E7 | Mobil uygulama ve gateway | DESIGNED | P4 | V3-F035, V3-F056 | UASCO-T0082, UASCO-T0083, UASCO-T0084, UASCO-T0085 | V3-AC-F036-1 | DS-R4-MOBILE |
| V3-F037 | UASCO-F037 | V3-E7 | Uzaktan onay ve STOP | DESIGNED | P4 | V3-F036 | UASCO-T0086 | V3-AC-F037-1 | DS-R4-MOBILE |
| V3-F016 | UASCO-F016 | V3-E8 | Müşteri stack, şablon ve yaşam döngüsü | 3 basit Node şablonu | P4 | V3-F012 | UASCO-T0036, UASCO-T0037, UASCO-T0040 | V3-AC-F016-1, V3-AC-F016-2, V3-AC-F016-3 | DS-R4-DEPLOY |

## Epic kabul kuralları

| Epic | Ad | Legacy Epic'ler | Senaryo | Kural | Release |
|---|---|---|---|---|---|
| V3-E0 | Fabrika temeli (geliştirme düzlemi) | UASCO-E05, UASCO-E07, UASCO-E08, UASCO-E09, UASCO-E03 | DS-OPS-01 | Zaman penceresi kuralı: ardışık 14 gün boyunca CI pass ≥ hedef, bütçe aşımı 0, kayıt sapması 0, SPOF kaynaklı duruş 0. Tekrar sayısı değil, pencere ölçülür. | R2 |
| V3-E1 | Kur ve çalıştır | UASCO-E01, UASCO-E07 | DS-R2-INSTALL | Temiz kurulum + onarım + kaldırma 2 farklı Windows makinesinde (Founder + ikinci kullanıcı) ve 1 upgrade (dev.N→N+1) veri kaybısız. Her makinede 1 kez yeterli. | R2 |
| V3-E2 | Fikirden spesifikasyona | UASCO-E01, UASCO-E02 | DS-R2-SPEC | 3 farklı proje fikri (en az 2 proje tipi): tek komut → Epic/Feature/Task+AC → Founder onayı/revizyonu; Founder kalite puanı ≥ eşik (eşik Founder kararı D-19). Çeşitlilik tekrar yerine geçer. | R2 |
| V3-E3 | İnşa ve doğrulama | UASCO-E02, UASCO-E05 | DS-R1-WEB/LIB + DS-R2-QA | R1: 3 ardışık gerçek run (2 proje tipi). R2: toplam 5 run, ≥1 tohumlanmış başarısız test remediation ile düzeltilmiş, ≥1 tohumlanmış secret güvenlik aşamasında yakalanmış. | R2 |
| V3-E4 | Teslim | UASCO-E01, UASCO-E02 | DS-R1-WEB/LIB + DS-R3-PR | R1: 3 ardışık teslim, her biri bağımsız yeniden üretimle (UASCO dışında build+test). R3: 1 gerçek müşteri repo'suna PR, Founder merge eder. | R3 |
| V3-E5 | Yürütme motoru (ajan + model) | UASCO-E03, UASCO-E04 | DS-R3-ENGINE | İstatistiksel kural: golden eval ≥20 vaka/arketip başarı oranı eşik üstü; kota simülasyonu 2 kez checkpoint'ten devam; 2 paralel run çakışmasız; model id her adımda kayıtlı. | R3 |
| V3-E6 | Ürün içi güven ve kontrol | UASCO-E01, UASCO-E05 | DS-SEC-NEG | Negatif test seti %100 (bypass, onaysız R3 aksiyon, sertifikasız adapter, replay). Her release'de bir kez yeniden koşulur; mekanik 3 tekrar yok. | R2 |
| V3-E7 | İzleme, Cockpit ve uzaktan kontrol | UASCO-E01, UASCO-E06 | DS-R2-COCKPIT + DS-R4-MOBILE | R2: Founder 5 iş günü boyunca durum/engel/maliyet bilgisini yalnız Cockpit'ten aldı (kullanım kaydı). R4: telefondan STOP gerçek run'ı durdurdu (1 kez + replay negatif). | R4 |
| V3-E8 | Stack ve yaşam döngüsü genişliği | UASCO-E02 | DS-R3-STACK2 + DS-R4-DEPLOY | Desteklenen her stack için 1 gerçek uçtan uca; deploy kapsamı evetse 1 deploy + rollback + izleme kanıtı. | R4 |
