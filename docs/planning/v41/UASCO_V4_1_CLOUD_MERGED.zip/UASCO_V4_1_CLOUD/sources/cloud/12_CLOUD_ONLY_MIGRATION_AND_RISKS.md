# 12 — Cloud-Only Migration / Blockers / Honest Limits

## Mandatory replacements
- #231 local Windows WSL2 branch: NOT MERGE AS IS; replace `defaultSandboxProviderFor(win32)=WSL2` with remote cloud gateway; add cloud worker and test gate.
- D-03 now chooses cloud runtime; D-23 is only local installation/UAT; D-26 OS client compatibility; D-12 only cloud supervisor; D-19 scanning in cloud; D-29 provider identity cloud-side.
- UASCO-T0108 now hosted Windows CI worker; legacy local process/Task Scheduler requirement removed.
- Security tools, Node, native Claude Code, npm/git and test packages run only cloud-side; no Windows local prerequisite.
- Windows UI/client `CLOUD_RUNTIME_NOT_CONFIGURED` if no remote service; never WSL fallback.

## Important limits
- A verified, secure always-on cloud sandbox endpoint and persistence provider were NOT supplied. User approvals for cloud spend/keys need to be requested when relevant. No claim that Claude Cloud alone supplies third-party production code execution.
- This input is 52-file original V4.1 Candidate (175 Task); newer Claude **PATCHED 241** not uploaded. `14_*` MUST merge these targeted changes with latest 241 Task records, typed dependencies, security tiers and sim tests. Do not replace the newer 241 matrix with this 190 Task file or downgrade gates.
- The `sources/original_v41_outputs/` and `sources/v31`, `sources/v4`, `sources/audit` folders preserve historical evidence; old WSL instructions in those archives are **NOT ACTIVE**.
- R1 estimates based on #231 40–120h are now STALE. New cloud provider estimates are provisional; no delivery date guarantees.
- Code for cloud runtime and cloud client has NOT been committed. Real acceptance is still 0.
