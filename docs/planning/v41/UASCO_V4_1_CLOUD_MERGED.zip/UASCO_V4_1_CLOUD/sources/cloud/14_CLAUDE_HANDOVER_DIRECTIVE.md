# 14 — CLAUDE'UN MEVCUT V4.1 PATCHED TASARIM OTURUMUNA VERİLECEK TEK TALİMAT

Bu dosyayla birlikte bütün cloud-only revizyon ZIP'ini yükle. Mevcut en son `UASCO_V4_1_FINAL_CANDIDATE_PATCHED.zip` (241 Task; typed dependency, reseal-lock, sim/verify, 63 manifest) çalışma kaynağın olsun.

**KODLAMA BAŞLATMA, REPO'YA YAZMA, PR/MERGE/CI ÇALIŞTIRMA.** Bu iş mevcut yürütme dosyalarının son **cloud-only** mimariye revizyonu. Yeni roadmap tasarlama.

1. `00_BASLA_BURADAN`, `11_CLOUD_RUNTIME_ARCHITECTURE_AND_SECURITY`, `12_CLOUD_ONLY_MIGRATION_AND_RISKS`, `02_V4_1_EXECUTION_MATRIX.json` ve `06_V4_1_FOUNDER_DECISION_CENTER.json` oku.
2. Bu revizyon 175 Task özgün bazından üretildi, senin son 241-Task PATCHED paketinden değil. **Son 241 Task'ı koru**; yalnız `cloudOnlyOverride` olan mevcut Task'ların id/name/work/done/targetFiles/typed deps/startGates/mergeGates/authority owner'larını yeni cloud yönergesine göre güncelle; 15 `CLOUD-T0001..0015` Task'ını ekle (çift kayıt varsa diff uygula). Korumalı dosyaları T2/Opus/Founder onayıyla koru.
3. 102 AC'nin kimliklerini koru; eskiden Founder-PC WSL/CLI test isteyen AC'leri cloud e2e + Founder UAT olarak ortam bazlı düzelt, evidence PASS sayacı hâlâ 0.
4. #231 WSL2 branch'i AS-IS merge edilmez; cloud provider adapter, remote API, async job queue, cloud model gateway, hosted Windows runner planla. **Claude Cloud kodlama ortamının doğrudan güvenli müşteri sandbox sağlayıcısı olduğu varsayımını yapma**; worker/deploy/secret/bütçe ayrı verified gate.
5. 09 directive ve 01 roadmap, 02 task matrix, 03 graph, 04 model/lane, 05 acceptance, 06 decisions, 07 reconciliation, 08 cost, 10 integrity, 11 architecture aynı cloud-only kurallarıyla üret; eski yerel WSL/worker/Founder-PC code/security test talimatları aktif dosyalarda kalmasın. Kaynak arşivdeki eski metni aktif talimat gibi kullanma.
6. Özellikle PATCHED setin 10 dispatch sim, typed deps, reseal lock, independent reviewer, kit SHA, 8h/24h timeout ve 1–3 slot korunmalı. UAT öncesi cloud e2e CI ve Windows hosted installer PASS zorunlu. `UASCO-T0002` yalnız normal Founder kur/aç/kullan kabulü.
7. `verify.py`: 57 features, tüm Task ID refs, 102 AC, 31 Founder decision IDs, cycle 0, T2 sensitive paths, file claims 0 conflict, 10 sims 0 deadlock; SHA manifest and reproducibility. Cloud-runtime UNKNOWN ise READY_FOR_CODING olabilir, **PRODUCT_READY değil**.
8. Tek ZIP ve SHA manifest; sadece düzeltmeler ve gerçek blokajlar içeren kısa rapor.

**Founder'ın nihai hedefi:** Claude bütün kodlama, model, test, security, sandbox, CI ve teslimi bulutta yürütsün. Founder kendi Windows 10 Home bilgisayarında sadece `.exe` kurup UI'den normal kullanıcı kabulünü yapsın. Hiçbir BIOS/WSL/VM/Node/Claude CLI veya yerel worker şartı getirilemez.
