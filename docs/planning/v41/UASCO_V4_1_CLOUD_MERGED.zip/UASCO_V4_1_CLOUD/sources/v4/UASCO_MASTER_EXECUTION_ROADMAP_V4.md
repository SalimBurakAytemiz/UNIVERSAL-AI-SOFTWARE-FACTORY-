# UASCO MASTER EXECUTION ROADMAP V4

**Durum:** `PROPOSAL / EXECUTION-READY AFTER SOURCE RECONCILIATION`. Bu belge ChatGPT tarafından hazırlanmış **yeni icra planıdır**; GitHub'da kod, CI, PR, yetki veya otomasyon değiştirilmedi. V3.1'i ve mevcut çalışan kodu koruyup işi teslim dalgalarına ayırır.

**Ana hedef:** Gerçek, kurulu Windows uygulamasında ön yüz → Control API → AI analiz → görev → kod → izole test ve güvenlik → bağımsız teslim/PR. Son ürün tek Windows `.exe` installer'ı ve onun yüklediği UASCO Desktop uygulamasıdır. Kurulum paketinin üretilmesi ile işlevlerin tümünün doğrulanması farklı statülerdir.

## 0. Doğrulanan gerçek başlangıç (2 Kasım 2026)

- Repository: `SalimBurakAytemiz/UNIVERSAL-AI-SOFTWARE-FACTORY-`; branch `v7/integration`; son okunan SHA `16d3a925b8a3f4ffc08dea2ea64c53862a7bcb03`.
- Push `CI` run **41434581692 = SUCCESS**; `Windows Installer` run **41434581581 = SUCCESS**.
- Installer artifact **13135209964**, adı `uasco-windows-installer-41434581581-1`, **111.397.611 bayt** ZIP artifact; GitHub'da görünen son erişim tarihi **2026-12-02**. Bunun içindeki `.exe` dosyasının yerel kurulumunu bu oturumda bizzat yürütmedik.
- `package.json` sürümü **0.7.0-dev.3**, Node `>=24`, `npm run dist:win`, `npm run installer:test`, `npm run validate`, `npm run typecheck`, `npm test` komutlarını içeriyor. Electron ve electron-builder bağımlılıkları var; installer derleyicisinin Windows/offline ön koşulları gözlenmeli.
- #294 merge, #282 açık ve CI iki denemede başarısız; #251, #247, #231, #66 açık. Bunların tamamı aynı seviyede ürün-kritik değil.
- Ana repo için resmi GitHub Release mevcut sorguda **0**. **Installer artifact var** ama gerçek Founder-PC'de tam E2E kabulü bulunmuyor.
- V3.1'in **57 Feature** kaydı mevcut ve bu pakete taşındı. **129 legacy + 35 önerilen Task = 164** ile **102 AC** V3.1'in iddiasıdır; orijinal `V3_TASK_DEPENDENCY_MATRIX` ve `V3_ACCEPTANCE_EVIDENCE_MATRIX` dosyaları bu sohbette teslim edilmedi. Bu nedenle tüm Task/AC bağımlılıklarının doğrulandığı veya 164'ünün de hazır paketlendiği iddia edilmez.

## 1. Beş zorunlu yürütme ilkesi

1. **Kodlama beklemez:** Sistemsel blocker başka lane'in bağımsız yazılım geliştirmesini durdurmaz. Ama güvenli merge ve gerçek teslim kanıtı bloke olan dosyada bekler.
2. **Her commit teslim adımına bağlanır:** PR sayısı değil, `Windows .exe'de çalışan demo + API çağrısı + test + kabul kanıtı` ölçülür.
3. **Tek işin sahibi vardır:** En çok **3 aktif builder lane**, tek merge controller, **taze ve bağımsız reviewer**. İki builder aynı dosyayı eş zamanlı değiştirmez.
4. **Model maliyeti göreve göre:** Deterministik işlemde model kullanılmaz; küçük iş Haiku, günlük geliştirme Sonnet, karmaşık mimari ve zor hata Opus. Opus sürekli supervisor yapılmaz.
5. **Güvenlik/sahiplikten sahte PASS üretilmez:** CI kırmızıysa paketlemenin mevcut yeşil SHA'sı korunur; test bypass edilmez, `PARTIAL` sonucu `VERIFIED` yazılmaz. T2/T3 yetkileri ve gerçek müşteri dağıtımı Founder kararı gerektirir.

## 2. Yürütme motorunun kesin görev sözleşmesi

Her Task işlenmeden önce aynı şema ile **execution packet** oluşturulur:

```json
{
  "id":"V3-Txxxx-or-UASCO-Txxxx",
  "featureId":"V3-Fxxx",
  "wave":"W0..W5",
  "owner":"A_UI|B_API|C_ENGINE|D_CI_RELEASE|E_CONTROL",
  "model":"haiku|sonnet|opus|deterministic",
  "baseSha":"current SHA",
  "dependsOn":["verified task IDs"],
  "allowPaths":["exact owned files/dirs"],
  "description":"small observable outcome",
  "acceptanceCriteria":["observable scenario"],
  "validationCommands":["minimal targeted test","relevant integration test"],
  "reviewPolicy":"independent SHA-bound review",
  "authorityTier":"T0|T1|T2|T3",
  "contextDigest":"hash of short references",
  "artifactPaths":["real output/evidence links"],
  "status":"READY|RUNNING|BLOCKED|REVIEW|MERGED|ACCEPTED",
  "retryCount":0,
  "costUsage":{"inputTokens":null,"outputTokens":null,"charge":null}
}
```

**Kimlik ve referans çözümleme:** İlk çalışmada V3.1'e eşlik eden 5 kayıt dosyasının özellikle JSON'larını ve kanonik `UASCO_REMAINING_WORK.json` dosyasını yükle. 57 Feature/164 Task/102 AC/kanıt kimliklerini doğrula; yalnız gerçek kaynakta bulunan ID'ler kullanılabilir. `orphan=0`, `duplicate=0`, `cycle=0`, `missing AC reference=0` olmalı. Sorun varsa **etkilenen alt ağaç** BLOCKED_SOURCE olur; diğer READY işler beklemez. 29 adet bilinen R1 Task'ı `UASCO_EXECUTION_MANIFEST_V4.json` içinde seed olarak verilir; bunlar tam 164'ün yerine geçmez. Belgeyle kaynak çelişirse yeni gerçek GitHub kanıtı ve kullanıcı onaylı kaynak üstün, düzeltme ve audit kaydı zorunludur.

**Task bölme:** Bir Task'ın çıktı ve dosya sahipliği birbirinden bağımsızsa küçük alt işlere ayrılır; mevcut kanonik ID korunur, yeni alt kimlikler `parentId/subtaskId` olarak türetilir. Tek alt iş tek bir test edilebilir davranış değişimi hedefler; sırf PR artırmak için bölünmez. Aynı dosyada paralellik yok, shared refactor bir owner'a atanır. Her görev: `DISCOVER → PLAN ≤1 sayfa → CODE → TARGETED_TEST → REVIEW → INTEGRATION → PR → MERGE → EXE_SMOKE → ACCEPTED`. Her gereksiz ara durumda yeni model çağrısı yapılmaz.

**Başarısızlık:** Aynı commit+aynı failure fingerprint için en fazla bir otomatik retry. Yeni kanıt üretmeyen tekrar yok. Bir Sonnet düzeltmesi daha başarısız olursa Opus tek seferlik dar teşhis verir, Sonnet uygular. Kök neden ayrılmıyorsa `BLOCKED_WITH_EVIDENCE`; bir sonraki bağımsız Task yürütülür. Ana dalı yeşil gösteren sahte skip/boş test yasak. Şüpheli güvenlik taraması sonuçlarında fail-closed.

## 3. Lane mimarisi ve dosya sahipliği

| Lane | Sorumluluk | İş başına varsayılan | Fiziksel sınır |
|---|---|---|---|
| `A_UI` | Desktop UI, ekran etkileşimleri, görünür gerçek iş akışı | Sonnet; stil/tekrar Haiku | `apps/desktop/renderer/**`; `main.mjs/preload.mjs` T2 kontrolü altında |
| `B_API` | Fastify Control API, predev, delivery, veri şemaları | Sonnet | `apps/control-api/src/**`, `core/workos/predev/**`; ortak core için file claim |
| `C_ENGINE` | MissionRunner, sandbox, task DAG, crew, model executor | Sonnet; karmaşık lease/sandbox Opus planı | `core/workos/**` (predev hariç), `core/agents/**` |
| `D_CI_RELEASE` | Windows installer, build, CI/shard, güvenlik, release | Sonnet; kritik kök neden Opus | `scripts/build-installer.mjs`, `installer/**`, `.github/workflows/**`, `config/trust-root*` protected |
| `E_CONTROL` | Görev/ledger, yetki, maliyet, review orchestration, mobil hazır olunca mobil | Haiku + deterministik; gerektiğinde Sonnet | `governance/**`, `automation/**`, `apps/mobile/**`; diğer alanlarla file claim |

**Aktif sınır:** En çok 3 builder lane; örneğin A+B+C. D ve E aynı anda sürekli kod üretmez; planlama/CI ve kayıt işlemlerini olaylarla tetikler. Bir shared dosya gerektiğinde o anda tek owner değişikliği yapar. Repo geneli tarama/çoklu uzun koordinatör oturumu yok; seed dosyalardan import graph ve diff ile noktasal arama. Her Task bitince kısa deltalı rapor ve bağlam sıfırlama/özetleme uygulanır.

## 4. Model yönlendirme ve token disiplini

| Görev tipi | Varsayılan model | Ne zaman yükseltilir | Kanıt / sınır |
|---|---|---|---|
| Kaynak keşfi, etiketleme, changelog, test sonucu kırpma, küçük mekanik edit | **Haiku** | Kod bağlamı/açık risk büyürse Sonnet | Değişiklik deterministik lint/test ile doğrulanır |
| UI bileşenleri, TypeScript/React/Electron, API ve route entegrasyonu, unit/E2E testleri | **Sonnet** | 2 farklı hipotez başarısızsa Opus teşhisi | Dar dosya kümesi; iş başına 1 test grubu |
| Sandbox, trust root, lease, kilit, izin sistemi, yarış koşulu, çakışan mimari | **Opus (tek odaklı tasarım/teşhis)** | Kodlamaya Sonnet devam eder | Opus sonsuz supervisor olmaz |
| Önceki commit/test kanıtının ayrıştırılması ve task sıralaması | **Deterministik kod; gerekirse Haiku** | Bileşen sınırı belirsizse Sonnet | Aynı şeyi tekrar tekrar LLM'e okutma |
| Bağımsız review | **Taze, salt-okur Sonnet/Opus** | Güvenlik veya kritik sistem değişikliklerinde Opus | Builder ile ayrı kimlik, ayrı context, tam SHA/patch |


- Claude Code'da o hesabın kullanılabilir modellerini `/model` ile doğrula; desteklenmeyen modeli seçip tekrar döngüsü oluşturma. Önerilen aileler: **Haiku 5.5, Sonnet 5.5, Opus 5.5**; mevcut oturumda gerçek erişim doğrulanmalıdır. Model adlarını körlemesine repository config'ine pinleme.
- `scope`: İlgili Task'ın doğrudan dosyaları ve bağlantı noktaları. Tüm repo, tüm 210 KB rapor, tüm başarılı test logları ayrı ayrı ajanlara gönderilmez.
- **Tek sayfalık context pack:** kullanıcı amacı + AC + base SHA + ilgili 3–10 sembol + gerekli test + en fazla 30 satır gerçek hata. Her ajan çıkışını `{changedFiles, tests, evidence, remainingBlocker, tokensUsed}` olarak kısa formatta verir.
- Paylaşılan kanıt hash'i aynıysa ikinci kez modelle incelettirme; sonuç deterministik cache'den gelsin. 599 katalog rolünü her görev için 599 ayrı oturum olarak başlatma.
- **Gerçek maliyet sınırı:** Kullanıcı açıkça tutar vermediği için haftalık $ limiti atanmamıştır. Mevcut hesap kotaları ve token kullanımı kaydedilir; ücretli yeni API/secret otomatik açılmaz. Kullanım %80'de uyarı, %95'te yeni düşük öncelikli görev açma; başlatılmış bağımsız işler kontrollü checkpoint'e alınır. Mümkünse önce cache ve deterministik araç kullan.
- Tahmini çağrı dağılımı **Sonnet ağırlıklı (%60–75), Haiku (%20–35), Opus (%5–10)** bir *başlangıç yönlendirme hedefidir*, gerçek token/yük ve kaliteye göre dinamik değişir; taahhüt edilmiş tasarruf değildir. Opus seçimine somut gerekçe gerekir.
- Testler, `npm`, `tsc`, `git`, `SHA`, `node`, static analysis deterministic yürütülür, LLM konuşmalarıyla taklit edilmez.

## 5. Teslim dalgaları: her dalgada gerçek `.exe`

| Dalga | İlk sonuç | Kritik bağımlılıklar | Teslim ölçütü |
|---|---|---|---|
| **W0: BASE EXE NOW** | Halihazırdaki Windows installer artifact'ını al, kur, sağlığını ölç | Windows ortamı | Kurulum, açılış, API health ve ilk ekranın gerçek kanıtı; başarısızsa hata paketinin kendisi ilk Task olur |
| **W1: WORKING END-TO-END EXE** | Fikir → gerçek AI analiz → implement → sandbox test → security → ZIP, bağımsız build | #231 Windows sandbox + T2 yetkisi; export/CLI keşfi | İki Node örneğinde 3 ardışık gerçek E2E ve kurulabilir installer |
| **W2: FACTORY COCKPIT / PLAN / API** | Tüm temel ekranlar ve Epic/Feature/Task/AC, canlı API ve görev panosu | W1 çekirdeği; source task matrix | Mock'suz kullanışlı Desktop UI, ekran→API→veri→state gerçek kanıtı, yeni `.exe` |
| **W3: AUTONOMOUS FACTORY** | Görev DAG çalıştırma, çoklu model, bütçe/fallback, crew, kontrollü paralellik, GitHub PR teslimi | W2 plan şeması ve reviewer/lease | Görev güdümlü gerçek müşteri projesi teslimi; kota kesilse bile resume, yeni `.exe` |
| **W4: DESKTOP HARDEN / RELEASE / STACKS** | İmzalama kararı, güvenilir güncelleme, yeni stack'ler, güçlü security/QA, revizyon, dokümantasyon | W1–W3 ürün çekirdeği | Clean install + upgrade/rollback + bağımsız örnek stack testleri, release artifact |
| **W5: EXTENSIONS** | Mobil companion, uzaktan STOP/onay, ses | Güvenli auth ve W4 release altyapısı | Gerçek cihaz E2E, gizlilik/izin, replay negatifleri |

**W0, W1, W2, W3 bittiğinde ortaya çıkanlar aynı ürünün artan kabiliyetli kurulum sürümleridir; yeni repolar veya ayrı ürünler değildir.** W4/W5 nihai vizyonu genişletir; her şeyin ilk `exe` için bitmesini bekleme. Her wave sonunda `latest-known-good` SHA tutulur; bozuk ana dal mevcut başarılı installer teslimini silmez.

## 6. Sıralı kritik yol ve paralellik

```
GitHub green base + Windows installer artifact [mevcut]
  ├── W0: gerçek Windows kurulum / UI-health doğrula [hemen]
  ├── D lane: Windows store-lock + shard provenance (#251) [paralel]
  ├── A lane: desktop export ve gerçek UI köprüleri [paralel]
  ├── B lane: pre-dev gerçek model ve API uçtan uca [paralel]
  └── C lane: #231 WSL2 sandbox + trust-root onay kapsamı [kritik]
               ↓
     Güvenli Windows izolasyonu + gerçek model + export
               ↓
     W1: 3 gerçek demo / 2 farklı proje tipi / Windows installer
               ↓
     W2: tek komut, Epic/Feature/Task, Founder UX, API + test
               ↓
     W3: görev DAG, crew, model routing/fallback, PR teslim
               ↓
     W4/W5: release hardening, ek stack, mobil/ses
```

- W0 ve W1 bağımsız kod işleri CI flake nedeniyle bekletilmez. **Sadece merge güvenliğinin kanıtı yoksa merge bekler.**
- `#282` salt teşhis değişikliği: bloklayıcı değilse DEFER; `#251` shard provenance ve CI korumaları güvenli şekilde entegre edilir; `#247` 16.8 GB geçici dosya sızıntısı öncelik, `#231` Windows sandbox **kritik yol**, `#66` önce delta analizi, mevcut çözümler tarafından karşılanıyorsa SUPERSEDED.
- `#251/#247/#231` ortak trust-root dosya çakışmaları tek sahibi olan T2 lane'de sıralı ve yetkili mühürlenir; gelişigüzel auto-reseal yok.
- Yerel V6/Task Scheduler UNKNOWN: gerçek Windows bilgisayarda yetki/oturum çakışması varsa önce durumu kanıtla; iki supervisor aynı işi başlatamaz.
- `Windows 11 + WSL2` kaynak R1 kabulünün ortamıdır. Kullanıcının gerçek OS'si doğrulanmadan mevcut Founder-PC'nin uygun olduğu varsayılmaz. Windows 10 destek hedefi varsa ayrı uyumluluk matrisi gerekir; sandbox yok diye izolesiz kodu host'ta çalıştırmak geçerli fallback değildir.

## 7. Teslim paketleri: doğrudan kodlanacak işler

### PK-00 | Acil Windows installer teslimi

**Dalga:** `W0` · **Sahip:** `D_CI_RELEASE + A_UI` · **Model:** Sonnet/Haiku.

**Odak dosyalar:** `scripts/build-installer.mjs; installer/**; apps/desktop/**`.

**İş:** Başarılı CI artifact 13135209964 indir, ZIP içindeki .exe adını, SHA256 ve Windows uyumluluğunu doğrula. Kurulum, kaldırma, ilk açılış, backend health, hata ekranını test et. Test edilemeyen OS için NOT_RUN yaz.

**Kabul:** EXE artefact + SHA + kurulum checklist + ekran görüntüsü/hata logu.

### PK-01 | Windows Sandbox ve trust-root

**Dalga:** `W1` · **Sahip:** `C_ENGINE + D_CI_RELEASE` · **Model:** Opus tasarım/teşhis, Sonnet kod.

**Odak dosyalar:** `core/workos/execution-gate.ts; apps/control-api/src/packaged-entry.ts; #231; config/trust-root-manifest.json`.

**İş:** WSL2 veya karşılaştırmalı yalıtım seçimi; #231 delta incelemesi, korunan yol yetkisi, gerçek Windows ortamında ağ/yol negatif testleri. Host üzerinde kısıtsız kod çalıştırmayı PASS sayma.

**Kabul:** Sandbox testCommand PASS/FAIL + fail-closed negatifleri.

### PK-02 | Gerçek model ile predev

**Dalga:** `W1` · **Sahip:** `B_API` · **Model:** Sonnet.

**Odak dosyalar:** `core/workos/predev/**; core/workos/intake.ts; apps/control-api/src/routes/**`.

**İş:** Intake→BA→Requirements→Architecture→Plan gerçek model kanıtı, Founder onayı, kaybolmayan artifact/ID.

**Kabul:** 3/3 gerçek predev kanıtı ve hash.

### PK-03 | Implement, test, remediation, security

**Dalga:** `W1` · **Sahip:** `C_ENGINE + B_API` · **Model:** Sonnet + Opus on demand.

**Odak dosyalar:** `core/workos/runner.ts; core/workos/security-tools.ts; core/workos/secret-scan.ts; core/workos/executors.ts`.

**İş:** Gerçek runner sandbox üzerinde implement→test→remediation→review→güvenlik. SECURITY PARTIAL ürün VERIFIED etiketi doğuramaz.

**Kabul:** 3 ardışık run, 1 seeded failure onarımı, seeded secret FAIL.

### PK-04 | Desktop export, bağımsız build ve teslim

**Dalga:** `W1` · **Sahip:** `A_UI + B_API` · **Model:** Sonnet.

**Odak dosyalar:** `apps/desktop/main.mjs; apps/desktop/renderer/**; core/workos/zip.ts; delivery route`.

**İş:** Export, secrets scrub, sha, ZIP temiz klasörde UASCO dışı npm ci && npm test.

**Kabul:** Teslim ZIP + sha + bağımsız PASS (web-node/node-lib).

### PK-05 | Frontend UX ve gerçek Control API

**Dalga:** `W2` · **Sahip:** `A_UI + B_API` · **Model:** Sonnet; mekanik stil Haiku.

**Odak dosyalar:** `apps/desktop/renderer/**; apps/desktop/preload.mjs; apps/control-api/src/routes/**`.

**İş:** Siyah-kırmızı-beyaz tasarım sistemini mevcut kodda işlet; Founder Cockpit, intake, artifacts, task board, live run, QA/Security, models/cost, delivery, settings. Loading/empty/error/retry her ekran; fake/stub hiçbir route VERIFIED sayılmaz.

**Kabul:** Her ekranın gerçek route/response ve etkileşim kanıtı + exe smoke.

### PK-06 | Epic → Feature → Task + AC uygulama içi

**Dalga:** `W2` · **Sahip:** `B_API + A_UI` · **Model:** Sonnet.

**Odak dosyalar:** `core/workos/plan.ts; core/workos/store.ts; apps/control-api/src/routes/**; apps/desktop/renderer/**`.

**İş:** Kullanıcı fikri → predev plan → stable Epic/Feature/Task IDs + DAG + AC; Founder edit/approve + UI.

**Kabul:** Bir fikirde plan DAG görüntüleme, düzenleme, restart persistence.

### PK-07 | Görev DAG ve ekip yürütme

**Dalga:** `W3` · **Sahip:** `C_ENGINE` · **Model:** Opus dependency checkpoint; Sonnet kod.

**Odak dosyalar:** `core/workos/task-selector.ts; core/workos/runner.ts; core/workos/crew/**`.

**İş:** Görev başına lease, idempotent claim, retry, kanıt ve rol ataması; çakışan işler seri, bağımsız işler kontrollü paralel.

**Kabul:** Task DAG gerçek run ve crash-resume; duplicate side-effect sıfır.

### PK-08 | Model yönlendirme, kota ve fallback

**Dalga:** `W3` · **Sahip:** `C_ENGINE + E_CONTROL` · **Model:** Sonnet; Opus politika.

**Odak dosyalar:** `core/workos/executors.ts; core/workos/claude-profiles.ts; config/omniroute-policy.json`.

**İş:** Model id/provenance/usage ölçümü önce; Haiku/Sonnet/Opus model routing, ücretli/fallback sadece izin verilen sağlayıcıda; rate-limit → checkpoint ve pause. Anahtarları hiçbir loga yazma.

**Kabul:** En az iki erişilebilir model/sağlayıcı kontrolü + sentetik quota failover kanıtı; bulunamıyorsa BLOCKED_UNAVAILABLE.

### PK-09 | GitHub PR teslimi ve review/merge kontrolü

**Dalga:** `W3` · **Sahip:** `B_API + D_CI_RELEASE` · **Model:** Sonnet; Opus risk kararı.

**Odak dosyalar:** `GitHub delivery adapter; .github/workflows/**; config/**`.

**İş:** Müşteri repo ayrımı, PR teslimi, bağımsız reviewer, merge queue ya da güvenli seri tren, Founder T2/T3 yetkileri.

**Kabul:** Gerçek test repo PR, SHA-bound review, yanlış yetki negatif testi.

### PK-10 | CI flake düzeltmesi, shard provenance ve Windows E2E

**Dalga:** `W1-W4` · **Sahip:** `D_CI_RELEASE` · **Model:** Opus kök neden, Sonnet kod.

**Odak dosyalar:** `scripts/validate-shards.mjs; .github/workflows/ci.yml; core/workos/store.ts; #251/#282`.

**İş:** Store-lock ve shard yeniden kullanım probleminde SHA/run/partition/test manifest/jobreport provenance. CI gerçekten başarısızsa merge durur; bağımsız iş akışı sürer. Flake sonucu gizleme.

**Kabul:** Tekrarlanabilir Windows CI, aggregator negatif testleri, runner artifacts.

### PK-11 | Kurulum, release, rollback, güvenlik sertleştirme

**Dalga:** `W4` · **Sahip:** `D_CI_RELEASE + A_UI` · **Model:** Sonnet; Opus yüksek risk.

**Odak dosyalar:** `installer/**; scripts/build-installer.mjs; apps/desktop/main.mjs; apps/desktop/preload.mjs`.

**İş:** Installer, update/uninstall/data migration, signing kararı, Windows E2E, Electron security, SAST/SCA/SBOM ve zaman bazlı regresyon.

**Kabul:** İndirilebilir sürüm, temiz upgrade+rollback+uninstall kanıtı.

### PK-12 | Ek müşteri stack, akıllı revizyon ve dokümantasyon

**Dalga:** `W4` · **Sahip:** `B_API + C_ENGINE + A_UI` · **Model:** Sonnet.

**Odak dosyalar:** `core/workos/project-templates.ts; templates/**; docs/**; renderer/**`.

**İş:** Node dışında seçilen müşteri stacklerinde gerçek scaffold/test/build; akıllı revizyon ve doküman deliverable; desteklenen matrisi açık belirt.

**Kabul:** Stack başına bağımsız build/test + revizyon demo.

### PK-13 | Mobil companion, ses ve uzaktan STOP

**Dalga:** `W5` · **Sahip:** `A_UI + E_CONTROL` · **Model:** Sonnet, basit UX Haiku.

**Odak dosyalar:** `apps/mobile/**; apps/control-api/src/routes/**`.

**İş:** Eşleştirme, MFA/oturum, mobil push ve STOP yetkisi, onay attestation, ses için açık izin ve gizlilik.

**Kabul:** Gerçek cihazda negatif replay ve STOP testleri.

### PK-14 | Orkestratör maliyet ve görev defteri

**Dalga:** `W0-W3` · **Sahip:** `E_CONTROL` · **Model:** Deterministik + Haiku + Sonnet.

**Odak dosyalar:** `current register/ledger; .ai/**; kanonik rapor`.

**İş:** Tek yetkili görev state; 57 Feature + task matrisi reconcile. Merge→Task durum adayı; PASS kanıtı olmadan COMPLETE yok. Supervisor tek sahip, idle no-op çağrısı yok.

**Kabul:** 0 duplicate ID, 0 orphan AC, task queue planlanabilir ve evidence bağlı.

## 8. Ürün arayüzünün minimum işlev standardı

- Görsel sistem: **siyah / kırmızı / beyaz**, okunaklı tipografi, tutarlı spacing, responsive desktop breakpoints; mevcut görünümü kaybetmeden örnek ekranlar ve UI snapshot'ları. UI kütüphanesi seçimi mevcut koda bağlı kalmalı, yeniden yazma gerekçelendirilmelidir.
- Başlangıç: Dashboard/Founder Cockpit; proje açma, tek komut, BA-Requirements-Architecture-Plan onayları, Epic/Feature/Task, iş kuyruğu, canlı run, agent/model, test/security kanıtı, teslim, log ve ayarlar erişilebilir.
- Her ekran sözleşmesi: kullanıcı aksiyonu → IPC/preload izinli çağrı → `/v1/...` API → server state → journal/evidence → UI state; loading/empty/error/permission denied/timeout/retry ayrımı.
- **73/73 route bağlı** iddiası HTTP/response smoke ile yeniden kontrol edilir. Sadece route'un mevcut olması fonksiyonun gerçek iş yaptığı anlamına gelmez. Mock/Fake yalnız testte; kurulu ürünün önemli aksiyonlarında gerçek karşılık aranır.
- Zorunlu ekran gözden geçirme: uygulamanın kurulu `.exe` sürümünden alınan ekran görüntüsü, en az bir gerçek proje akışı video/log kanıtı; tasarımcı onayı olmayan resim değil, işlevsel UI.
- Her yeni feature merge'ünden sonra sadece ilgili renderer/API smoke; her milestone sonunda Windows installer + E2E.

## 9. Kontroller, merge ve kanıt (hızlı ama güvenilir)

1. Preflight: yalnız değişen yolların lint/typecheck/unit testi. `npm run validate` gerektiği yerde ve merge-train üzerinde koşar; her ara edit'te tüm 1000+ testi koşturmak yok.
2. Tek owner'lı PR patch. PR'da Task ID, base SHA, diff, test komutu, test kanıtı, risk tier, ürün kabiliyeti yazılı olur.
3. T0/T1 için mevcut ruleset ve reviewer şartları sağlanınca auto-merge; birleştirilmiş SHA full CI ve Windows installer doğrulaması. CI başarısızsa yanlış yeşil verilmez.
4. Native merge queue kullanılabiliyorsa merge_group üzerinde test; erişilemiyorsa **seri tren**: branch update + birleşik SHA doğrulaması + merge. Eski #291/#288 gibi ayrı ayrı yeşil ama birlikte kırmızı hatalara izin yok.
5. Windows flake: job conclusion + runId + SHA + attempt + partition + test manifest karşılaştırılır. GitHub API'den alınan son job verdict ile uyuşmayan shard PASS sayılmaz. `PASS_AFTER_RETRY` ayrı raporlanır. `Re-run failed jobs` aggregator eksik artifact'i gizlemez.
6. Gate düzeyleri: `BUILD_OK`, `INSTALLER_OK`, `API_UI_OK`, `E2E_REAL_OK`, `SECURITY_ACCEPTED`, `DELIVERY_ACCEPTED`, `FOUNDER_ACCEPTED`. Bir önceki adım geçmeden bir üst durumu yazma.
7. Kırmızı CI, başka lane'in dosya bağımsız işini engellemez; ancak kırmızı base'e doğrulanmamış merge ve sahte release yapılamaz. Çok eski veya koşması imkânsız testleri sessizce silme/skip yapma. Sahipli, süreli karantina kanıtlı olmalı.
8. Kanıt artifact'ları digest + kısa manifest ile saklanır; geçmiş JSON kayıtları ve gerçek `.exe` SHA'sı raporda görünür.

## 10. Çalışma çevrimi: karar değil icra

```text
A. RECONCILE (1 kez): kaynak JSON + GitHub, dedupe, DAG; sonra yalnız delta
B. SELECT: topolojik READY Task, kullanılabilir dosya sahibi, değer/kritik yol
C. ROUTE: no-LLM / Haiku / Sonnet / Opus, dar context pack
D. IMPLEMENT: 2-3 paralel dosya-ayrık builder; checkpoint; hedef test
E. REVIEW: bağımsız aynı SHA, P0/P1 blocker fix; tek bounded remediation
F. INTEGRATE: merge-train/CI güvenli ise auto-merge
G. PACKAGE: her W0–W5 sonunda Windows installer ve smoke
H. REPORT: accepted Feature/E2E/EXE SHA, token/maliyet, blockers ve sonraki 3 iş
```

**Duruş şartı:** Kullanım limiti, insan onayı gereken korumalı yol veya erişilemeyen Windows ortamı varsa `BLOCKED_xxx` ve deterministik kanıt. Bağımsız işler sürer. API kotası aşılırsa yeni ücretli hesap açılmaz; işler checkpoint'e alınır. GitHub'a otomatik push veya merge başarısızsa yanlış başarı ilan edilmez.

**Kritik kalite:** Ürün kodu en az bir çalışan demo yeteneği eklemiyorsa ve yalnız rapor/araç sayısını büyütüyorsa kapsamı gözden geçir. Önce mevcut modülleri bağla; yeniden yazma gerekmezse yenisini açma. Kod üretimi yerine gerçek teslim değerini optimize et.

## 11. Founder için baştan alınacak az sayıdaki zorunlu karar

- **Windows ve WSL2:** Gerçek PC'nin Windows sürümü ve sanallaştırma desteği; #231 için hangi ortamda acceptance yapılacağı.
- **T2 birleşik reseal:** #251/#247/#231 protected paths, trust root ve yetkili güvenlik testleriyle seri merge izni. Otomatik olarak kendine onay veremez.
- **Geliştirme bütçesi:** Claude üyelik/kota ortamı; ücretli API harcaması için ayrı tutar ve süreli onay. Ücretsiz fallback'in doğrulanmamış modellere geçmesi review bağımsızlığını düşürmemeli.
- **Güvenli PR stratejisi:** Native merge queue mevcutsa etkinleştirme, değilse seri merge treni.
- **Reviewer kimliği:** Geçersiz `CLAUDE_CODE_OAUTH_TOKEN` yenileme veya ayrı doğrulanmış reviewer servisi; kullanıcı secret'ı chat veya loglarda paylaşmaz.
- **Yerel otomasyon:** V6/Task Scheduler durumu, aynı Task üzerinde ikinci kontrol düzlemi olmadığının doğrulanması.

Karar gelmeyen `T2/T3` alt iş parçası bloklu kalır; diğer Feature'ların kodlamasına engel olmaz. Founder'a her 10 dakikada soru sorulmaz; birleştirilmiş tek karar listesi verilir.

## 12. Başarı ve teslim şablonu

**Gösterge paneli**: `currentBaseSHA`, `latestExeArtifactURL`, `latestExeSHA256`, `installerTestStatus`, `liveWindowsAcceptance`, `workingScreens/totalScreens`, `API_real/totalAPI`, `endToEndScenariosPassed`, `legacyTasksVerified/expected`, `featuresAccepted/57`, `featuresStable7d/57`, `activeLanes`, `blockedCriticalTasks`, `effectiveTokens`, `measuredCost`, `usageLimitState`.

**İlk hedef:** W0 gerçek Windows kurulum. **Ürün ilk hedefi:** W1'de iki farklı proje tipi için çalışan fikirden ZIP'e akış. **Esas hedef:** W3'te komuttan müşteri PR'ına görev ve model güdümlü fabrika. **Tüm kapsam:** W4/W5 ile release, mobil ve ses dahil nihai Feature seti.

**Raporda asla denmeyecekler:** “599 ajan aktif”, “57 Feature tamam”, “testler kesin başarılı”, “exe teslim edildi” demek için ilgili CI/E2E/artifact/kurulu Windows kanıtı yoksa. `UNKNOWN`, `NOT_RUN`, `BLOCKED` ayrı tutulur.

## 13. V3.1 kapsamının eksiksiz taşınması: 57 Feature

Aşağıdaki her Feature bir dalgaya atanmıştır; görev alt bağımlılıkları yalnız gerçek orijinal Task Matrix import edilince kesinleşir. `Kabul fazı`, kaynak V3.1'in fazıdır; `V4 dalgası` geliştirme/entegrasyon önceliğidir, kaynak verinin üstüne yazılmaz.

| V3.1 Feature | Epic | V4 dalgası | Kod sahibi | Açıklama | V3.1 kabul fazı |
|---|---|---|---|---|---|
| V3-F001 | V3-E1 | W0 | D_CI_RELEASE | Electron kabuğu + paketli backend başlatma | P2 |
| V3-F002 | V3-E1 | W0 | A_UI | UI kabuğu ve renderer → Control API | P2 |
| V3-F039 | V3-E1 | W0 | A_UI | Windows installer build | P1 |
| V3-F004 | V3-E2 | W1 | A_UI | Görev/plan/çalıştırma ekranları ve Founder akışı | P1 |
| V3-F005 | V3-E4 | W1 | A_UI | Teslim kartı ve dışa aktarma | P1 |
| V3-F011 | V3-E2 | W1 | B_API | Pre-dev zinciri (BA, Requirements, Architecture, Plan, UxSpec) | P2 |
| V3-F012 | V3-E3 | W1 | C_ENGINE | Implement + review runner | P1 |
| V3-F013 | V3-E3 | W1 | C_ENGINE | Sandbox'ta test yürütme | P1 |
| V3-F014 | V3-E3 | W1 | B_API | Güvenlik aşaması | P2 |
| V3-F015 | V3-E4 | W1 | B_API | Kaynak teslimi ve kabul | P1 |
| V3-F019 | V3-E5 | W1 | C_ENGINE | Tek mission runner (lease, fencing, retry, remediation) | P1 |
| V3-F025 | V3-E5 | W1 | C_ENGINE | Claude CLI executor çifti ve ProviderPort | P1 |
| V3-F029 | V3-E3 | W1 | D_CI_RELEASE | Test-surface bütünlük koruması | BASE |
| V3-F030 | V3-E0 | W1 | D_CI_RELEASE | Trust root ve korunan yollar | P2 |
| V3-F038 | V3-E0 | W1 | D_CI_RELEASE | CI hattı (ubuntu + 3 Windows shard + aggregator) | P2 |
| V3-F043 | V3-E0 | W1 | E_CONTROL | Founder yetki kaydı ve kararlar | P1 |
| V3-F044 | V3-E0 | W1 | D_CI_RELEASE | Self-hosted runner hijyeni | P0 |
| V3-F045 | V3-E0 | W1 | E_CONTROL | Geliştirme düzlemi orkestrasyonu | P1 |
| V3-F046 | V3-E0 | W1 | E_CONTROL | Kota ve bütçe kontrolü | P1 |
| V3-F049 | V3-E0 | W1 | D_CI_RELEASE | Kanıt saklama | P0 |
| V3-F053 | V3-E0 | W1 | D_CI_RELEASE | Ledger ↔ Founder-authority köprüsü | P1 |
| V3-F054 | V3-E0 | W1 | D_CI_RELEASE | CI sonuç provenance'ı ve shard toplama | P0 |
| V3-F057 | V3-E4 | W1 | B_API | Teslim doğrulama etiketleri ve bağımsız yeniden üretim | P1 |
| V3-F003 | V3-E2 | W2 | A_UI | Intake ve tek komut alanı | P2 |
| V3-F008 | V3-E7 | W2 | A_UI | Founder Cockpit: ilerleme, bildirim, rapor ve maliyet | P4 |
| V3-F022 | V3-E5 | W2 | C_ENGINE | Duraklatma, devam, kurtarma | P2 |
| V3-F027 | V3-E5 | W2 | B_API | Token/maliyet ölçümü | P2 |
| V3-F032 | V3-E6 | W2 | B_API | Action-gateway politikası | P2 |
| V3-F041 | V3-E0 | W2 | A_UI | Windows desktop E2E CI | P2 |
| V3-F042 | V3-E0 | W2 | D_CI_RELEASE | Bağımsız review yolu | P2 |
| V3-F048 | V3-E0 | W2 | E_CONTROL | Tek görev kaydı ve tek roadmap | P2 |
| V3-F050 | V3-E2 | W2 | A_UI | Ürün içi Epic → Feature → Task + AC hiyerarşisi | P2 |
| V3-F055 | V3-E5 | W2 | C_ENGINE | Golden değerlendirme seti | P2 |
| V3-F056 | V3-E6 | W2 | E_CONTROL | Birleşik yetki matrisi | P2 |
| V3-F017 | V3-E4 | W3 | B_API | Müşteri repo'suna PR teslimi | P3 |
| V3-F020 | V3-E5 | W3 | C_ENGINE | Crew/team çalışma zamanı | P3 |
| V3-F021 | V3-E5 | W3 | C_ENGINE | Paralel çalışma ve görev dağıtımı | P3 |
| V3-F023 | V3-E0 | W3 | C_ENGINE | Yerel + bulut lease (FA-LEASE2) | P3 |
| V3-F024 | V3-E5 | W3 | C_ENGINE | Rol bağlama ve hazırlık ölçümü | P3 |
| V3-F026 | V3-E5 | W3 | C_ENGINE | Model yönlendirme | P3 |
| V3-F028 | V3-E5 | W3 | C_ENGINE | Failover, ikinci sağlayıcı, yerel model | P3 |
| V3-F031 | V3-E0 | W3 | D_CI_RELEASE | Kimlik ayrımı ve ruleset | P2 |
| V3-F051 | V3-E5 | W3 | C_ENGINE | Görev güdümlü yürütme | P3 |
| V3-F052 | V3-E0 | W3 | D_CI_RELEASE | Merge kuyruğu / birleşik CI | P2 |
| V3-F006 | V3-E4 | W4 | A_UI | Akıllı revizyon | P4 |
| V3-F009 | V3-E6 | W4 | D_CI_RELEASE | Masaüstü ve yürütme sertleştirmesi | P4 |
| V3-F010 | V3-E1 | W4 | A_UI | Güncelleme ve geri alma | P4 |
| V3-F016 | V3-E8 | W4 | B_API | Müşteri stack, şablon ve yaşam döngüsü | P4 |
| V3-F018 | V3-E4 | W4 | B_API | Dokümantasyon üretimi | P4 |
| V3-F033 | V3-E0 | W4 | D_CI_RELEASE | Bağımlılık tedarik zinciri kapısı | P2 |
| V3-F034 | V3-E0 | W4 | D_CI_RELEASE | Repo güvenlik taraması | P2 |
| V3-F040 | V3-E1 | W4 | A_UI | İmzalı sürüm | P2 |
| V3-F047 | V3-E0 | W4 | E_CONTROL | Rutin ve oturum hijyeni | P2 |
| V3-F007 | V3-E2 | W5 | A_UI | Ses girişi | P4 |
| V3-F035 | V3-E7 | W5 | E_CONTROL | Mobil tasarım ve salt-okur çekirdek | P4 |
| V3-F036 | V3-E7 | W5 | E_CONTROL | Mobil uygulama ve gateway | P4 |
| V3-F037 | V3-E7 | W5 | E_CONTROL | Uzaktan onay ve STOP | P4 |

## 14. Task matrix entegrasyonu ve dürüstlük kuralı

- Bu paket **57 Feature + V3.1'in tam §4.2.1 R1 Task tablosundan çıkarılmış seed'ler** içerir; 164 Task'ın machine-readable tam matrisi **bu sohbette mevcut değildir**. 164'ü hayalî açıklamalarla doldurmak söz konusu değildir.
- Claude, V3.1'in orijinal `V3_TASK_DEPENDENCY_MATRIX.json`, `V3_FEATURE_CROSSWALK.json`, `V3_ACCEPTANCE_EVIDENCE_MATRIX.json`, `V3_FOUNDER_DECISION_REGISTER.json` ve `UASCO_REMAINING_WORK.json` kaynaklarını bulup hash'lerle doğrular. Erişim yoksa 57 feature kaynak tablosunu ve doğrulanmış mevcut seedleri kullanarak bağımsız işleri yürütür; eksikleri `SOURCE_REQUIRED` olarak raporlar.
- Topolojik sıralama yalnız kanıtlı bağımlılıklardan üretilir. Her Task'a **en az bir AC** ve gerçek test ortamı atanır. Özel karar gerekmiyorsa Claude tekrar kullanıcıdan onay istemez.
- `v7/integration` değişirse yeni SHA ile diff-only rebase; eski base'e ait kanıtı yeni SHA'ya taşımadan önce güvenli geçerlilik kontrolü gerekir.

## 15. Founder'a gösterilecek tek kısa rapor

```text
UASCO V4 / tick <UTC>
Current integration SHA: ... | Latest verified exe: ... | real Windows install: PASS/FAIL/NOT_RUN
Wave: W# | accepted features: x/57 | E2E passed: x/y | working screens: x/y
In-flight: A: task-id; B: task-id; C: task-id
Merged verified: ... | blocked critical: 1-line reason + required authority
Tokens: Haiku X / Sonnet Y / Opus Z; spend: measured or UNKNOWN
Next ready tasks: ...
```

Uzun ara monolog, sonsuz kontrol raporu veya yeni yol haritası isteme. Çalışma kanıtı ve teslim üret.
