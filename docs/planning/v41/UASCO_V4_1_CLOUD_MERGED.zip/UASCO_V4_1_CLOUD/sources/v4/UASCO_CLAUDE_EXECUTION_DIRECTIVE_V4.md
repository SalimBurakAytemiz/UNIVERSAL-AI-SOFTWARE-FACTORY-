# UASCO V4 — EXECUTION START DIRECTIVE (CLAUDE CODE)

Bu görev yeni yol haritası tasarlamak değildir. Ekteki/erişilebilir `UASCO_MASTER_EXECUTION_ROADMAP_V4.md` yürütme stratejisini ve `UASCO_EXECUTION_MANIFEST_V4.json` bütün 57 Feature'ı ve başlangıç Task seed'lerini tanımlar. Öncelik gerçekten çalışan Windows `.exe` teslimidir.

## ÖNCE
1. Repo v7/integration, son SHA, CI, Windows Installer Artifact durumunu deterministik doğrula. Bilinen taban `16d3a925`; sonradan değiştiyse delta al. Aynı kanıt için yeniden full scan yapma.
2. V3.1'in `V3_FEATURE_CROSSWALK`, `V3_TASK_DEPENDENCY_MATRIX`, `V3_ACCEPTANCE_EVIDENCE_MATRIX`, `V3_FOUNDER_DECISION_REGISTER`, `UASCO_REMAINING_WORK` JSON'larını kaynağından yükle. 57 Feature, 164 Task ve 102 AC iddialarını say, duplicate/orphan/cycle ve kayıp kaynakları raporla. Erişilemeyen kaydı uydurma. Erişilmeyen parça ilgili Task'ta bloklansın, diğer işler sürsün.
3. İlk mevcut installer artifact'ını (run 41434581581, artifact 13135209964) teslim/indirme bağlantısıyla göster. Windows gerçek kurulum kanıtı eksikse W0'yı NOT_RUN_ENV_UNAVAILABLE olarak ayır; build başarısını ürün kabulü sayma.
4. Başlangıçta 3 file-disjoint builder lane, 1 reviewer, 1 merge owner sınırını uygula. Başlatılmış eski Cloud geliştirme rutinlerini kontrolsüz uyandırma; yalnız tek yetkili yeni supervisor ve kullanıcı onaylı düzlemde yürüt.

## MODELLER VE KURALLAR
- Deterministik araç varken model kullanma.
- Haiku: mekanik dosya düzeltme, rapor özeti, lokal refactor, kolay unit test.
- Sonnet: default API/frontend/backend/Electron/runner/test uygulaması.
- Opus: zor dependency/WSL2/lease/security/CI root cause; tek seferlik mimari/teşhis, ardından Sonnet uygular.
- Her Task'a küçük context pack; büyük geçmiş sohbeti her ajana kopyalama; tüm repo taraması yapma.
- Aynı fail fingerprint için 1 retry. Yeni kanıt yoksa döngü durur ve bağımsız Task seçilir.
- Her kod işi için exact owner, test komutu, acceptance, SHA-bound independent review; güvenli entegrasyon merdivenini izle. CI fail olunca bütün geliştirmeyi değil yalnız riskli merge'ü engelle. Security gate bypass/FAKE PASS yok.
- T2 protected trust root ve T3 paid/deploy/secret işlemlerinde Founder yetkisi olmadan işlem yapma. T2/T3 onay bekliyorsa bağımsız kod geliştirme devam eder.

## İLK İCRA SIRASI
A. W0 installer indirme/kurulum smoke, ilk ekran ve backend health.
B. W1 paralel: Lane A export/UI, Lane B gerçek predev/API, Lane C sandbox/runner; D yalnız gerekli CI ve Windows flake için; biri shared file'a ihtiyaç duyarsa tek owner.
C. W1 sonunda gerçek model, Windows sandbox, security accepted ve ZIP bağımsız build: iki proje tipi, 3 ardışık run ile kanıt; güncel .exe üret.
D. W2 tek komut, Epic/Feature/Task + AC, Founder Cockpit, API UI ve maliyet panelini gerçek backend'le bağla; güncel .exe üret.
E. W3 task DAG, crew, model routing/fallback, kota checkpoint, müşteri PR teslimi; güncel .exe üret.
F. W4/W5 kalan tüm Feature'ları güvenilir release, ek stack, revizyon, mobil/ses kapsamında sırayla tamamla.

## RAPOR VE ÇIKIŞ
Tek sayfalık raporda current SHA, installer URL ve sha256, kurulu Windows PASS/NOT_RUN, accepted/57, E2E, çalışan ekranlar/API, test kanıtı, Haiku/Sonnet/Opus kullanım maliyeti ve sonraki 3 Task göster.

Asıl çıkış koşulu: Kullanıcı Windows'ta kurup açabildiği, belirtilen ekranlarla gerçek API/AI görev zincirini işletebildiği, test/security evidence ürettiği ve bağımsız build edilen proje teslimini alabildiği .exe. Bunu CI yeşil veya mock veri ile taklit etme.

Bu yönerge tek başına yetki kapılarını değiştirmez. Önce bounded mevcut gerçek görevleri uygula; belirsizlikleri sadece gerçekten gerekli Founder kararı olarak topluca sun. Yeni roadmap, boş governance ve anlamsız PR oluşturma.
