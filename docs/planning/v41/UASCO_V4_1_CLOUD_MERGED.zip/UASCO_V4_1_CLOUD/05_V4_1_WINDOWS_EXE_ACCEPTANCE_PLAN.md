# 05 — Windows `.exe` Teslim ve Kabul Planı (patch EX-04, EX-08 + CLOUD-ONLY)

> **CLOUD-ONLY (2026-11-02, Founder yönergesi; birleştirme kuralları CO-1..CO-10: 17_CLOUD_ONLY_MERGE_REPORT.md).** Bütün geliştirme, model, test, güvenlik, sandbox, CI ve teslim bulutta yürür. Founder-PC yalnız imzalı/hash doğrulanmış `.exe`'nin kur/aç/kullan son kullanıcı kabulü (UASCO-T0002, T0002.a) içindir; BIOS/WSL/VM/Node/Claude CLI/yerel worker şartı yoktur. #231 (WSL2) AS-IS merge edilmez (D-07). Bulut sandbox/worker sağlayıcısı (D-03) verilmedikçe çalışma zamanı UNKNOWN: paket en fazla READY_FOR_CODING'dir, PRODUCT_READY değildir. UAT'tan önce cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS zorunludur.

> Bir aşamanın kanıtı diğerinin yerine geçmez. Gerçek ortam yoksa NOT_RUN_ENV_UNAVAILABLE. CI installer PASS kullanıcı kabulü değildir.

## 1. Kanıt ↔ SHA bağlama kuralları (EX-04)

1. **Kabul kiti (`founder-acceptance.mjs`) `git HEAD`'e bağlıdır.** Temiz checkout ve `npm ci` gerektirir (kit README; #231).
2. **Sıra:** T0031 (kod) → T0031.b (server.ts) → **T0069.c (reseal commit = son commit)** → **T0031.c: hosted Windows runner, PR head SHA'sını temiz checkout eder ve kiti çalıştırır** (#231 AS-IS merge edilmez; bulut sağlayıcı yolu CLOUD-T0002/T0014) → merge.
3. **T0031.c'den sonra PR dalına commit atılmaz.** Atılırsa (rebase ya da düzeltme dahil) T0031.c geçersizdir ve kit yeniden koşulur. Merge öncesi supervisor şunu doğrular: `kit.sha == PR head SHA`.
4. **Merge commit ≠ PR head.** Kit kanıtı PR head kaynağı içindir. Merge sonrası:
   - **V4-T0001.a** merge commit'inin installer'ını toplar (`.exe` SHA + kaynak merge SHA).
   - **T0002.a** bu installer'la yeniden kurulum yapar.
   - R1 koşuları (T0029 …) bu kurulu build üzerinde yapılır.
   - Eşleme kanıtı: merge commit'in ikinci ebeveyni (parent2) = kabul edilen PR head SHA'sı. Ağaç da merge-tree ile aynı olmalı; ledger bunu zaten kontrol ediyor (rapor M.2).
5. **R1 installer'ı bütün R1 kod Task'larını içerir:** V4-T0001.a, R1 kod Task'larının hepsi MERGED olmadan başlamaz (build betiği bu bağımlılıkları ekliyor).

## 2. Aşamalar

| Aşama | Sorumlu | Ortam | Yöntem | Kanıt | Başarısızlıkta |
| --- | --- | --- | --- | --- | --- |
| BUILD_OK | E (deterministik) | Actions | Push CI sonucu | run id + headSha | Merge durur |
| INSTALLER_OK | E (V4-T0001 / V4-T0001.a) | Actions windows-latest | Installer workflow + smoke (job log'u) | `.exe` adı, boyutu, sha256, kaynak SHA | D lane |
| WINDOWS_INSTALL_VERIFIED | E (CLOUD-T0006/T0013) → Founder UAT (UASCO-T0002, T0002.a) | Hosted Windows runner (Win10 19045 + Win11 matrisi) → Founder-PC yalnız kur/aç | Otomatik GUI/API smoke; sonra Founder kur/aç/kullan | JSON + ekran görüntüsü; installer sha256 = V4-T0001(.a) SHA | A/D Task'ı |
| FRONTEND_API_VERIFIED | A_UI + E | Hosted Windows runner (windows-latest E2E UASCO-T0095) | Ekran aksiyonu → `/v1` yanıtı (remote cloud API) | Ekran → route → yanıt kaydı | A Task'ı |
| REAL_AI_EXECUTION_VERIFIED | C/B (bulut) | Bulut worker + cloud model gateway (D-29) | Gerçek pre-dev | Artifact hash'leri; kullanım ya da UNKNOWN | T0061.a akışı |
| SANDBOX_VERIFIED | C (CLOUD-T0002, T0014) | Bulut sandbox (D-03); yerel WSL yok | İzolasyon testleri + fail-closed (`CLOUD_RUNTIME_NOT_CONFIGURED`) | Test raporu (head SHA'ya bağlı) | C Task'ı |
| TEST_ACCEPTED | C/B (CLOUD-T0011) | Bulut E2E | 3 ardışık run; tohumlanmış hata remediation ile düzeltilir | V3-EV-F012-2, F019-2 | Sonnet → Opus |
| SECURITY_ACCEPTED | D (CLOUD-T0007, V3-T1010) | Bulut CI runner image (pinned gitleaks + trivy) | SEC-PROFILE-R1 | security-report + araç hash'leri. PARTIAL → DELIVERED_SECURITY_PARTIAL | D-19 |
| DELIVERY_ACCEPTED | B + script (CLOUD-T0008, T0011) | Bulut temiz worker | Export sha256 + `npm ci && npm test` (şablon kilit dosyası) | V3-EV-F005-1, F057-1/2 | A / B / C |
| FOUNDER_ACCEPTED | Founder | Founder-PC (yalnız `.exe` kur/aç/kullan; bulut koşusunu izler, sonucu indirir) | SOURCE_DELIVERY_ACCEPTED + R1 demo | V3-EV-F015-1, F004-1 | İlgili aşama |

## 3. Founder-PC gereksinimleri (yalnız UAT)

Windows 10 Home (19045) ya da Windows 11, internet bağlantısı ve indirilen `.exe`. Node, Git, WSL, sanallaştırma, Claude CLI, güvenlik aracı ya da test worker kurulmaz. Uyumluluk hosted runner matrisiyle kanıtlanır (CLOUD-T0013, D-26). Eski salt-okur teşhis metni arşivdedir (sources/archive/).

## 4. İlk gerçek `.exe` tesliminin kabul şartları (R1)

1. Bulut sandbox yolu (CLOUD-T0002/T0014, UASCO-T0031 cloud) merge edildi; #231 AS-IS merge edilmedi. Reseal paketleri için: merge commit parent2 = kit'in kabul ettiği head SHA'sı.
2. Cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS; sonra V4-T0001.a installer'ı (bütün R1 kodu MERGED) Founder tarafından kuruldu (T0002.a, yalnız UAT).
3. 10 aşamanın her biri ayrı kanıtla geçti.
4. İki proje tipi, 3 ardışık run.
5. SECURITY PARTIAL ise etiket VERIFIED olmaz.
6. Bağımsız yeniden üretim PASS.
7. Elle düzenleme 0.
8. STOP ve sağlayıcı hatası negatifleri geçti.
9. R1 kapısı: 45 kabul AC'si. 7 izleme AC'si R1'i bloke etmez, STABLE durumuna sayılır.
