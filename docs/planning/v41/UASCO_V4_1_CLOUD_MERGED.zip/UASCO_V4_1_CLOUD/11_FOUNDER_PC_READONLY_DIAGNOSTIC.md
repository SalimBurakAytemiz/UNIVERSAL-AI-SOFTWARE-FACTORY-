# 11 — Founder-PC Salt-Okur Teşhisi: KALDIRILDI (CLOUD-ONLY)

> Cloud-only yönergesiyle Founder-PC'de teşhis, WSL, sanallaştırma ya da yerel worker kontrolü istenmez. Founder-PC yalnız `.exe` kur/aç/kullan kabulü içindir (UASCO-T0002, T0002.a).
> Windows 10/11 istemci uyumluluğu hosted runner matrisiyle kanıtlanır (CLOUD-T0013, D-26).
> Önceki metin yalnız tarihsel kanıt olarak saklanır: `sources/archive/11_FOUNDER_PC_READONLY_DIAGNOSTIC.historical.md` (AKTİF TALİMAT DEĞİLDİR).
