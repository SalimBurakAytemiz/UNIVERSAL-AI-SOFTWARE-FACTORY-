# 04 — Model / Ajan / Lane Atama Matrisi

## Kurallar

- **Lane = dosya sahipliği; slot = eşzamanlılık.** En fazla 3 kodlama slotu (D-12 verilmeden 1). Deterministik ve Founder Task'ları slot kullanmaz.
- **Claim:** Execution'da tek supervisor bütün slotları dağıtır; claim tablosu supervisor'dadır (tek yazar, atomik). Claim Task başlarken alınır, PR paketi MERGED olana kadar tutulur. Önek/dizin çakışması da çakışma sayılır. Aynı lane'deki iki Task da aynı dosyayı aynı anda tutamaz.
- **PR paketleri (tek PR dalında sıralı devir):** PR-251: V3-T1002 → V3-T1003 → V3-T1036 → UASCO-T0069.a; PR-231: UASCO-T0031 → UASCO-T0031.b → UASCO-T0069.c; PR-247: UASCO-T0100.a; PR-UASCO-T0004: UASCO-T0004.A → UASCO-T0004.D; PR-UASCO-T0007: UASCO-T0007.A → UASCO-T0007.D; PR-UASCO-T0011: UASCO-T0011.B → UASCO-T0011.A; PR-UASCO-T0016: UASCO-T0016.A → UASCO-T0016.D; PR-UASCO-T0017: UASCO-T0017.C → UASCO-T0017.A → UASCO-T0017.D; PR-UASCO-T0018: UASCO-T0018.A → UASCO-T0018.D; PR-UASCO-T0020: UASCO-T0020.B → UASCO-T0020.A; PR-UASCO-T0039: UASCO-T0039.C → UASCO-T0039.B; PR-UASCO-T0051: UASCO-T0051.E → UASCO-T0051.D; PR-UASCO-T0056: UASCO-T0056.C → UASCO-T0056.D; PR-UASCO-T0057: UASCO-T0057.C → UASCO-T0057.D; PR-UASCO-T0059: UASCO-T0059.C → UASCO-T0059.D; PR-UASCO-T0066: UASCO-T0066.C → UASCO-T0066.D; PR-UASCO-T0074: UASCO-T0074.B → UASCO-T0074.D; PR-UASCO-T0083: UASCO-T0083.B → UASCO-T0083.E; PR-UASCO-T0084: UASCO-T0084.B → UASCO-T0084.E; PR-UASCO-T0085: UASCO-T0085.B → UASCO-T0085.E; PR-UASCO-T0086: UASCO-T0086.B → UASCO-T0086.E; PR-UASCO-T0123: UASCO-T0123.C → UASCO-T0123.D; PR-V3-T1011: V3-T1011.B → V3-T1011.D; PR-V3-T1017: V3-T1017.C → V3-T1017.D; PR-V3-T1026: V3-T1026.B → V3-T1026.D; PR-V3-T1027: V3-T1027.B → V3-T1027.A; PR-V3-T1030: V3-T1030.C → V3-T1030.D; PR-V3-T1033: V3-T1033.E → V3-T1033.D; PR-V3-T1037: V3-T1037.C → V3-T1037.D; PR-UASCO-T0023.a: UASCO-T0023.a.A → UASCO-T0023.a.D. Paket içindeki tests/docs dosyaları paket birincil sahibine aittir.
- **Karma owner:** birden çok lane'e dokunan açık Task'lar otomatik olarak `<id>.<A|B|C|D|E|F>` alt Task'larına bölündü (EX-03). Ebeveyn SPLIT olur.
- **Review modeli:** T0 deterministik · T1 taze Sonnet · T2 taze Opus · T3 taze Opus + Founder · güvenlik-hassas dosyalar taze Opus.
- **Yükselme:** Haiku → Sonnet (diff > 80 satır ya da 2× FAIL); Sonnet → Opus (2 farklı hipotez ya da aynı fingerprint 2×), tek seferlik; ardından BLOCKED_WITH_EVIDENCE.
- **Haiku yasak:** korumalı, yetki-hassas ve güvenlik-hassas dosyalar (build kontrolü).

## Model dağılımı (açık Task; ESTIMATE)

| Model | Task | Efor h |
|---|---|---|
| sonnet | 150 | 1715–4635 |
| FOUNDER (model yok) | 15 | 17–52 |
| deterministic | 10 | 16–39 |
| opus→sonnet | 6 | 120–320 |
| haiku | 1 | 1–3 |

## Dalga × lane

| Dalga | A_UI | B_API | C_ENGINE | D_CI_RELEASE | E_CONTROL | F_FOUNDER |
|---|---|---|---|---|---|---|
| W0 | 0 | 0 | 3 | 5 | 11 | 7 |
| W1 | 6 | 9 | 18 | 10 | 7 | 3 |
| W2 | 6 | 5 | 9 | 15 | 5 | 1 |
| W3 | 0 | 1 | 12 | 7 | 2 | 2 |
| W4 | 3 | 1 | 6 | 7 | 1 | 0 |
| W5 | 1 | 4 | 3 | 5 | 5 | 2 |

## EX-03 ile bölünen Task'lar

| Ebeveyn | Alt Task'lar |
|---|---|
| UASCO-T0004 | UASCO-T0004.A, UASCO-T0004.D |
| UASCO-T0007 | UASCO-T0007.A, UASCO-T0007.D |
| UASCO-T0011 | UASCO-T0011.B, UASCO-T0011.A |
| UASCO-T0016 | UASCO-T0016.A, UASCO-T0016.D |
| UASCO-T0017 | UASCO-T0017.C, UASCO-T0017.A, UASCO-T0017.D |
| UASCO-T0018 | UASCO-T0018.A, UASCO-T0018.D |
| UASCO-T0020 | UASCO-T0020.B, UASCO-T0020.A |
| UASCO-T0023.a | UASCO-T0023.a.A, UASCO-T0023.a.D |
| UASCO-T0039 | UASCO-T0039.C, UASCO-T0039.B |
| UASCO-T0051 | UASCO-T0051.E, UASCO-T0051.D |
| UASCO-T0056 | UASCO-T0056.C, UASCO-T0056.D |
| UASCO-T0057 | UASCO-T0057.C, UASCO-T0057.D |
| UASCO-T0059 | UASCO-T0059.C, UASCO-T0059.D |
| UASCO-T0066 | UASCO-T0066.C, UASCO-T0066.D |
| UASCO-T0072 | UASCO-T0072.D, UASCO-T0072.F |
| UASCO-T0074 | UASCO-T0074.B, UASCO-T0074.D |
| UASCO-T0083 | UASCO-T0083.B, UASCO-T0083.E |
| UASCO-T0084 | UASCO-T0084.B, UASCO-T0084.E |
| UASCO-T0085 | UASCO-T0085.B, UASCO-T0085.E |
| UASCO-T0086 | UASCO-T0086.B, UASCO-T0086.E |
| UASCO-T0123 | UASCO-T0123.C, UASCO-T0123.D |
| V3-T1010 | V3-T1010.C, V3-T1010.F |
| V3-T1011 | V3-T1011.B, V3-T1011.D |
| V3-T1013 | V3-T1013.B, V3-T1013.F |
| V3-T1017 | V3-T1017.C, V3-T1017.D |
| V3-T1020 | V3-T1020.D, V3-T1020.F |
| V3-T1026 | V3-T1026.B, V3-T1026.D |
| V3-T1027 | V3-T1027.B, V3-T1027.A |
| V3-T1030 | V3-T1030.C, V3-T1030.D |
| V3-T1033 | V3-T1033.E, V3-T1033.D |
| V3-T1037 | V3-T1037.C, V3-T1037.D |
