# UASCO MASTER EXECUTION ROADMAP V4.1 — FINAL CANDIDATE (patch EX-01..EX-10 + CLOUD-ONLY)

> **CLOUD-ONLY (2026-11-02, Founder yönergesi; birleştirme kuralları CO-1..CO-10: 17_CLOUD_ONLY_MERGE_REPORT.md).** Bütün geliştirme, model, test, güvenlik, sandbox, CI ve teslim bulutta yürür. Founder-PC yalnız imzalı/hash doğrulanmış `.exe`'nin kur/aç/kullan son kullanıcı kabulü (UASCO-T0002, T0002.a) içindir; BIOS/WSL/VM/Node/Claude CLI/yerel worker şartı yoktur. #231 (WSL2) AS-IS merge edilmez (D-07). Bulut sandbox/worker sağlayıcısı (D-03) verilmedikçe çalışma zamanı UNKNOWN: paket en fazla READY_FOR_CODING'dir, PRODUCT_READY değildir. UAT'tan önce cloud e2e CI (CLOUD-T0011) ve hosted Windows installer (CLOUD-T0006) PASS zorunludur.

| Alan | Değer |
| --- | --- |
| Durum | **FINAL CANDIDATE — yürürlükte değil.** D-01 olmadan Execution başlamaz ve repo'ya yazılmaz. Bu oturumda kod, commit, PR, merge, CI ve otomasyon yok. |
| Tür | V4'ün uygulanabilirlik revizyonu + bağımsız derin denetimin EX-01..EX-10 patch'i. Yeni roadmap değil. |
| Temel | `v7/integration` @ 16d3a925 · CI 41434581692 ve Windows Installer 41434581581 SUCCESS · artifact 13135209964 (ZIP digest c44e21bf…, son tarih 2026-12-02) — VERIFIED |
| Kanonik kapanış | `uasco/production-reports` @ 770c5513 · ledger @ 122a1b12 — VERIFIED |
| Açık PR'lar | #282 (DEFER), #251, #247, #231, #66 — VERIFIED. Gerçek değişen dosyalar: #231 42 · #251 4 · #247 3 · #282 8 (`git diff --name-only merge-base…head`) |
| Rutinler / yerel | 0/11 etkin CLAIMED · yerel V6 UNKNOWN |
| Tek veri kaynağı | `v41/source.py` + `patch_ex.py` + `decisions.py` + `recon.py` + `sim.py` + `sources/*` → `build.py` + `docs.py` |

## 1. V4'ten ve önceki V4.1'den korunanlar

Beş ilke, execution packet şeması, W0–W5 dalgaları, lane'ler, model aileleri, G/X/B uzlaştırması, tek retry kuralı, kısa rapor biçimi.

## 2. Bu patch'te değişenler (ayrıntı: 12_EX_FINDINGS_CLOSURE.md)

- **Tipli durumlar ve bağımlılıklar (EX-01):** PLANNED → CODING → CODE_READY → REVIEWED → MERGED (kod) · ACCEPTED (Founder kabul) · DONE (karar / deterministik kayıt). Her bağımlılık `Task:DURUM` biçiminde. PR paketleri tanımlı: PR-251, PR-231 (merge ön koşulu: Founder kabul kiti), PR-247.
- **Yetki sınıflandırması (EX-02 + bağımsız review R-S1..S5):**
  - `NEW:`/`PR231:` yolları normalize edilir. Korumalı dosya içeren klasör hedefleri korumalı sayılır.
  - T2 (fail-closed) kapsamı: `config/`, `.github/`, `scripts/validate-*`, `scripts/ci/`, `automation/lib/`, `schemas/`, `prompts/`, `.ai/`, `docs/acceptance/`, docs altındaki çalıştırılabilir dosyalar, `docs/routines/`, `docs/planning/dispatch.mjs`, tedarik zinciri (package.json, lock, `.npmrc`), release (`scripts/build-installer.mjs`, `installer/`), ücretli model yönlendirmesi (`core/policy/`, `models/router/`, `models/omniroute/`), supervisor araçları, coord-ledger, GitHub ayarları.
  - Güvenlik uygulayan kod da T2: execution-gate, sandbox, runner, executors, claude-profiles, security-tools, secret-scan, test-surface, action-gateway, preload, devrun.
  - Register'a yalnız deterministik araç yazar (CI'sız); LLM yazmaz.
  - Mühürlü (trust-root) dosyaya dokunan her Task'ın write set'ine manifest eklenir ve aynı PR'da D lane reseal'i yapar.
- **Gerçek write set'ler (EX-03):** PR paketlerinin dosyaları gerçek changed-files listelerinden geliyor. Karma owner'lı 16 Task otomatik olarak `.A/.B/.C/.D/.E/.F` alt Task'larına bölündü. Önek/dizin çakışması algılanıyor. V3-T1014 #231 merge'ünden sonraya alındı (`executors.ts`).
- **Kabul SHA'sı (EX-04 + R-D1/D2):**
  - Sıra: reseal (T0069.c) → reseal'in review'u → Founder kabul kiti (T0031.c) son head'de → merge.
  - **Reseal penceresi kilidi:** reseal başladığı andan paket merge'üne kadar başka merge yapılmaz; base sabit kalır, update-branch gerekmez.
  - Reseal yalnız paketin merge kapıları karara bağlıysa başlar.
  - Head değişirse kit yeniden koşulur.
  - Merge sonrası yeni installer (V4-T0001.a) toplanır ve yeniden kurulur (T0002.a).
- **Yetkilendirme durumları (EX-05):** DESIGN_FINAL_CANDIDATE → FOUNDER_AUTHORIZED (D-01) → CODE_ALLOWED (Task'ın kendi startGates'i; D-12 yoksa 1 slot) → MERGE_ALLOWED → WINDOWS_ACCEPTANCE_ALLOWED. Başlangıç için tek zorunlu karar D-01. D-24, D-01 ile birleştirildi.
- **M0 (EX-06):** V3-T1008 başlangıç kapısı yok. Geçici mod mevcut kurallar içinde: tek merger + update-branch + birleşik SHA'da tam CI. 14 günlük ölçüt yalnız izleme.
- **Doğrulama komutu (EX-07):** `v41/verify.py` (Linux / Windows, salt-okur).
- **Windows ön koşulları (EX-08):** 11_* salt-okur teşhis. Windows 11 dayatılmaz; D-26 teşhisten sonra.
- **Ölçüt ayrımı (EX-09):** uzun pencere ölçütleri `monitoring` alanında; 10 AC STABILITY_MONITORING; merge kapısı değiller.
- **Kanıt sayaçları (EX-10):** EVIDENCE_SPEC_COUNT 102 · **EVIDENCE_VERIFIED_PASS_COUNT 0** · LEGACY_UNIT (yeniden bağlanacak) 10 · NOT_PRODUCED 92.

## 3. Sayılar (makine-okunur kayıtlardan)

- 57 Feature.
- **256 kayıt** = 175 temel kayıt (129 legacy + 35 V3.1 + 11 V4.1; 175/175 korundu) + 3 EX-04 Task'ı (UASCO-T0002.a, UASCO-T0031.c, V4-T0001.a) + 63 EX-03 alt Task'ı (karma owner bölmesi). SPLIT konteynerleri: 32. Açık iş: **182**.
- 102 AC ve 102 kanıt spesifikasyonu; bunlardan PASS kanıtı **0**.
- 31 karar:

  | Grup | Karar sayısı |
  | --- | --- |
  | 0 (başlangıç) | 1 |
  | 1 (alan kapıları) | 8 |
  | 2 (kodlama sürerken) | 14 |
  | 3 (ileri faz) | 7 |
  | Birleştirilen | 1 |

- **Tier (açık Task):** {'T3': 8, 'T2': 115, 'T1': 42, 'T0': 17}.

## 4. Dalgalar (açık Task; efor ESTIMATE)

| Dalga | Açık Task | Efor h |
| --- | --- | --- |
| W0 | 26 | 49–128 |
| W1 | 53 | 244–725 |
| W2 | 41 | 255–666 |
| W3 | 24 | 374–992 |
| W4 | 18 | 371–964 |
| W5 | 20 | 576–1574 |

**Kritik yol (R1):** CLOUD-T0001 → CLOUD-T0003 → CLOUD-T0002 → UASCO-T0031 → UASCO-T0031.b → UASCO-T0069.c → V4-T0001.a → UASCO-T0002.a → UASCO-T0029 → UASCO-T0014 → UASCO-T0035 = 79–236 h. R1 kapanış kümesi 57 Task, 246–726 h (ESTIMATE).

## 5. Merge sırası (tipli; 3-slot simülasyonuyla doğrulandı)

| Sıra | Ne | Durum geçişi | Kapılar |
| --- | --- | --- | --- |
| M0 | Geçici seri merge modu (V3-T1008) | Mevcut kurallar; karar gerekmez | — |
| M1 | V3-T1001 store-lock | REVIEWED → MERGED | — (T1) |
| M2 | PR-251: V3-T1002 → V3-T1003/V3-T1036 (CODE_READY) → UASCO-T0069.a reseal (üyeler REVIEWED) → paket merge | MERGED | D-18, D-07, D-31 |
| M3 | UASCO-T0016 export | MERGED | D-31 |
| M4 | PR-247: UASCO-T0100.a | MERGED (PR-251'den sonra) | D-07, D-31 |
| M5 | PR-231: T0031 (C, REVIEWED) → T0031.b (B; T0031:CODE_READY'den sonra) → T0069.c reseal (D; PR-251 MERGED'den sonra) → **T0031.c Founder kiti son head'de ACCEPTED** → paket merge. Head değişirse T0031.c yeniden | MERGED | D-03, D-07, D-31, D-23 |
| M6 | V4-T0001.a yeni installer (bütün R1 kodu MERGED) → T0002.a yeniden kurulum → T0029 / T0044 / V3-T1018 / T0014 / T0035 | ACCEPTED | D-23, D-26, D-29, D-19 |
| M7 | UASCO-T0069.b koruma genişletmesi | MERGED | D-07, D-31 |
| — | #282 | DEFER; D-22 ölçütü (3 ardışık tam yeşil Windows + base kontrol); otomatik koşu yok | D-22 |
| — | #66 | Merge yok (D-11) | D-11 |

## 6. İlk paralel dalga (simülasyon S2: D-01 + Grup 1, kabul ortamı henüz yok)

- **Slot gerektirenler (ilk başlayanlar):** V3-T1002, V3-T1001, V3-T1012.a, UASCO-T0016.A, UASCO-T0120, V3-T1003.
- **Slot gerektirmeyen (deterministik / Founder):** V3-T1006, UASCO-T0115, UASCO-T0103, V4-T0002, UASCO-T0100, V3-T1005, UASCO-T0124, UASCO-T0119.
- **D-01 tek başına verilirse (S1, 1 slot):** ilk başlayanlar V3-T1002, V3-T1006, UASCO-T0115, UASCO-T0100, V3-T1005, UASCO-T0124, V3-T1003, V3-T1036 … Tamamlanan 7/182; kalanların hepsi karar ya da Founder ortamı bekliyor, **kilitlenme 0**.

## 7. Simülasyon sonuçları (13_*)

| Senaryo | Verilen kararlar | Kabul ortamı (hosted runner / UAT) | Slot | Tamamlanan | Kilitlenme | Bağımsız denetimde çakışma | Kapı atlaması | Kilit / freeze ihlali | En çok slot |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| S0 | — | — | 0 | 0 (repo yazma yok) | 0 | 0 | 0 | 0 | 0 |
| S1 | D-01 | yok | 1 | 7/182 | 0 | 0 | 0 | 0/0 | 1 |
| S2 | D-01, D-03, D-07, D-08, D-12, D-18, D-23, D-26, D-31 | yok | 3 | 71/182 | 0 | 0 | 0 | 0/0 | 3 |
| S3 | hepsi | var | 3 | 182/182 | 0 | 0 | 0 | 0/0 | 3 |
| S4 | hepsi | yok | 3 | 110/182 | 0 | 0 | 0 | 0/0 | 3 |
| S5 | hepsi | var | 3 | 119/182 | 0 | 0 | 0 | 0/0 | 3 |
| S6 | hepsi | var | 3 | 182/182 | 0 | 0 | 0 | 0/0 | 3 |
| S7 | hepsi | var | 3 | 119/182 | 0 | 0 | 0 | 0/0 | 3 |
| S8 | hepsi | var | 3 | 182/182 | 0 | 0 | 0 | 0/0 | 3 |
| S9 | hepsi | var | 3 | 117/182 | 0 | 0 | 0 | 0/0 | 3 |

- **S4:** bütün kararlar verilmiş ama kabul ortamı (hosted Windows runner / Founder UAT) yok. Reseal kilidi hiç alınmıyor, merge'ler sürüyor (R2-N0).
- **S5:** kabul kiti, kilit zaman aşımını (kit başlatılabilir olduğu andan 24 h) aşıyor. Kilit iki kez iptal ediliyor; PR-231 eskalasyona gidiyor. Güvenli varsayılan: paket ertelenir, claim'ler serbest bırakılır. Kalan işler açıkça D-03 kararını bekliyor; kilit sonda serbest.
- **S6:** kit bir kez NOT_ACCEPTED dönüyor. Kilit bırakılıyor, düzeltme aynı PR paketinde yapılıyor (üyeler yeniden açılıyor, claim'ler pakette kalıyor), kit yeniden koşuyor. Sonuç: 167/167 (R3-L2).
- **S7:** kit iki kez başarısız. Eskalasyon (D-03), paket ertelenir, claim'ler serbest (R3-L3).
- **S9:** Founder kilitten sonra ulaşılamaz oluyor. Kit 8 h içinde başlamadığı için kilit iptal ediliyor (kit öncesi zaman aşımı); iki iptalden sonra eskalasyon (ESC-PR-231); kilit serbest, merge'ler sürüyor (R5).
- **S8:** bütün Founder Task'ları 40 h sürüyor. Kilit yalnız Founder boşken alınıyor, zaman aşımı kit fiilen başlayınca başlıyor. Sonuç: iptal 0, 167/167 (R4-L1).
- **Founder rezervasyonu (R3-L1, R4-L1):** kilit yalnız Founder boşken alınır; kilit süresince Founder yalnız kilitli paketin kitini yapar; zaman aşımı kit fiilen başladığında başlar.

**Negatif (mutasyon) testleri:** claim'ler kapatılınca bağımsız denetim 35 çakışma buluyor; reseal kilidi kapatılınca 30 kilit ihlali buluyor. Yani "0" sonuçları tanım gereği değil, ölçülmüş sonuçlar (R-D3, R2-N1).

Bağımsız denetim, claim mantığından ayrı bir kontroldür. Simülasyon günlüğündeki aralıklardan (başlangıç → merge; aynı PR içinde başlangıç → bitiş) dosya ve paylaşılan dış kaynak çakışmasını yeniden hesaplar. Aynı PR'daki eşzamanlı kodlamayı da kapsar (R-D3).

S3'te R1'in son Task'ı (UASCO-T0035) simülasyon saatiyle ~193.3 h'de tamamlanıyor. Bu, ortalama efor ve kesintisiz Founder varsayımıyla üretilmiş bir **ESTIMATE**'tir; takvim değildir.

## 8. Doğrulama

`cd <paket-kökü> && python3 v41/verify.py` (Linux/macOS) · `cd <paket-kökü>; py -3 v41\verify.py   # ya da: python v41\verify.py` (Windows PowerShell). Kanıt: 14_V4_1_TEST_EVIDENCE.md.

## 9. Doğrulanamayanlar

- `.exe`'nin adı ve SHA'sı.
- Installer smoke ayrıntısı.
- Rutin durumu.
- Bulut sandbox/worker sağlayıcısı ve kalıcılık (D-03, D-08): UNKNOWN.
- Merge queue'nun kullanılabilirliği.
- Claude otomatik güncellemesi.
- #231 rebase çakışma boyutu.
- Efor/maliyet (ESTIMATE).
- Windows'ta `verify.py` çalıştırılmadı (NOT_RUN_ENV_UNAVAILABLE).
