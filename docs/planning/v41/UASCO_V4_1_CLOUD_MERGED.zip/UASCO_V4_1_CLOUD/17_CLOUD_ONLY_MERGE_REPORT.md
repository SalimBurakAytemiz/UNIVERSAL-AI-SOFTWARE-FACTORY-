# 17 — Cloud-Only Birleştirme Raporu (V4.1 PATCHED 241 + CLOUD_ONLY_CHANGE_REQUEST 2026-11-02)

Kaynaklar: `sources/v41_patched/` (PATCHED 241 çıktısı, SHA manifestiyle doğrulandı), `sources/cloud/CLOUD_ONLY_CHANGE_MATRIX.json` (MERGE_ONLY; 175 tabanlı). Üretici: `v41/cloud_only.py` (kurallar CO-1..CO-10).

- Task: 256 (= 241 PATCHED + 15 CLOUD-T). Override uygulanan mevcut Task: 21.
- Statik hata: 0 · self-test: 36/36 · kanıt PASS sayacı: 0
- Durum: READY_FOR_CODING adayı (bulut çalışma zamanı UNKNOWN) · PRODUCT_READY DEĞİL.

## Uygulama günlüğü

- CO-8 AC overrides 32
- CO-1 added 15 CLOUD tasks
- CO-6 UASCO-T0002: UAT ön koşulu CLOUD-T0011
- CO-6 UASCO-T0002: UAT ön koşulu CLOUD-T0006
- CO-6 UASCO-T0002.a: UAT ön koşulu CLOUD-T0011
- CO-6 UASCO-T0002.a: UAT ön koşulu CLOUD-T0006
- CO-5 V3-T1010: split parent; deps/files applied to Founder-PC child
- CO-5 V3-T1013: split parent; deps/files applied to Founder-PC child
- CO-4 UASCO-T0031: targetFiles kept (PR-231 real write set); cloud target ['NEW:core/sandbox/cloud-sandbox-provider.ts'] owned by CLOUD-T0002/T0014
- CO-4 UASCO-T0031.b: targetFiles kept (PR-231 real write set); cloud target ['apps/control-api/src/server.ts'] owned by CLOUD-T0002/T0014
- CO-4 UASCO-T0069.c: targetFiles kept (PR-231 real write set); cloud target ['config/trust-root-manifest.json'] owned by CLOUD-T0002/T0014
- CO-5 V3-T1010.F: Founder-PC → cloud (['NEW:scripts/ci/cloud-security.mjs'])
- CO-5 V3-T1013.F: Founder-PC → cloud (['NEW:tests/cloud/predev-live.test.ts'])
- CO-10 UASCO-T0069.b: dep UASCO-T0029:ACCEPTED → UASCO-T0029:MERGED (Founder-PC → cloud)
- CO-11 UASCO-T0011.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 UASCO-T0017.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 V3-T1023.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 UASCO-T0011.B.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 UASCO-T0011.A.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 UASCO-T0017.C.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 UASCO-T0017.A.doneMerge: Founder-PC kanıtı → hosted Windows runner
- CO-11 UASCO-T0017.D.doneMerge: Founder-PC kanıtı → hosted Windows runner

## Bilinçli olarak uygulanmayan / farklı uygulanan alanlar

- Override `authorityTier` daha düşükse uygulanmadı (CO-2; ör. V3-T1010 T1, UASCO-T0003/T0061 T1, V3-T1019 T0).
- Override `lane` yalnız öneri; PATCHED owner + karma-owner bölme kuralı geçerli; sapmalar `laneHint` alanında.
- PR-231 üyelerinin targetFiles'ı korunur (CO-4); bulut hedef dosyaları CLOUD-T0002/T0014 kapsamında.
- D-23 hiçbir Task'tan kaldırılmadı (gate düşürme yok); D-23 anlamı artık yalnız `.exe` UAT.
- sim.py R4-L1 düzeltmesi: kit süresi kit başladığı anda başlar (önceden bir sonraki olaya kadar gecikebiliyordu). Düzeltilmiş sim orijinal PATCHED verisinde de 0 hata verir.
