# 15 — Bağımsız Reviewer Kaydı (güvenlik sınıflandırması ve kilitlenme)

## Reviewer ve yöntem

- **Reviewer:** Ayrı, taze bir alt ajan. Paketi yazmadı ve salt-okur çalıştı.
- **Kendi kontrol betikleri:** cls/cls2 (sınıflandırma), sched (tipli döngü ve claim-kilitlenme analizi), window/r2/r3/r4d (rastgele ve pertürbasyonlu programlar, kendi aralık denetimi, kilit penceresi ve eski-kit kontrolleri), intra (aynı PR içinde eşzamanlı yazma), live (liveness senaryoları).
- **Bağımsızlık:** Betiklerin bir kısmı sim.py'den bağımsızdı. Diğerleri, davranışı değişik girdilerle sınamak için sim.py'yi bilerek kullandı.
- **Konum:** Betikler `scratchpad/review_tmp/` altında; pakete dahil değildir.

## Turlar

| Tur | Paket | Bulgular | Hüküm (güvenlik / kilitlenme / liveness) |
| --- | --- | --- | --- |
| 1 | pkg1 | S1–S5 (4 HIGH, 1 MEDIUM-HIGH, 1 MEDIUM), D1–D5 (2 HIGH, 2 MEDIUM, 1 LOW) | NOT CONFIRMED / yalnız modelde CONFIRMED / — |
| 2 | pkg2 | N0 HIGH (kilit merge'leri süresiz dondurabiliyor), N1–N3 MEDIUM, N4 LOW | CONFIRMED (artıklarla) / modelde CONFIRMED / NOT CONFIRMED |
| 3 | pkg3 | L1–L3 MEDIUM, L4 LOW | CONFIRMED / CONFIRMED / PARTIALLY |
| 4 | pkg4 | L1 kalıntısı MEDIUM, 2 LOW | CONFIRMED / CONFIRMED / PARTIALLY |
| 5 | pkg5 | L1 CLOSED; 1 LOW (kit öncesi bekleme sınırsız) | **CONFIRMED / CONFIRMED / CONFIRMED (modelde, LOW kalıntıyla)** |

**5. tur ölçümleri** (varyant başına 40 rastgele koşu: rand, founderslow, founderlong, kitfail1, kitfail2):

- Gerçek hata olmadan iptal: 0. Önceki turda 15'ti.
- Gerçek hata olmadan eskalasyon: 0. Önceki turda 3'tü.
- Kilitlenme, denetim çakışması, kilit penceresi ihlali ve eski-kit merge'ü: hepsi 0.
- kitfail2'nin 40/40 koşusu `ESC-PR-231` kararıyla bitiyor; DEADLOCK ya da CYCLE yok.

## 5. tur sonrası yapılan son değişiklik (re-review EDİLMEDİ)

5. turun LOW kalıntısı, review'dan sonra bu oturumda kapatıldı:

- **Değişiklik:** Kit öncesi zaman aşımı 8 h (`LOCK_PREKIT_TIMEOUT_H`).
- **Yeni senaryo S9:** Founder kilitten sonra ulaşılamaz oluyor. Sonuç: iptal, iki iptalden sonra eskalasyon, kilit sonda serbest. Kilitlenme 0; kalan Task'ların nedeni FOUNDER_UNAVAILABLE ya da ESC kararı.
- **Doğrulama:** Yalnız yazarın kendi testleri (verify.py, S9).

Bu son değişiklik bağımsız reviewer tarafından yeniden doğrulanmadı. Değişiklik küçük ve yalnız iptal yolunu tetikliyor; S0–S8 sonuçları değişmedi.

## Modelin sınırları (reviewer'ın da belirttiği)

Simülasyon bir modeldir:

- Süreler efor tahminidir.
- Founder ortamı senaryo boyunca sabit kabul edilir (S9 dışında).
- Gerçek CI flake'leri, GitHub API hataları ve insan hatası modellenmez.

Execution'da aynı kurallar supervisor tarafından uygulanmalı (09_*). Sapmalar her raporda "beklenen ↔ gerçek sıra" olarak gösterilir.
